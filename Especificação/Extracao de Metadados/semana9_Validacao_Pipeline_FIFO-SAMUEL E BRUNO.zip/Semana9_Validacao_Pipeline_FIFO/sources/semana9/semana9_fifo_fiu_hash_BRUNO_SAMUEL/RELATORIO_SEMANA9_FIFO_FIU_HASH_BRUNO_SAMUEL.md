# Semana 9 — Avaliação da FIFO entre FIU e Hash Unit

**Projeto:** Extração de Features de Fluxos TCP/IP para IDS baseado em ML  
**Responsáveis pela avaliação da FIFO:** Bruno e Samuel  
**Data da avaliação:** 24/11/2026  
**Ferramenta de simulação RTL:** ModelSim – Intel FPGA Starter Edition 2020.1

## 1. Solicitação da Alessandra e escopo

A atividade da Semana 9 pede **avaliar a viabilidade de uma FIFO antes da Hash Unit**, para guardar temporariamente as transferências produzidas pela Flow Identification Unit (FIU) enquanto o cálculo de CRC estiver ocupado. As orientações são: (i) analisar sinais de escrita, leitura, FIFO cheia e vazia; (ii) definir a largura incluindo `flow_key`, `packet_length` e `timestamp`; (iii) estimar profundidade pela diferença entre ritmos de chegada e processamento; e (iv) testar rajadas, ocupação máxima e política de FIFO cheia.

Este relatório cobre essa atividade de Bruno e Samuel. A avaliação complementar da **Hash Unit em pipeline** é conduzida pela Alessandra e não é objeto desta implementação.

## 2. Ponto de partida

Os RTLs da Semana 8 conectavam a saída da FIU diretamente à Hash, sem FIFO nem negociação de prontidão. A FIU podia produzir transferências com intervalo local mínimo de aproximadamente **3 clocks**; a Hash sequencial consumia 13 bytes da chave a um byte por clock e exigia intervalo mínimo de **16 clocks** entre capturas. O teste anterior de integração usava intervalo de **80 clocks**, suficiente para comprovar seu caso espaçado, mas sem provocar acúmulo antes da Hash.

**Nota 1 — Taxas:** o intervalo de 16 clocks refere-se à capacidade de aceitar uma nova transferência na implementação atual da Hash. Treze clocks correspondem ao cálculo dos 13 bytes, e os demais ciclos decorrem da captura, partida e publicação. A estimativa de FIFO deve usar o intervalo entre aceitações, não apenas os ciclos aritméticos do CRC.

## 3. Interface avaliada

| Elemento | Função na versão de avaliação |
|---|---|
| `in_valid` / `in_ready` na FIU | A testbench apresenta um pacote apenas quando a FIU indica prontidão. |
| `out_valid` / `out_ready` da FIU | A FIU mantém seus dados registrados até a FIFO poder gravá-los. |
| `in_valid` / `in_ready` da FIFO | Escrita quando a saída da FIU é válida e há espaço, inclusive se uma leitura simultânea liberar uma posição. |
| `out_valid` / `out_ready` da FIFO | Leitura da entrada mais antiga quando a Hash está pronta para capturá-la. |
| `fifo_full` / `fifo_empty` | Indicam ocupação total ou zero, respectivamente. |
| `fifo_occupancy` | Número de posições ocupadas; permite medir o pico na Wave. |
| `reset` | Síncrono, ativo em nível alto na FIU, FIFO e Hash. |

O percurso avaliado é **metadados → FIU → FIFO → Hash Unit**. O `fiu_hash_top.sv` da Semana 9 conecta os três blocos. A testbench não inclui Packet Parser, Controller, Flow Table nem Finalizer.

### 3.1 Largura e profundidade

| Campo por posição | Largura |
|---|---:|
| `flow_key` | 104 bits |
| `packet_length` | 16 bits |
| `timestamp` | 80 bits |
| **Total** | **200 bits** |

A configuração testada possui **8 posições**, ou **1.600 bits de dados**, sem contar ponteiros e lógica de controle. O sinal de validade qualifica a escrita e não ocupa um bit por posição. A FIFO preserva a associação entre os três campos e a ordem de chegada.

**Nota 2 — Profundidade:** oito posições são uma configuração experimental. Os testes mostram quando ela basta e quando impõe espera; não estabelecem ainda a profundidade final para o tráfego real.

### 3.2 Política de FIFO cheia

Quando a FIFO enche, `fifo_full` sobe e a entrada deixa de aceitar novas transferências até existir espaço. Na testbench, a origem **espera `in_ready=1` antes de apresentar o próximo pulso `in_valid`**. Essa é a política testada para evitar descartes, e a espera reduz a taxa efetiva de chegada.

**Nota 3 — Contrato da origem:** o futuro Parser ou seu adaptador precisa conseguir reter/pausar a próxima transferência. Se não puder, deve ser definida outra política (por exemplo, descarte com contagem explícita). Os resultados de zero perdas dependem de a origem obedecer ao contrato utilizado na testbench. A FIU atual ainda exige ao menos um ciclo baixo de `in_valid` entre pulsos.

## 4. Organização e execução

Os arquivos da Semana 9 foram organizados em `semana9_fifo_fiu_hash_arquivos/rtl` (`flow_identification_unit.sv`, `flow_fifo.sv`, `hash_unit.sv` e `fiu_hash_top.sv`) e `semana9_fifo_fiu_hash_arquivos/tb` (`tb_semana9_fifo.sv`). O projeto ModelSim ficou em `semana9_fifo_fiu_hash_projeto`. As cópias da Semana 8 incluídas como referência no pacote original **não são compiladas junto com os módulos da Semana 9**, pois repetem nomes de módulos.

A testbench gera metadados distintos, calcula um CRC-16 de referência e confere a cada saída a **ordem**, `flow_key`, `packet_length`, `timestamp` e `hash_index`. Também mede a ocupação máxima e os clocks em que a origem precisou esperar. Os cenários são reiniciados separadamente. A checagem de reset é feita com a FIFO ocupada e inclui a constatação de que a limpeza não ocorre antes da próxima borda de subida.

## 5. Resultados observados no ModelSim

| Cenário | Profundidade | Ocupação máxima | Espera da origem | Resultado |
|---|---:|---:|---:|---|
| 8 pacotes; intervalo solicitado de 3 clocks | 8 | 6 | 0 clocks | Passou; 0 perdas |
| 32 pacotes; intervalo solicitado de 3 clocks | 8 | 8 | 263 clocks | Passou; 0 perdas com espera |
| 32 pacotes; intervalo solicitado de 16 clocks | 8 | 1 | 0 clocks | Passou; 0 perdas |
| Reset ativo alto com FIFO ocupada | 8 | — | — | Passou; limpeza na borda de subida |

O Transcript terminou com **“TODOS OS CENARIOS DA FIFO PASSARAM”**, sem mensagens `$fatal` desses ensaios. A Wave da rajada de 32 pacotes mostra a ocupação em **8**, `fifo_full=1`, períodos de `in_ready=0`, aumento de `wait_cycles` e pulsos subsequentes de `hash_valid`. A mensagem inicial `couldn't open "transcript": permission denied` diz respeito à gravação do arquivo de log pelo ModelSim e não impediu o `run -all` mostrado na captura.

**Nota 4 — Interpretação dos 263 clocks:** são a soma das esperas da origem nesse cenário, não a latência de um único pacote. “Intervalo solicitado de 3 clocks” não significa que todas as transferências foram efetivamente aceitas a esse ritmo quando houve contrapressão.

**Nota 5 — Contadores no último cenário:** após o teste de reset com a fila ocupada, a Wave final mostra `accepted=12` e `checked=2`. As transferências ainda pendentes foram **canceladas deliberadamente pelo reset**; isso não indica perdas no ensaio anterior de 32 pacotes.

### 5.1 Evidências visuais

**Figura 1 — Transcript dos cenários da FIFO entre FIU e Hash Unit.** A captura mostra os três resultados quantitativos, a aprovação do reset e a mensagem final de sucesso. Arquivo de evidência: `Transcript_Semana9.png`.

**Figura 2 — Ocupação máxima da FIFO e controle da entrada durante a rajada de pacotes.** Na região em que `accepted` cresce de aproximadamente 10 para 14, a FIFO atinge oito posições; `fifo_full` sobe e `in_ready` impede nova aceitação até haver espaço. Arquivo de evidência: `Wave_FIFO_Cheia_Semana9.png`.

## 6. Conclusão vinculada à atividade

A simulação RTL **demonstra a viabilidade funcional de uma FIFO de 200 bits por posição, com profundidade 8, entre a FIU e a Hash atual** para os cenários programados. A rajada curta de oito pacotes coube sem espera. A de 32 pacotes atingiu a ocupação máxima; o controle de prontidão fez a origem esperar e permitiu conferir os 32 resultados sem perda ou alteração de ordem/dados. O cenário a cada 16 clocks praticamente não acumulou dados.

Uma FIFO finita absorve rajadas, mas **não aumenta a taxa sustentada da Hash**. Se a origem tentar manter por tempo indefinido uma taxa maior que a taxa de processamento, ocorrerá espera contínua ou será necessária uma política explícita de descarte. A escolha definitiva da profundidade depende do perfil real de chegada de pacotes, do limite aceitável de espera e da possibilidade de contrapressão na interface do Parser.

## 7. Encaminhamentos e limites

1. Confirmar com Herman e o grupo como o Parser sinalizará e respeitará `in_ready`, inclusive durante captura de pacotes no AXI Stream.
2. Medir rajadas reais ou definir uma hipótese formal de duração e taxa máxima para selecionar a profundidade final.
3. Integrar a saída da Hash ao Controller com controle de aceitação: o Controller atual só captura `hash_valid` quando está em `IDLE`. Uma FIFO **antes** da Hash não resolve, por si, ocupação **depois** dela.
4. Reavaliar taxa de serviço e dimensionamento caso o estudo complementar da Alessandra resulte numa Hash em pipeline.
5. Preservar Transcript e Wave com o código exato utilizado; compilar e testar novamente após cada mudança de interface.

**Estado da avaliação:** simulação isolada FIU–FIFO–Hash concluída nos quatro cenários acima; integração completa e profundidade final pendentes.
