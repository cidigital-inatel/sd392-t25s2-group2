`timescale 1ns/1ps
`default_nettype none

module fiu_hash_top #(
    parameter integer FIFO_DEPTH = 8,
    parameter integer COUNT_W = $clog2(FIFO_DEPTH + 1)
) (
    input wire logic clk, reset,
    input wire logic [31:0] src_ip_in, dst_ip_in,
    input wire logic [15:0] src_port_in, dst_port_in,
    input wire logic [7:0] protocol_in,
    input wire logic [15:0] packet_length_in,
    input wire logic [79:0] timestamp_in,
    input wire logic in_valid,
    output logic in_ready,
    output logic [15:0] hash_index,
    output logic [103:0] flow_key,
    output logic [15:0] packet_length,
    output logic [79:0] timestamp,
    output logic hash_valid,
    output logic fifo_full, fifo_empty,
    output logic [COUNT_W-1:0] fifo_occupancy
);
    logic [103:0] fiu_key;
    logic [15:0] fiu_length;
    logic [79:0] fiu_timestamp;
    logic fiu_valid, fifo_ready, hash_ready, fifo_valid;
    logic [199:0] fifo_data;

    flow_identification_unit u_fiu (
        .clk, .reset,
        .src_ip_in, .dst_ip_in, .src_port_in, .dst_port_in,
        .protocol_in, .packet_length_in, .timestamp_in, .in_valid,
        .in_ready(in_ready), .out_ready(fifo_ready),
        .flow_key_out(fiu_key), .packet_length_out(fiu_length),
        .timestamp_out(fiu_timestamp), .out_valid(fiu_valid)
    );

    flow_fifo #(.DEPTH(FIFO_DEPTH)) u_fifo (
        .clk, .reset, .in_data({fiu_key, fiu_length, fiu_timestamp}),
        .in_valid(fiu_valid), .in_ready(fifo_ready),
        .out_data(fifo_data), .out_valid(fifo_valid),
        .out_ready(hash_ready), .full(fifo_full), .empty(fifo_empty),
        .occupancy(fifo_occupancy)
    );

    hash_unit u_hash (
        .clk, .reset,
        .flow_key_in(fifo_data[199:96]),
        .packet_length_in(fifo_data[95:80]),
        .timestamp_in(fifo_data[79:0]),
        .in_valid(fifo_valid && hash_ready), .in_ready(hash_ready),
        .hash_index_out(hash_index), .flow_key_out(flow_key),
        .packet_length_out(packet_length), .timestamp_out(timestamp),
        .out_valid(hash_valid)
    );
endmodule

`default_nettype wire
