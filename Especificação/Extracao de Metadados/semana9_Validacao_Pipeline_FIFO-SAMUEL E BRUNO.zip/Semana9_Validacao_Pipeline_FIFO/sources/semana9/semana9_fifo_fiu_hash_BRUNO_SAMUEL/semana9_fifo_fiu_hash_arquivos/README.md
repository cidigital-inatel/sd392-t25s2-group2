# Semana 9 — FIFO entre FIU e Hash Unit

Projeto de **avaliação isolada FIU → FIFO → Hash** para ModelSim. Os arquivos da Semana 8 ficam em `referencia_semana8/` para comparação; compile somente `rtl/` e `tb/` desta pasta. A integração com Controller, Flow Table, Finalizer e Parser ainda não está validada nesta versão.

## Interface

- FIFO: 200 bits por palavra (`flow_key` 104 + `packet_length` 16 + `timestamp` 80), profundidade parametrizável, padrão 8.
- `in_valid` só pode ser apresentado na FIU quando `in_ready=1`. Após a transferência, mantenha `in_valid=0` por pelo menos um clock. A testbench respeita esse contrato.
- `fifo_full`, `fifo_empty` e `fifo_occupancy` estão expostos para observação.
- Reset síncrono, ativo alto. Os ponteiros e a ocupação são limpos; os bits físicos da memória não são apagados e não ficam válidos após reset.
- A Hash oferece `in_ready` para a leitura da FIFO na borda em que captura seus dados. O pulso `in_valid` é gerado somente nessa aceitação.

## Como executar no ModelSim

Abra o ModelSim, mude o diretório de trabalho para **esta pasta** e use o Transcript:

```tcl
vlib work
vlog -sv rtl/flow_identification_unit.sv rtl/hash_unit.sv rtl/flow_fifo.sv rtl/fiu_hash_top.sv tb/tb_semana9_fifo.sv
vsim -onfinish stop work.tb_semana9_fifo
run -all
```

Para ver a ocupação e os sinais, antes do `run -all` execute:

```tcl
add wave sim:/tb_semana9_fifo/clk sim:/tb_semana9_fifo/reset sim:/tb_semana9_fifo/in_valid sim:/tb_semana9_fifo/in_ready
add wave sim:/tb_semana9_fifo/fifo_full sim:/tb_semana9_fifo/fifo_empty sim:/tb_semana9_fifo/fifo_occupancy
add wave sim:/tb_semana9_fifo/dut/u_fiu/out_valid sim:/tb_semana9_fifo/dut/u_fifo/do_write sim:/tb_semana9_fifo/dut/u_fifo/do_read
add wave sim:/tb_semana9_fifo/hash_valid sim:/tb_semana9_fifo/flow_key sim:/tb_semana9_fifo/hash_index
```

## Ensaios automáticos

1. Rajada de 8 pacotes solicitados a cada 3 clocks.
2. Rajada de 32 pacotes no mesmo ritmo, até encher a FIFO; a origem espera `in_ready`.
3. 32 pacotes solicitados a cada 16 clocks.
4. Reset afirmado entre bordas com a FIFO ocupada; limpeza só na borda seguinte.

Uma fila de referências confere ordem, dados de 200 bits e CRC-16 de cada saída. O Transcript informa ocupação máxima e clocks de espera. **Não há resultados de simulação RTL incluídos neste pacote:** execute os comandos no ModelSim e preserve o Transcript para a apresentação ao grupo.

## Notas para discussão

- A origem deve obedecer a `in_ready`. O futuro Parser precisa ter como interromper ou reter pacotes; caso contrário, deve-se definir explicitamente uma política de descarte.
- A FIFO absorve rajadas, mas não aumenta a taxa sustentada da Hash. Se a taxa de chegada exceder a de saída indefinidamente, a origem ficará em espera.
- A FIFO não controla a saída da Hash em direção ao Controller. O Controller atual só captura `hash_valid` em `IDLE`; testar esse trecho separadamente antes da integração completa.
- Uma mudança futura na Hash por pipeline altera a taxa de serviço e exige nova avaliação da profundidade.
