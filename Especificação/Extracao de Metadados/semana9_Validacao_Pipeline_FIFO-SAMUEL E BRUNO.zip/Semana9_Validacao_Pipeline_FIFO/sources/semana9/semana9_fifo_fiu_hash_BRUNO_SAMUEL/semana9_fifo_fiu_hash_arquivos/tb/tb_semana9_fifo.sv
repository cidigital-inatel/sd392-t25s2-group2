`timescale 1ns/1ps
`default_nettype none

module tb_semana9_fifo;
    logic clk = 0;
    always #5 clk = ~clk;
    logic reset = 1;
    logic in_valid = 0;
    logic [31:0] src_ip_in = 0, dst_ip_in = 0;
    logic [15:0] src_port_in = 0, dst_port_in = 0;
    logic [7:0] protocol_in = 0;
    logic [15:0] packet_length_in = 0;
    logic [79:0] timestamp_in = 0;
    wire in_ready, hash_valid, fifo_full, fifo_empty;
    wire [15:0] hash_index, packet_length;
    wire [103:0] flow_key;
    wire [79:0] timestamp;
    wire [3:0] fifo_occupancy;

    fiu_hash_top #(.FIFO_DEPTH(8)) dut (.*);

    logic [103:0] expected_key [0:255];
    logic [15:0] expected_length [0:255];
    logic [79:0] expected_timestamp [0:255];
    integer accepted = 0, checked = 0, max_occupancy = 0, wait_cycles = 0;
    integer cycles = 0;

    function automatic logic [15:0] reference_crc(input logic [103:0] key);
        logic [15:0] crc;
        crc = 16'hffff;
        for (integer b = 12; b >= 0; b = b - 1) begin
            crc = crc ^ {key[b*8 +: 8], 8'h00};
            for (integer bit_no = 0; bit_no < 8; bit_no = bit_no + 1)
                crc = crc[15] ? (crc << 1) ^ 16'h1021 : crc << 1;
        end
        return crc;
    endfunction

    // Observa saidas apos a atualizacao dos registradores da borda.
    always @(posedge clk) begin
        #1;
        cycles = cycles + 1;
        if (!reset) begin
            if (fifo_occupancy > max_occupancy)
                max_occupancy = fifo_occupancy;
            if (hash_valid) begin
                if (checked >= accepted)
                    $fatal(1, "Hash produziu resultado sem entrada aceita");
                if (flow_key !== expected_key[checked] ||
                    packet_length !== expected_length[checked] ||
                    timestamp !== expected_timestamp[checked] ||
                    hash_index !== reference_crc(expected_key[checked]))
                    $fatal(1, "Dados, ordem ou CRC divergentes no pacote %0d", checked);
                checked = checked + 1;
            end
        end
    end

    task automatic send_packet(input integer id, input integer gap);
        begin
            @(negedge clk);
            while (!in_ready) begin
                wait_cycles = wait_cycles + 1;
                @(negedge clk);
            end
            src_ip_in = 32'h0a000000 + id;
            dst_ip_in = 32'hc0a80001 + id;
            src_port_in = 16'd1000 + id;
            dst_port_in = 16'd8000 + id;
            protocol_in = (id % 2) ? 8'd17 : 8'd6;
            packet_length_in = 16'd60 + id;
            timestamp_in = {48'(id + 100), 32'(id * 1000)};
            expected_key[accepted] = {src_ip_in, dst_ip_in,
                                      src_port_in, dst_port_in, protocol_in};
            expected_length[accepted] = packet_length_in;
            expected_timestamp[accepted] = timestamp_in;
            in_valid = 1;
            accepted = accepted + 1;
            @(negedge clk);
            in_valid = 0;
            repeat (gap - 2) @(negedge clk);
        end
    endtask

    task automatic drain_and_report(input integer total, input integer gap);
        integer timeout;
        begin
            timeout = 0;
            while ((checked < accepted || !fifo_empty) && timeout < 5000) begin
                @(negedge clk);
                timeout = timeout + 1;
            end
            if (checked != total || accepted != total || !fifo_empty)
                $fatal(1, "Timeout/perda: esperado=%0d aceito=%0d conferido=%0d", total, accepted, checked);
            $display("PASSOU: %0d pacotes; intervalo solicitado=%0d clocks; profundidade=8; ocupacao_max=%0d; espera_origem=%0d clocks; perdidos=0",
                     total, gap, max_occupancy, wait_cycles);
        end
    endtask

    task automatic start_case;
        begin
            @(negedge clk);
            reset = 1;
            in_valid = 0;
            @(posedge clk);
            #1;
            if (!fifo_empty || fifo_occupancy !== 0 || hash_valid)
                $fatal(1, "Reset sincrono nao limpou a interface");
            @(negedge clk);
            accepted = 0;
            checked = 0;
            max_occupancy = 0;
            wait_cycles = 0;
            reset = 0;
        end
    endtask

    initial begin : scenarios
        integer i;
        repeat (2) @(negedge clk);
        start_case();
        for (i = 0; i < 8; i = i + 1) send_packet(i, 3);
        drain_and_report(8, 3);

        start_case();
        for (i = 0; i < 32; i = i + 1) send_packet(i, 3);
        drain_and_report(32, 3);
        if (max_occupancy != 8 || wait_cycles == 0)
            $fatal(1, "Cenario de FIFO cheia nao ocorreu");

        start_case();
        for (i = 0; i < 32; i = i + 1) send_packet(i, 16);
        drain_and_report(32, 16);

        start_case();
        for (i = 0; i < 12; i = i + 1) send_packet(i, 3);
        if (fifo_empty) $fatal(1, "Reset nao foi testado com fila ocupada");
        // Afirmar fora da borda e conferir que a ocupacao nao mudou ainda.
        #1 reset = 1;
        #1;
        if (fifo_empty) $fatal(1, "Reset atuou antes da borda de subida");
        @(posedge clk);
        #1;
        if (!fifo_empty || fifo_occupancy !== 0 || hash_valid)
            $fatal(1, "Reset durante rajada falhou");
        $display("PASSOU: reset sincrono ativo alto durante ocupacao");
        @(negedge clk);
        reset = 0;
        repeat (20) @(negedge clk);
        if (hash_valid || !fifo_empty)
            $fatal(1, "Dados antigos reapareceram apos reset");
        $display("TODOS OS CENARIOS DA FIFO PASSARAM");
        $finish;
    end

    initial begin
        #1000000;
        $fatal(1, "Timeout global da testbench");
    end
endmodule

`default_nettype wire
