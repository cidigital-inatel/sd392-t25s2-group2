`timescale 1ns/1ps
`default_nettype none

module flow_fifo #(
    parameter integer DEPTH = 8,
    parameter integer PTR_W = (DEPTH > 1 ? $clog2(DEPTH) : 1),
    parameter integer COUNT_W = $clog2(DEPTH + 1)
) (
    input  wire logic clk,
    input  wire logic reset,
    input  wire logic [199:0] in_data,
    input  wire logic in_valid,
    output      logic in_ready,
    output      logic [199:0] out_data,
    output      logic out_valid,
    input  wire logic out_ready,
    output      logic full,
    output      logic empty,
    output      logic [COUNT_W-1:0] occupancy
);
    logic [199:0] mem [0:DEPTH-1];
    logic [PTR_W-1:0] rd_ptr, wr_ptr;
    logic do_read, do_write;

    assign empty = (occupancy == 0);
    assign full = (occupancy == DEPTH);
    assign out_valid = !empty && !reset;
    assign do_read = out_valid && out_ready;
    // Mesmo cheia, uma leitura simultanea libera lugar para uma escrita.
    assign in_ready = (!full || do_read) && !reset;
    assign do_write = in_valid && in_ready;
    assign out_data = mem[rd_ptr];

    always_ff @(posedge clk) begin
        if (reset) begin
            rd_ptr <= '0;
            wr_ptr <= '0;
            occupancy <= '0;
        end else begin
            if (do_read)
                rd_ptr <= (rd_ptr == DEPTH-1) ? '0 : rd_ptr + 1'b1;
            if (do_write) begin
                mem[wr_ptr] <= in_data;
                wr_ptr <= (wr_ptr == DEPTH-1) ? '0 : wr_ptr + 1'b1;
            end
            case ({do_write, do_read})
                2'b10: occupancy <= occupancy + 1'b1;
                2'b01: occupancy <= occupancy - 1'b1;
                default: ;
            endcase
        end
    end
endmodule

`default_nettype wire
