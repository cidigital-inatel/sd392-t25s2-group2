# Flow Identification Unit (FIU)

Flow Identification Unit (FIU)
Em arquitetura pipeline

Documentação funcional e estrutural do módulo flow_identification_unit_pipeline

# Resumo das características

| Característica | Descrição |

| --- | --- |

| Entradas principais | src_ip (32 bits), dst_ip (32 bits), src_port (16 bits), dst_port (16 bits) e protocol (8 bits) |

| Chave gerada | flow_key de 104 bits (13 bytes), formada pela concatenação dos cinco campos |

| Metadados propagados | packet_length (16 bits) e timestamp (80 bits) |

| Arquitetura | Pipeline de um estágio registrado |

| Latência de referência | 1 ciclo, conforme a convenção de contagem adotada no testbench |

| Intervalo de iniciação | II = 1 ciclo |

| Reset | Síncrono, ativo em nível alto (reset=1) |

| Validação de referência | 181 transações na simulação isolada da FIU, conforme os testes de referência do projeto |

# 1. Objetivo

O módulo flow_identification_unit_pipeline reúne os campos que identificam um fluxo de rede em uma única chave de 104 bits (flow_key) e propaga, junto com ela, o comprimento do pacote (packet_length) e o timestamp associado à transação.

A FIU foi implementada como uma pipeline de um estágio. Em cada borda positiva do clock, quando in_valid está em nível alto e reset está desativado, os campos de entrada são capturados e publicados nas saídas registradas. A unidade aceita uma nova transação a cada ciclo, portanto seu intervalo de iniciação é II=1.

# 2. Interface

module flow_identification_unit_pipeline (
    input  wire logic         clk,
    input  wire logic         reset,

    input  wire logic [31:0]  src_ip_in,
    input  wire logic [31:0]  dst_ip_in,
    input  wire logic [15:0]  src_port_in,
    input  wire logic [15:0]  dst_port_in,
    input  wire logic [7:0]   protocol_in,
    input  wire logic [15:0]  packet_length_in,
    input  wire logic [79:0]  timestamp_in,

    input  wire logic         in_valid,

    output logic [103:0]     flow_key_out,
    output logic [15:0]      packet_length_out,
    output logic [79:0]      timestamp_out,
    output logic             out_valid
);

| Sinal | Largura | Descrição |

| --- | --- | --- |

| clk | 1 | Clock do circuito. A lógica sequencial é acionada na borda positiva. |

| reset | 1 | Reset síncrono ativo em alto. Quando amostrado em 1 na borda positiva, zera as saídas e limpa out_valid. |

| src_ip_in | 32 | Endereço IP de origem. |

| dst_ip_in | 32 | Endereço IP de destino. |

| src_port_in | 16 | Porta de origem. |

| dst_port_in | 16 | Porta de destino. |

| protocol_in | 8 | Identificador do protocolo. |

| packet_length_in | 16 | Comprimento do pacote associado à chave. |

| timestamp_in | 80 | Timestamp associado ao pacote. |

| in_valid | 1 | Indica que os campos de entrada representam uma nova transação válida na borda positiva. |

| flow_key_out | 104 | Chave de fluxo formada pela concatenação dos cinco campos de identificação. |

| packet_length_out | 16 | Comprimento do pacote registrado e propagado. |

| timestamp_out | 80 | Timestamp registrado e propagado. |

| out_valid | 1 | Indica que as saídas foram atualizadas com uma nova transação válida. |

# 3. Formação da flow_key

A FIU não calcula hash nem realiza busca na tabela de fluxos. Sua função é organizar os campos recebidos do parser em um vetor único, mantendo a ordem definida pela arquitetura:

flow_key_out = {
    src_ip_in,
    dst_ip_in,
    src_port_in,
    dst_port_in,
    protocol_in
};

| Campo | Largura | Posição na flow_key |

| --- | --- | --- |

| src_ip | 32 bits | [103:72] |

| dst_ip | 32 bits | [71:40] |

| src_port | 16 bits | [39:24] |

| dst_port | 16 bits | [23:8] |

| protocol | 8 bits | [7:0] |

| Total | 104 bits | [103:0] |

A concatenação preserva a distinção entre a direção de origem e destino. Portanto, a chave A→B é diferente da chave B→A, conforme a estratégia de uniflow adotada no projeto.

# 4. Organização interna da pipeline

A FIU possui um único estágio de armazenamento. Não há arrays de pipeline, lógica de cálculo intermediário ou máquina de estados. O bloco always_ff registra a chave concatenada e os metadados na mesma borda de clock.

always_ff @(posedge clk) begin
    if (reset) begin
        flow_key_out      <= '0;
        packet_length_out <= '0;
        timestamp_out     <= '0;
        out_valid         <= 1'b0;
    end else begin
        out_valid <= in_valid;

        if (in_valid) begin
            flow_key_out <= {
                src_ip_in,
                dst_ip_in,
                src_port_in,
                dst_port_in,
                protocol_in
            };

            packet_length_out <= packet_length_in;
            timestamp_out     <= timestamp_in;
        end
    end
end

As atribuições não bloqueantes (<=) fazem com que os registradores sejam atualizados simultaneamente na borda positiva. A chave e os metadados pertencentes à mesma transação são, assim, publicados juntos.

# 5. Funcionamento do estágio

## 5.1 Captura de uma transação válida

Quando reset=0 e in_valid=1 na borda positiva, a FIU captura os cinco campos que formam flow_key, além de packet_length e timestamp. Na mesma atualização, out_valid recebe 1.

Cada ciclo com in_valid=1 representa uma transação independente. Se in_valid permanecer alto por vários ciclos, a FIU captura uma nova transação em cada borda positiva. Os dados podem mudar entre esses ciclos, permitindo fluxo contínuo de pacotes.

## 5.2 Ciclos sem entrada válida

Quando reset=0 e in_valid=0, out_valid recebe 0. Os registradores de dados não são atualizados e, portanto, flow_key_out, packet_length_out e timestamp_out mantêm os valores da última transação capturada. Esses valores antigos não representam uma nova transação quando out_valid=0 e devem ser ignorados pelo consumidor.

## 5.3 Reset

O reset é síncrono e ativo em nível alto. Isso significa que sua ativação só produz efeito na borda positiva do clock. Quando reset=1 nessa borda, a FIU zera flow_key_out, packet_length_out e timestamp_out, além de limpar out_valid.

Como a FIU contém apenas um estágio registrado, o reset elimina a validade da transação que seria publicada naquele estágio. A lógica não possui sinal de ready ou mecanismo de backpressure.

# 6. Latência, II e capacidade

| Propriedade | Valor / comportamento |

| --- | --- |

| Latência de referência | 1 ciclo, conforme a convenção de observação usada no testbench do projeto. |

| Intervalo de iniciação (II) | 1 ciclo. |

| Taxa máxima teórica em regime | Uma transação por ciclo. |

| Estágios registrados | 1. |

| Backpressure | Não há sinal ready; o consumidor deve aceitar cada ciclo em que out_valid=1. |

Latência e intervalo de iniciação representam propriedades diferentes. A latência indica o tempo entre a aceitação de uma transação e sua disponibilização na saída. O II indica o intervalo mínimo entre a aceitação de transações consecutivas. Assim, a FIU pode ter latência de um ciclo e, simultaneamente, aceitar uma nova transação em todos os ciclos.

A contagem exata de latência depende da convenção usada para identificar a borda de aceitação e a borda em que out_valid é observado pelo testbench. O valor de referência deve ser interpretado segundo essa convenção.

# 7. Comportamento temporal ilustrativo

| Borda de clock | in_valid | Entrada | Comportamento após a borda |

| --- | --- | --- | --- |

| N | 1 | Transação A | Registra A e ativa out_valid. |

| N+1 | 1 | Transação B | Registra B; out_valid continua ativo para a nova transação. |

| N+2 | 0 | Sem transação | out_valid é desativado; dados de saída mantêm B. |

| N+3 | 1 | Transação C | Registra C e ativa out_valid novamente. |

O exemplo ilustra o comportamento de uma entrada contínua e de uma lacuna. A saída de dados só deve ser consumida quando out_valid estiver ativo.

# 8. Integração com a Hash Unit

Na arquitetura do projeto, a FIU antecede a Hash Unit. A saída flow_key_out da FIU é conectada à entrada flow_key_in da Hash Unit. Os metadados packet_length_out e timestamp_out também são encaminhados às respectivas entradas da Hash Unit. O sinal out_valid da FIU funciona como in_valid da Hash Unit.

// Conexão conceitual FIU -> Hash Unit
.flow_key_in       (fiu_flow_key),
.packet_length_in  (fiu_packet_length),
.timestamp_in      (fiu_timestamp),
.in_valid          (fiu_valid)

Como a FIU e a Hash Unit operam com II=1, a conexão permite que a Hash Unit receba uma nova chave a cada ciclo válido da FIU. Não é necessário inserir ciclos de espera entre transações consecutivas. O consumidor deve acompanhar out_valid e não interpretar dados mantidos nas saídas durante ciclos inválidos.

A convenção de reset deve ser uniforme na integração. A FIU documentada utiliza reset síncrono ativo alto; a Hash Unit de referência também utiliza reset síncrono ativo alto.

# 9. Considerações de verificação

A verificação funcional da FIU deve conferir a concatenação dos cinco campos, a propagação correta de packet_length e timestamp, o alinhamento desses dados com out_valid e o comportamento em ciclos consecutivos de in_valid.

| Caso de teste | Verificação esperada |

| --- | --- |

| Transação isolada | A chave e os metadados de saída correspondem aos valores aplicados na entrada. |

| Transações consecutivas | Cada borda positiva com in_valid=1 produz uma nova transação válida, sem perdas ou duplicações. |

| Intervalos entre transações | out_valid fica inativo nos ciclos sem entrada válida; dados de saída podem permanecer estáveis. |

| in_valid prolongado | Uma transação é capturada por ciclo válido, e não apenas uma por período contínuo de nível alto. |

| Reset | As saídas são zeradas e out_valid é desativado na borda positiva em que reset=1. |

| Integração com Hash | A Hash Unit recebe a chave e os metadados correspondentes quando fiu_valid/out_valid está ativo. |

Os testes devem observar a interface pública do módulo. Como a FIU não expõe sinais internos de captura ou estados de controle, a verificação deve se concentrar nos sinais de entrada e saída.

# 10. Limitações e observações

A FIU apenas concatena e registra os campos recebidos. Ela não valida endereços, portas ou protocolos, não identifica se um fluxo já existe, não calcula hash e não acessa a Flow Table. Essas responsabilidades pertencem a outros blocos da arquitetura.

O módulo não possui sinal ready. Portanto, pressupõe-se que a lógica anterior consiga fornecer os campos de cada pacote nos ciclos em que in_valid é apresentado e que o estágio seguinte consiga aceitar cada transação válida.

# 11. Resumo

A flow_identification_unit_pipeline é um bloco combinador de campos seguido de um estágio registrado. Sua função é formar a flow_key de 104 bits e propagar packet_length e timestamp, mantendo os metadados associados à mesma transação. Com reset síncrono ativo alto, latência de referência de um ciclo e II=1, a FIU permite alimentar continuamente a Hash Unit sem inserir ciclos de espera entre pacotes.