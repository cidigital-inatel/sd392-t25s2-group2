Hash Unit em arquitetura pipeline

  -----------------------------------------------------------------------
  Característica                      Descrição
  ----------------------------------- -----------------------------------
  Entrada                             flow_key de 104 bits (13 bytes)

  Algoritmo                           CRC-16/CCITT-FALSE: polinômio
                                      0x1021, INIT 0xFFFF

  Arquitetura                         13 estágios de processamento, um
                                      byte por estágio

  Latência observada                  15 ciclos na simulação de
                                      referência

  Intervalo de iniciação              II = 1 ciclo

  Metadados propagados                packet_length (16 bits) e timestamp
                                      (80 bits)

  Reset                               Síncrono, ativo em nível alto
                                      (reset=1)

  Validação de referência             181 transações na simulação isolada
                                      da Hash Unit
  -----------------------------------------------------------------------

# 1. Objetivo

O módulo hash_unit_pipeline calcula um índice de 16 bits a partir da
flow_key de 104 bits, utilizando CRC-16/CCITT-FALSE. A chave original, o
comprimento do pacote e o timestamp são propagados junto com o resultado
para manter a associação entre os metadados e a transação.

A arquitetura é pipeline: aceita uma nova transação em cada ciclo em que
in_valid=1 (II=1), mesmo que cada transação leve vários ciclos para
alcançar a saída.

# 2. Interface

\`\`\`systemverilog module hash_unit_pipeline ( input wire logic clk,
input wire logic reset, input wire logic \[103:0\] flow_key_in, input
wire logic \[15:0\] packet_length_in, input wire logic \[79:0\]
timestamp_in, input wire logic in_valid, output logic \[15:0\]
hash_index_out, output logic \[103:0\] flow_key_out, output logic
\[15:0\] packet_length_out, output logic \[79:0\] timestamp_out, output
logic out_valid );

  -----------------------------------------------------------------------
  Sinal                   Largura                 Descrição
  ----------------------- ----------------------- -----------------------
  clk                     1                       Clock do circuito.

  reset                   1                       Reset síncrono ativo em
                                                  alto. Quando amostrado
                                                  em 1 na borda de
                                                  subida, limpa/
                                                  inicializa os
                                                  registradores.

  flow_key_in             104                     Chave de fluxo que será
                                                  processada.

  packet_length_in        16                      Comprimento do pacote.

  timestamp_in            80                      Timestamp associado ao
                                                  pacote.

  in_valid                1                       Indica entrada válida
                                                  na borda de subida.

  hash_index_out          16                      CRC final de 16 bits.

  flow_key_out            104                     Chave original
                                                  propagada.

  packet_length_out       16                      Comprimento propagado.

  timestamp_out           80                      Timestamp propagado.

  out_valid               1                       Indica que as saídas
                                                  representam uma nova
                                                  transação válida.
  -----------------------------------------------------------------------

# 3. Organização interna da pipeline

logic \[103:0\] key_pipe \[0:13\]; logic \[15:0\] length_pipe \[0:13\];
logic \[79:0\] timestamp_pipe \[0:13\]; logic \[15:0\] crc_pipe
\[0:13\]; logic valid_pipe \[0:13\];

  Array            Função
  ---------------- -------------------------------------------------
  key_pipe         Propaga a flow_key ao longo dos estágios.
  length_pipe      Propaga o comprimento do pacote.
  timestamp_pipe   Propaga o timestamp.
  crc_pipe         Armazena o estado intermediário do CRC.
  valid_pipe       Marca quais posições contêm transações válidas.

A posição 0 captura a entrada; as posições 1 a 13 correspondem ao avanço
pelos estágios de processamento. Os dados, metadados e bits de validade
avançam em conjunto.

# 4. Cálculo CRC-16/CCITT-FALSE

A função crc16_next_byte recebe o CRC parcial e um byte. O processamento
usa os seguintes parâmetros:

  Parâmetro   Valor
  ----------- -----------
  Largura     16 bits
  Polinômio   0x1021
  INIT        0xFFFF
  REFIN       false
  REFOUT      false
  XOROUT      0x0000
  Ordem       MSB-first

\`\`\`systemverilog value = crc \^ {data_byte, 8'h00};

for (int bit_index = 0; bit_index \< 8; bit_index++) begin if
(value\[15\]) value = (value \<\< 1) \^ 16'h1021; else value = value
\<\< 1; end

O byte é colocado na metade mais significativa do vetor de 16 bits e
combinado por XOR com o CRC anterior. Em seguida, são realizadas oito
iterações: deslocamento à esquerda e, quando o bit mais significativo
era 1, XOR com o polinômio 0x1021.

A função atualiza um byte por chamada. Os 13 bytes da chave são
processados pelos 13 estágios físicos descritos no generate.

# 5. Estágio de entrada e estágios CRC

## 5.1 Captura inicial

\`\`\`systemverilog always_ff @(posedge clk) begin if (reset) begin
key_pipe\[0\] \<= '0; length_pipe\[0\] \<= '0; timestamp_pipe\[0\] \<=
'0; crc_pipe\[0\] \<= 16'hFFFF; valid_pipe\[0\] \<= 1'b0; end else begin
valid_pipe\[0\] \<= in_valid; if (in_valid) begin key_pipe\[0\] \<=
flow_key_in; length_pipe\[0\] \<= packet_length_in; timestamp_pipe\[0\]
\<= timestamp_in; crc_pipe\[0\] \<= 16'hFFFF; end end end

Quando reset=1, a posição inicial é reinicializada. Em operação normal,
valid_pipe\[0\] acompanha in_valid. Cada ciclo com in_valid=1 captura
uma transação; não é necessário inserir um ciclo inválido entre pacotes
consecutivos.

## 5.2 Estágios de processamento

generate for (genvar g = 0; g \< 13; g++) begin : g_crc_stage
\`\`\`systemverilog always_ff @(posedge clk) begin if (reset) begin
key_pipe\[g+1\] \<= '0; length_pipe\[g+1\] \<= '0; timestamp_pipe\[g+1\]
\<= '0; crc_pipe\[g+1\] \<= 16'hFFFF; valid_pipe\[g+1\] \<= 1'b0; end
else begin key_pipe\[g+1\] \<= key_pipe\[g\]; length_pipe\[g+1\] \<=
length_pipe\[g\]; timestamp_pipe\[g+1\] \<= timestamp_pipe\[g\];
crc_pipe\[g+1\] \<= crc16_next_byte( crc_pipe\[g\],
key_pipe\[g\]\[103-(g\*8) -: 8\] ); valid_pipe\[g+1\] \<=
valid_pipe\[g\]; end end end endgenerate

O generate cria 13 blocos de hardware na elaboração. Não é um laço
executado sequencialmente em um único ciclo. Cada estágio calcula um
byte e registra o resultado.

  g     Bits da flow_key
  ----- ------------------
  0     \[103:96\]
  1     \[95:88\]
  ...   ...
  12    \[7:0\]

A seleção percorre a chave do byte mais significativo ao menos
significativo. As atribuições não bloqueantes fazem cada estágio avançar
simultaneamente, permitindo que diferentes pacotes estejam em estágios
diferentes.

# 6. Estágio de saída

\`\`\`systemverilog always_ff @(posedge clk) begin if (reset) begin
hash_index_out \<= '0; flow_key_out \<= '0; packet_length_out \<= '0;
timestamp_out \<= '0; out_valid \<= 1'b0; end else begin out_valid \<=
valid_pipe\[13\]; if (valid_pipe\[13\]) begin hash_index_out \<=
crc_pipe\[13\]; flow_key_out \<= key_pipe\[13\]; packet_length_out \<=
length_pipe\[13\]; timestamp_out \<= timestamp_pipe\[13\]; end end end

A saída publica o CRC e os metadados quando valid_pipe\[13\]=1. Quando
out_valid=0, os valores de dados podem permanecer iguais aos do
resultado anterior e não devem ser interpretados como uma nova
transação.

# 7. Latência, II e capacidade

  -----------------------------------------------------------------------
  Propriedade                         Valor de referência
  ----------------------------------- -----------------------------------
  Latência da Hash Unit               15 ciclos (1 estágio captura, 13
                                      estágios CRC e 1 estágio saída)

  Intervalo de iniciação (II)         1 ciclo.

  Taxa máxima teórica em regime       Uma transação por ciclo.

  Backpressure                        Não há sinal ready; o consumidor
                                      deve aceitar cada ciclo válido.
  -----------------------------------------------------------------------

Latência é o tempo entre a aceitação de uma transação e sua saída. II é
o intervalo entre a aceitação de duas transações consecutivas. Assim,
latência de 15 ciclos não impede a entrada de um pacote por ciclo.
