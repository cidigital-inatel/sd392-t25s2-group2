`timescale 1ns/1ps
`default_nettype none

module hash_unit_pipeline (
    input  wire logic         clk,
    input  wire logic         reset,

    input  wire logic [103:0] flow_key_in,
    input  wire logic [15:0]  packet_length_in,
    input  wire logic [79:0]  timestamp_in,
    input  wire logic         in_valid,

    output logic [15:0]       hash_index_out,
    output logic [103:0]      flow_key_out,
    output logic [15:0]       packet_length_out,
    output logic [79:0]       timestamp_out,
    output logic              out_valid
);

    // -------------------------------------------------
    // Pipeline:
    // Estagio 0: captura da entrada
    // Estagios 1 a 13: processamento CRC
    // Estagio de saida: publicacao
    //
    // Throughput: uma transacao por ciclo (II = 1).
    // Cada ciclo com in_valid = 1 representa uma nova entrada.
    // -------------------------------------------------

    logic [103:0] key_pipe       [0:13];
    logic [15:0]  length_pipe    [0:13];
    logic [79:0]  timestamp_pipe [0:13];

    logic [15:0] crc_pipe   [0:13];
    logic        valid_pipe [0:13];

    // -------------------------------------------------
    // CRC-16/CCITT-FALSE
    // POLY   = 0x1021
    // INIT   = 0xFFFF
    // REFIN  = false
    // REFOUT = false
    // XOROUT = 0x0000
    // MSB-first
    // -------------------------------------------------

    function automatic logic [15:0] crc16_next_byte (
        input logic [15:0] crc,
        input logic [7:0]  data_byte
    );
        logic [15:0] value;

        begin
            value = crc ^ {data_byte, 8'h00};

            for (int bit_index = 0; bit_index < 8; bit_index++) begin
                if (value[15])
                    value = (value << 1) ^ 16'h1021;
                else
                    value = value << 1;
            end

            return value;
        end
    endfunction

    // -------------------------------------------------
    // Estagio 0: captura continua
    // -------------------------------------------------

    always_ff @(posedge clk) begin
        if (reset) begin
            key_pipe[0]       <= '0;
            length_pipe[0]    <= '0;
            timestamp_pipe[0] <= '0;
            crc_pipe[0]       <= 16'hFFFF;
            valid_pipe[0]     <= 1'b0;
        end else begin
            valid_pipe[0] <= in_valid;

            if (in_valid) begin
                key_pipe[0]       <= flow_key_in;
                length_pipe[0]    <= packet_length_in;
                timestamp_pipe[0] <= timestamp_in;
                crc_pipe[0]       <= 16'hFFFF;
            end
        end
    end

    // -------------------------------------------------
    // Estagios 1 a 13: processamento de um byte por estagio.
    // -------------------------------------------------

    generate
        for (genvar g = 0; g < 13; g++) begin : g_crc_stage

            always_ff @(posedge clk) begin
                if (reset) begin
                    key_pipe[g+1]       <= '0;
                    length_pipe[g+1]    <= '0;
                    timestamp_pipe[g+1] <= '0;
                    crc_pipe[g+1]       <= 16'hFFFF;
                    valid_pipe[g+1]     <= 1'b0;
                end else begin
                    key_pipe[g+1]       <= key_pipe[g];
                    length_pipe[g+1]    <= length_pipe[g];
                    timestamp_pipe[g+1] <= timestamp_pipe[g];

                    crc_pipe[g+1] <= crc16_next_byte(
                        crc_pipe[g],
                        key_pipe[g][103-(g*8) -: 8]
                    );

                    valid_pipe[g+1] <= valid_pipe[g];
                end
            end
        end
    endgenerate

    // -------------------------------------------------
    // Estagio de saida
    // -------------------------------------------------

    always_ff @(posedge clk) begin
        if (reset) begin
            hash_index_out     <= '0;
            flow_key_out       <= '0;
            packet_length_out  <= '0;
            timestamp_out      <= '0;
            out_valid          <= 1'b0;
        end else begin
            out_valid <= valid_pipe[13];

            if (valid_pipe[13]) begin
                hash_index_out    <= crc_pipe[13];
                flow_key_out      <= key_pipe[13];
                packet_length_out <= length_pipe[13];
                timestamp_out     <= timestamp_pipe[13];
            end
        end
    end

endmodule

`default_nettype wire