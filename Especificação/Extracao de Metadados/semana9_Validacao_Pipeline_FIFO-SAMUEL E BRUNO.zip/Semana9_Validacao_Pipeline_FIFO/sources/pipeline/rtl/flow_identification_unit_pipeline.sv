
`timescale 1ns/1ps
`default_nettype none

// FIU com pipeline de um estágio.
// Aceita uma nova transação por ciclo de clock (II = 1).
// Cada ciclo com in_valid = 1 representa uma nova transação.
// Reset síncrono ativo em nível alto.

module flow_identification_unit_pipeline (
    input wire logic         clk,
    input wire logic         reset,

    input wire logic [31:0]  src_ip_in,
    input wire logic [31:0]  dst_ip_in,
    input wire logic [15:0]  src_port_in,
    input wire logic [15:0]  dst_port_in,
    input wire logic [7:0]   protocol_in,
    input wire logic [15:0]  packet_length_in,
    input wire logic [79:0]  timestamp_in,

    input wire logic         in_valid,

    output logic [103:0]     flow_key_out,
    output logic [15:0]      packet_length_out,
    output logic [79:0]      timestamp_out,
    output logic             out_valid
);

    always_ff @(posedge clk) begin

        if (reset) begin

            flow_key_out      <= '0;
            packet_length_out <= '0;
            timestamp_out     <= '0;
            out_valid         <= 1'b0;

        end else begin

            out_valid <= in_valid;

            if (in_valid) begin

                flow_key_out <= {
                    src_ip_in,
                    dst_ip_in,
                    src_port_in,
                    dst_port_in,
                    protocol_in
                };

                packet_length_out <= packet_length_in;
                timestamp_out     <= timestamp_in;

            end

        end

    end

endmodule

`default_nettype wire