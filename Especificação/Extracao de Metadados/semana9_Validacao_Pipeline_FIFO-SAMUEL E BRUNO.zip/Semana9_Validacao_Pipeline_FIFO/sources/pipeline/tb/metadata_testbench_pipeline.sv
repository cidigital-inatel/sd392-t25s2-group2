`timescale 1ns/1ps
`default_nettype none

// Testbench de pipeline para FIU isolada (TEST_KIND=0), Hash isolada
// (TEST_KIND=1) ou FIU+Hash integradas (TEST_KIND=2). Inclui testes II=1,
// intervalos, resets e cancelamento. Golden externo, nao calculado no DUT.
module metadata_testbench_pipeline #(parameter int TEST_KIND = 2);
    localparam int MAX_VECTORS = 512;
    localparam int MAX_RECORDS = 1024;
    localparam int LATENCY = (TEST_KIND == 0) ? 1 : (TEST_KIND == 1) ? 15 : 16;
    logic clk, reset, in_valid;
    logic [31:0] src_ip_in, dst_ip_in;
    logic [15:0] src_port_in, dst_port_in, packet_length_in;
    logic [7:0] protocol_in;
    logic [79:0] timestamp_in;
    wire [103:0] input_key = {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in};
    wire [103:0] flow_key_out;
    wire [15:0] packet_length_out, hash_index_out;
    wire [79:0] timestamp_out;
    wire out_valid;
    wire fiu_start, hash_start, fiu_valid;
    wire [199:0] fiu_capture_data, hash_capture_data, fiu_data;

    generate
        if (TEST_KIND == 0) begin : g_fiu
            flow_identification_unit_pipeline dut (
                .clk,.reset,.src_ip_in,.dst_ip_in,.src_port_in,.dst_port_in,
                .protocol_in,.packet_length_in,.timestamp_in,.in_valid,
                .flow_key_out,.packet_length_out,.timestamp_out,.out_valid
            );
            assign hash_index_out = '0;
            // A FIU pipeline nao possui start nem registradores de captura
            // internos expostos: cada ciclo valido e uma transferencia.
            assign fiu_start = 1'b0;
            assign hash_start = 1'b0;
            assign fiu_valid = out_valid;
            assign fiu_capture_data = '0;
            assign hash_capture_data = '0;
            assign fiu_data = {flow_key_out,packet_length_out,timestamp_out};
        end else if (TEST_KIND == 1) begin : g_hash
            hash_unit_pipeline dut (
                .clk,.reset,.flow_key_in(input_key),.packet_length_in,.timestamp_in,
                .in_valid,.hash_index_out,.flow_key_out,.packet_length_out,.timestamp_out,.out_valid
            );
            assign fiu_start = 1'b0;

            // Cada ciclo com in_valid = 1 representa uma nova transacao.
            assign hash_start = in_valid;

            assign fiu_valid = 1'b0;
            assign fiu_capture_data = '0;

            // Dados apresentados na interface de entrada da Hash Unit.
            assign hash_capture_data = {input_key,packet_length_in,timestamp_in};

            assign fiu_data = '0;
        end else begin : g_chain
            fiu_hash_top dut (
                .clk,.reset,.src_ip_in,.dst_ip_in,.src_port_in,.dst_port_in,.protocol_in,
                .packet_length_in,.timestamp_in,.in_valid,.hash_index_out,.flow_key_out,
                .packet_length_out,.timestamp_out,.out_valid
            );
            // A FIU nova e um estagio registrado, sem start/captura internos.
            assign fiu_start = 1'b0;
            assign hash_start = dut.fiu_valid;
            assign fiu_valid = dut.fiu_valid;
            assign fiu_capture_data = '0;
            assign hash_capture_data = {dut.fiu_flow_key,dut.fiu_packet_length,dut.fiu_timestamp};
            assign fiu_data = {dut.fiu_flow_key,dut.fiu_packet_length,dut.fiu_timestamp};
        end
    endgenerate

    logic [215:0] vectors [0:MAX_VECTORS-1];
    // Scoreboard de software da simulacao. Nao existe FIFO no RTL.
    logic [215:0] expected [0:MAX_RECORDS-1];
    int capture_cycle [0:MAX_RECORDS-1];
    int vector_id [0:MAX_RECORDS-1];
    string record_phase [0:MAX_RECORDS-1];
    int clock_count, vector_count, active_vector;
    int read_ptr, write_ptr, stage_ptr;
    int accepted_total, delivered_total, cancelled_total;
    int fiu_transfers, hash_captures, max_pending;
    int start_checks, available_checks;
    int result_fd, stage_fd;
    logic previous_output_valid;
    logic source_event, hash_event;
    logic [199:0] expected_hash_capture;
    string phase, vector_file, results_file, stages_file, trace_file;
    string negative_mode;

    always #5 clk = ~clk;

    // Conferencia na mesma borda de leitura dos receptores, antes da NBA.
    always @(posedge clk) begin
        clock_count = clock_count + 1;
        source_event = 1'b0;
        hash_event = 1'b0;
        expected_hash_capture = '0;
        if (reset) begin
            if (write_ptr < read_ptr)
                $fatal(1,"Scoreboard inconsistente durante reset: write_ptr < read_ptr.");
            cancelled_total = cancelled_total + (write_ptr - read_ptr);
            write_ptr = 0;
            read_ptr = 0;
            stage_ptr = 0;
            previous_output_valid = 1'b0;
        end else begin
            // Em qualquer pipeline II=1, out_valid pode permanecer alto em ciclos consecutivos.
            previous_output_valid = out_valid;

            if (out_valid) begin
                if (read_ptr >= write_ptr)
                    $fatal(1,"Resultado duplicado ou sem entrada correspondente.");
                if ({flow_key_out,packet_length_out,timestamp_out} !== expected[read_ptr][215:16])
                    $fatal(1,"Chave ou metadados nao correspondem ao registro capturado.");
                if (TEST_KIND != 0 && hash_index_out !== expected[read_ptr][15:0])
                    $fatal(1,"CRC divergente: esperado=%04h obtido=%04h",expected[read_ptr][15:0],hash_index_out);
                if (clock_count-capture_cycle[read_ptr] != LATENCY)
                    $fatal(1,"Latencia divergente: esperada=%0d obtida=%0d",LATENCY,clock_count-capture_cycle[read_ptr]);
                delivered_total = delivered_total + 1;
                $fwrite(result_fd,"%0d,%s,%0d,%026h,%026h,%0d,%0d,%020h,%020h,",
                        delivered_total,record_phase[read_ptr],vector_id[read_ptr],
                        expected[read_ptr][215:112],flow_key_out,expected[read_ptr][111:96],packet_length_out,
                        expected[read_ptr][95:16],timestamp_out);
                if (TEST_KIND == 0) $fwrite(result_fd,"NA,NA,");
                else $fwrite(result_fd,"%04h,%04h,",expected[read_ptr][15:0],hash_index_out);
                $fwrite(result_fd,"%0d,%0d,%0d,%0.0f,PASS\n",capture_cycle[read_ptr],clock_count,
                        clock_count-capture_cycle[read_ptr],$realtime/1ns);
                read_ptr = read_ptr + 1;
            end

            // Todas as configuracoes suportadas (TEST_KIND=0, 1 ou 2)
            // aceitam uma nova transacao em cada borda positiva com in_valid=1.
            if (in_valid) begin
                source_event = 1'b1;
                if (write_ptr >= MAX_RECORDS)
                    $fatal(1,"Scoreboard excedeu o limite.");
                if ({input_key,packet_length_in,timestamp_in} !== vectors[active_vector][215:16])
                    $fatal(1,"Estimulo incoerente com o vetor esperado.");
                expected[write_ptr] = vectors[active_vector];
                capture_cycle[write_ptr] = clock_count;
                vector_id[write_ptr] = active_vector;
                record_phase[write_ptr] = phase;
                write_ptr = write_ptr + 1;
                accepted_total = accepted_total + 1;
                if (TEST_KIND == 1) begin
                    hash_event = 1'b1;
                    hash_captures = hash_captures + 1;
                    expected_hash_capture = vectors[active_vector][215:16];
                end
            end

            if (TEST_KIND != 1 && fiu_valid) begin
                if (stage_ptr >= write_ptr || fiu_data !== expected[stage_ptr][215:16])
                    $fatal(1,"Saida FIU duplicada ou concatencacao incorreta.");
                if (clock_count-capture_cycle[stage_ptr] != 1)
                    $fatal(1,"Transferencia FIU: latencia esperada=1 obtida=%0d.",
                           clock_count-capture_cycle[stage_ptr]);
                fiu_transfers = fiu_transfers + 1;
                $fwrite(stage_fd,"%0d,%0d,%0.0f,%026h,%0d,%020h,%0d\n",fiu_transfers,
                        clock_count,$realtime/1ns,fiu_data[199:96],fiu_data[95:80],fiu_data[79:0],vector_id[stage_ptr]);
                if (TEST_KIND == 2) begin
                    hash_event = 1'b1;
                    hash_captures = hash_captures + 1;
                    expected_hash_capture = fiu_data;
                end
                stage_ptr = stage_ptr + 1;
            end
            if (write_ptr-read_ptr > max_pending) max_pending=write_ptr-read_ptr;

            if (TEST_KIND == 2) begin
                // hash_start e hash_capture_data sao a interface FIU->Hash.
                // Conferir antes da NBA, no mesmo instante em que a Hash captura.
                if (hash_start !== hash_event)
                    $fatal(1,"Hash nao capturou a transferencia valida da FIU.");
                if (hash_event && hash_capture_data !== expected_hash_capture)
                    $fatal(1,"Hash recebeu dados diferentes dos publicados pela FIU.");
            end
        end

        #1;
        if (reset) begin
            if (out_valid !== 1'b0 || fiu_start !== 1'b0 || hash_start !== 1'b0)
                $fatal(1,"Reset nao limpou validade e starts.");
        end else begin
            if (TEST_KIND == 2) begin
                // A FIU pipeline nao expoe start nem registradores internos.
                // A transferencia e validada pelo fiu_valid e pelos dados de saida.
            end else if (TEST_KIND != 1 && TEST_KIND != 0) begin
                if (fiu_start !== source_event)
                    $fatal(1,"FIU start nao corresponde a captura unica do periodo alto.");
                if (source_event && fiu_capture_data !== expected[write_ptr-1][215:16])
                    $fatal(1,"FIU nao capturou os sete campos atomicamente.");
            end
            if (TEST_KIND == 1) begin
                if (hash_start !== hash_event)
                    $fatal(1,"Hash start nao corresponde a uma captura por ciclo valido.");
                if (hash_event && hash_capture_data !== expected_hash_capture)
                    $fatal(1,"Hash nao capturou todos os 200 bits de entrada.");
            end
            start_checks = start_checks + 1;
            if (read_ptr < write_ptr && clock_count-capture_cycle[read_ptr] == LATENCY-1) begin
                if (out_valid !== 1'b1)
                    $fatal(1,"Resultado nao foi disponibilizado no ciclo esperado.");
                available_checks = available_checks + 1;
            end
        end
    end

    // Reset sincrono ativo alto, coerente com as duas unidades pipeline.
    // Mantem o reset ativo por duas bordas positivas e libera em uma negedge.
    task automatic reset_dut;
        begin
            @(negedge clk);
            reset = 1'b1;
            in_valid = 1'b0;
            repeat (2) begin
                @(posedge clk);
                #2;
            end
            @(negedge clk);
            reset = 1'b0;
        end
    endtask

    task automatic drive_vector(input int id);
        @(negedge clk);
        active_vector=id;
        src_ip_in=vectors[id][215:184]; dst_ip_in=vectors[id][183:152];
        src_port_in=vectors[id][151:136]; dst_port_in=vectors[id][135:120];
        protocol_in=vectors[id][119:112]; packet_length_in=vectors[id][111:96];
        timestamp_in=vectors[id][95:16]; in_valid=1'b1;
        @(posedge clk); #2;
    endtask

    task automatic clear_input;
        @(negedge clk);
        in_valid=1'b0;
        // Altera os dados durante valid=0 para verificar que nao ha captura espuria.
        src_ip_in=~src_ip_in; dst_ip_in=~dst_ip_in;
        src_port_in=~src_port_in; dst_port_in=~dst_port_in;
        protocol_in=~protocol_in; packet_length_in=~packet_length_in; timestamp_in=~timestamp_in;
    endtask

    task automatic wait_cycles(input int cycles);
        repeat(cycles) begin @(posedge clk); #2; end
    endtask

    task automatic send_contiguous(input int first_id,input int count);
        for (int k=0;k<count;k++) begin
            @(negedge clk);
            active_vector=first_id+k;
            src_ip_in=vectors[first_id+k][215:184];
            dst_ip_in=vectors[first_id+k][183:152];
            src_port_in=vectors[first_id+k][151:136];
            dst_port_in=vectors[first_id+k][135:120];
            protocol_in=vectors[first_id+k][119:112];
            packet_length_in=vectors[first_id+k][111:96];
            timestamp_in=vectors[first_id+k][95:16];
            in_valid=1'b1;
            @(posedge clk); #2;
        end
        @(negedge clk);
        in_valid=1'b0;
    endtask

    // Envia transacoes separadas por exatamente gap ciclos entre capturas.
    // Cada captura e um unico ciclo de in_valid; nao ha semantica de start.
    task automatic send_spaced_group(input int first_id,input int count,input int gap);
        if (gap < 2) $fatal(1,"Gap deve ser de pelo menos 2 ciclos.");
        for (int k=0;k<count;k++) begin
            drive_vector(first_id+k);
            clear_input();
            if (k != count-1) wait_cycles(gap-1);
        end
    endtask

    // Reset sincrono ativo alto. A verificacao exige que ao menos min_cancel
    // transacoes ainda pendentes sejam contabilizadas como canceladas.
    task automatic reset_and_check_cancel(input int min_cancel,input string test_name);
        int cancelled_before;
        cancelled_before=cancelled_total;
        @(negedge clk);
        reset=1'b1;
        in_valid=1'b0;
        repeat(2) begin @(posedge clk); #2; end
        if ((cancelled_total-cancelled_before) < min_cancel)
            $fatal(1,"%s: reset cancelou %0d transacoes; minimo esperado=%0d.",
                   test_name,cancelled_total-cancelled_before,min_cancel);
        @(negedge clk);
        reset=1'b0;
    endtask

    task automatic drain;
        repeat(LATENCY+3) begin @(posedge clk); #2; end
        if (write_ptr != read_ptr)
            $fatal(1,"Existem %0d transacoes pendentes apos drain.",write_ptr-read_ptr);
    endtask

    // Suite de robustez executada depois do teste funcional principal.
    task automatic run_robustness_tests;
        int burst_count;
        int pending_before;
        begin
            // 1) Reset logo apos a borda de captura: a transacao entrou no DUT,
            // mas sua publicacao deve ser cancelada pelo reset seguinte.
            phase="reset_durante_captura";
            drive_vector(0);
            reset_and_check_cancel(1,"reset durante captura");
            drain();

            // 2) Reset no meio do processamento. Para pipelines de mais de um
            // ciclo, aguarda aproximadamente metade da latencia; na FIU de
            // latencia 1, o reset ocorre no primeiro ciclo posterior a captura.
            phase="reset_durante_processamento";
            drive_vector(1);
            if (LATENCY > 2) wait_cycles(LATENCY/2);
            reset_and_check_cancel(1,"reset durante processamento");
            drain();

            // 3) Reset imediatamente antes do ciclo previsto para publicacao.
            phase="reset_proximo_publicacao";
            drive_vector(2);
            if (LATENCY > 2) wait_cycles(LATENCY-2);
            reset_and_check_cancel(1,"reset proximo da publicacao");
            drain();

            // 4) in_valid alto por varios ciclos: cada ciclo representa uma
            // transacao diferente (II=1), e nao uma unica captura prolongada.
            phase="in_valid_prolongado_II1";
            burst_count=(vector_count < 24) ? vector_count : 24;
            send_contiguous(0,burst_count);
            drain();
            if (delivered_total < burst_count)
                $fatal(1,"Teste in_valid prolongado nao entregou todas as transacoes.");

            // 5) Transacoes isoladas com diferentes intervalos entre capturas.
            phase="intervalos_gap_2";
            send_spaced_group(0,3,2);
            phase="intervalos_gap_4";
            send_spaced_group(3,3,4);
            phase="intervalos_gap_7";
            send_spaced_group(6,3,7);
            drain();

            // 6) Cancelamento explicito de transacoes pendentes. Para a FIU
            // (latencia 1), uma transacao e suficiente; para Hash/cadeia,
            // enviamos uma pequena rajada para manter varias em voo.
            phase="cancelamento_transacoes_pendentes";
            if (LATENCY == 1) begin
                drive_vector(9);
            end else begin
                send_contiguous(9,4);
                wait_cycles(1);
            end
            pending_before=write_ptr-read_ptr;
            if (pending_before < 1)
                $fatal(1,"Teste de cancelamento nao criou transacoes pendentes.");
            reset_and_check_cancel(1,"cancelamento de transacoes pendentes");
            drain();

            $display("PASS: suite de robustez: resets em 3 momentos, valid prolongado, gaps e cancelamento.");
        end
    endtask

    initial begin : run_tests
        int fd;
        int burst_count;
        clk=1'b0; reset=1'b1; in_valid=1'b0;
        src_ip_in='0; dst_ip_in='0; src_port_in='0; dst_port_in='0;
        protocol_in='0; packet_length_in='0; timestamp_in='0;
        clock_count=0; vector_count=181; active_vector=0;
        read_ptr=0; write_ptr=0; stage_ptr=0;
        accepted_total=0; delivered_total=0; cancelled_total=0;
        fiu_transfers=0; hash_captures=0; max_pending=0;
        start_checks=0; available_checks=0;
        previous_output_valid=1'b0;
        source_event=1'b0; hash_event=1'b0; expected_hash_capture='0;
        phase="funcional_II1"; negative_mode="";

        // Caminho dos vetores permanece configuravel por +VECTORS.
        // Os tres arquivos de saida sao gravados na pasta validation.
        vector_file="../../../../../tb/hash_vectors.mem";
        results_file="../../../../../validation/obtidos.csv";
        stages_file="../../../../../validation/transferencias.csv";
        trace_file="../../../../../validation/integracao.vcd";
        if($value$plusargs("VECTORS=%s",vector_file)) begin end
        if($value$plusargs("COUNT=%d",vector_count)) begin end
        if($value$plusargs("RESULTS=%s",results_file)) begin end
        if($value$plusargs("STAGES=%s",stages_file)) begin end
        if($value$plusargs("TRACEFILE=%s",trace_file)) begin end
        if($value$plusargs("NEGATIVE=%s",negative_mode)) begin end

        if(vector_count<13 || vector_count>MAX_VECTORS)
            $fatal(1,"COUNT invalido: %0d.",vector_count);
        fd=$fopen(vector_file,"r");
        if(fd==0) $fatal(1,"Vetores ausentes: %s",vector_file);
        $fclose(fd);
        $readmemh(vector_file,vectors,0,vector_count-1);

        result_fd=$fopen(results_file,"w");
        stage_fd=$fopen(stages_file,"w");
        if(result_fd==0 || stage_fd==0)
            $fatal(1,"Nao foi possivel abrir os CSVs. Verifique se a pasta validation existe no diretorio de trabalho do XSim.");
        $fwrite(result_fd,"entrega,fase,vetor_id,flow_key_esperada_hex,flow_key_obtida_hex,packet_length_esperado,packet_length_obtido,timestamp_esperado_hex,timestamp_obtido_hex,hash_index_esperado_hex,hash_index_obtido_hex,ciclo_entrada,ciclo_saida,latencia_ciclos,tempo_saida_ns,status\n");
        $fwrite(stage_fd,"transferencia,ciclo,tempo_ns,flow_key_hex,packet_length,timestamp_hex,vetor_id\n");

        $display("Gerando arquivo VCD: %s", trace_file);
        $dumpfile(trace_file);
        $dumpvars(0);

        reset_dut();

        // TESTE FUNCIONAL PRINCIPAL: rajadas de 5, 100 e restantes vetores.
        // Cada ciclo valido e uma nova transacao (II=1).
        phase="rajada_II1_5";
        send_contiguous(0,(vector_count<5)?vector_count:5);
        wait_cycles(3);

        if (vector_count>5) begin
            phase="rajada_II1_100";
            burst_count=(vector_count-5<100)?(vector_count-5):100;
            send_contiguous(5,burst_count);
            wait_cycles(2);
        end
        if (vector_count>105) begin
            phase="rajada_II1_restante";
            send_contiguous(105,vector_count-105);
        end
        drain();

        if (accepted_total != vector_count || delivered_total != vector_count ||
            read_ptr != write_ptr || cancelled_total != 0)
            $fatal(1,"Teste funcional perdeu/duplicou transacoes: aceitas=%0d entregues=%0d canceladas=%0d.",
                   accepted_total,delivered_total,cancelled_total);
        if (TEST_KIND != 1 && fiu_transfers != vector_count)
            $fatal(1,"Quantidade de transferencias FIU divergente: %0d de %0d.",fiu_transfers,vector_count);
        if (TEST_KIND != 0 && hash_captures != vector_count)
            $fatal(1,"Quantidade de capturas Hash divergente: %0d de %0d.",hash_captures,vector_count);

        $display("PASS: teste funcional, TEST_KIND=%0d, %0d transacoes, II=1, latencia=%0d ciclo(s).",
                 TEST_KIND,vector_count,LATENCY);

        // Testes adicionais de robustez solicitados.
        run_robustness_tests();
        drain();

        if (accepted_total != delivered_total + cancelled_total)
            $fatal(1,"Contabilidade final inconsistente: aceitas=%0d entregues=%0d canceladas=%0d.",
                   accepted_total,delivered_total,cancelled_total);
        if (write_ptr != read_ptr)
            $fatal(1,"Ainda existem transacoes pendentes ao final.");

        $fclose(result_fd);
        $fclose(stage_fd);
        $display("SUMMARY TEST_KIND=%0d accepted=%0d delivered=%0d cancelled=%0d FIU=%0d Hash=%0d max_pending=%0d",
                 TEST_KIND,accepted_total,delivered_total,cancelled_total,
                 fiu_transfers,hash_captures,max_pending);
        $display("PASS: testbench pipeline completo, incluindo suite de robustez.");
        $finish;
    end

endmodule

`default_nettype wire