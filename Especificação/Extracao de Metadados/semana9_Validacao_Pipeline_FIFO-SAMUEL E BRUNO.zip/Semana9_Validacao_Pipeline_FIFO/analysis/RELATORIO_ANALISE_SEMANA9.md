# Análise técnica da Semana 9: pipeline, FIFOs e integração

Projeto SD392 - PROJETO 4 SAMUEL  
Data da análise: 25/11/2026  
Repositório analisado: `cidigital-inatel/sd392-t25s2-group2`  
Commit fixado: `1f1d1ab50e7b677a914ebf2781d5566e89844ddf`

## Decisão recomendada

Adotar como próxima integração a **FIU em pipeline + Hash em pipeline + FIFO de 216 bits antes do Controller**, com aceitação explícita pelo Controller, reserva de vagas para resultados em trânsito e finalização somente depois da drenagem. Manter a versão sequencial com duas FIFOs como alternativa funcional para comparar admissão, ocupação e processamento sob o mesmo tráfego simulado.

As duas soluções corrigidas passaram pelos ensaios funcionais completos. O pipeline permite admitir rajadas mais rapidamente; o Controller continua limitando a taxa sustentada. Como o usuário informou que o projeto deve ficar em simulação, a recomendação funcional pode ser concluída sem placa. A comparação de área e frequência física não faz parte deste escopo.

## 1. Materiais e método

Foram lidos o relatório Markdown, o transcript ModelSim e todos os RTLs/testbench do arquivo `semana9_fifo_fiu_hash_BRUNO_SAMUEL.zip`. Também foram obtidos, pelo GitHub, o ZIP `FIU_Hash_pipeline.zip`, os arquivos da integração `Integração/pcap_teste_2`, o PCAP P01-P14 e os RTLs atuais do Controller. O conteúdo dos dois Controllers coincide após normalização das quebras de linha.

O ZIP de pipeline contém RTL, documentos, testbench, VCD e CSVs. Seu CSV de resultados contém 214 entregas marcadas PASS, incluindo ensaios além dos 181 vetores funcionais. **Não contém relatório de utilização, temporização pós-implementação ou fechamento de frequência.**

As novas execuções usaram **Icarus Verilog 13.0**. Vivado e ModelSim não estavam instalados neste ambiente. Os resultados fornecidos foram reproduzidos em simulação RTL; não se trata de uma nova execução do Vivado, nem de ensaio em placa.

Para compatibilidade com o Icarus, a inicialização da Flow Table por assignment pattern foi substituída por um laço `initial` equivalente. A memória preserva 2^20 palavras de 32 bits e os mesmos sinais/tempos de leitura e escrita. Os originais foram preservados em `sources/`. O Controller de avaliação apenas expõe sua condição de prontidão; sua FSM e operações de memória foram mantidas.

O CRC foi conferido também por `binascii.crc_hqx` do Python, independente da função do RTL. As features foram comparadas com um modelo Python por fluxo, incluindo ordem de classificação, chaves, contagens, bytes, duração e preservação da entrada em caso de colisão. Não basta observar uma mensagem PASS: os eventos de entrada, Hash, captura do Controller, conclusão e features foram registrados em CSV.

Os testes integrados de 181 entradas reutilizam as chaves e comprimentos originais, com timestamps monotônicos gerados e normalizados. Os vetores originais completos, inclusive timestamps extremos, foram mantidos nos testes isolados fornecidos. A campanha com Parser usa bytes Ethernet reais do PCAP e quadros UDP sintéticos.

## 2. Reprodução dos ensaios fornecidos

### FIFO da Semana 9, antes da Hash sequencial

| Cenário | Pico da FIFO | Espera da origem | Resultado reproduzido |
|---|---:|---:|---|
| 8 entradas, intervalo solicitado de 3 clocks | 6 | 0 | Passou |
| 32 entradas, intervalo solicitado de 3 clocks | 8 | 263 clocks | Passou |
| 32 entradas, intervalo solicitado de 16 clocks | 1 | 0 | Passou |
| Reset síncrono, ativo alto, com fila ocupada | - | - | Passou |

Isso confirma o relatório do Bruno e Samuel dentro de seu escopo: FIU, FIFO e Hash. A ausência de perdas depende da origem aguardar `in_ready`. O Parser atual não oferece esse mecanismo.

### Pipeline fornecido

| Bloco | Vetores funcionais | Intervalo de iniciação | Latência na convenção do testbench |
|---|---:|---:|---:|
| FIU | 181 | 1 ciclo | 1 ciclo |
| Hash | 181 | 1 ciclo | 15 ciclos |
| FIU + Hash | 181 | 1 ciclo | 16 ciclos |

Os testes adicionais de reset, lacunas e `valid` consecutivo também passaram. As contagens de cancelamento após reset coincidem com os testes fornecidos: FIU 4, Hash 27 e cadeia 29. São cancelamentos deliberados de transações em trânsito.

O RTL da Hash tem captura, 13 estágios CRC e publicação. Assim, a latência de referência da Hash não é apenas 13 ciclos. Cada estágio processa um byte de uma chave diferente e conserva chave, comprimento, timestamp e validade alinhados.

## 3. Resultados integrados com os 181 vetores

| Arquitetura e condição | Entradas admitidas | Concluídas pelo Controller | Features | Resultado |
|---|---:|---:|---:|---|
| Pipeline direto, 1 entrada/ciclo | 181 | 1 | 1 | Perda na interface do Controller |
| FIU + FIFO 8 + Hash sequencial, sem FIFO após a Hash | 181 | 61 | 60 | Perda na interface do Controller |
| Pipeline + FIFO 256 + créditos | 181 | 181 | 179 | Correto; pico de 176 posições |
| Pipeline + FIFO 8 + créditos e origem aguardando | 181 | 181 | 179 | Correto; 6.678 clocks de espera |
| Sequencial + FIFO antes 8 + FIFO depois 8 + créditos | 181 | 181 | 179 | Correto; 5.961 clocks de espera |
| Pipeline + FIFO 8 sem reservar vagas | 181 | 13 | 12 | 168 resultados excederam a capacidade |

As duas versões corretas reproduziram **179 MISS, 1 HIT e 1 COLLISION**, além das 179 features esperadas. A colisão corresponde a um descarte intencional pela política da tabela, e não a uma perda de transporte entre módulos. O pacote do HIT atualizou o fluxo existente. O pacote em colisão não alterou o fluxo armazenado.

A versão com pipeline e FIFO 256 recebeu as 181 entradas em 181 clocks e concluiu o processamento em 7.218 clocks, contados da primeira admissão até a última conclusão. A versão sequencial com duas FIFOs concluiu em 7.220 clocks, mas a origem precisou de 6.502 clocks para entregar as entradas. Essa diferença mostra ganho de absorção de rajadas, enquanto a taxa final permanece limitada pelo Controller.

Uma FIFO de 176 posições foi suficiente, sem espera, para essa sequência específica. Com 175 posições, houve 25 clocks de espera e nenhum erro. Isso não estabelece 176 como profundidade adequada para qualquer tráfego.

## 4. Por que apenas conectar a FIFO não funciona

### 4.1 Contrato de `valid`

Na FIU e Hash em pipeline, cada borda com `valid=1` corresponde a uma transferência nova. Dois pacotes legítimos podem ter campos idênticos e ainda representar duas transferências. O consumidor deve contabilizar ambos. Não se deve exigir uma borda de subida de `valid` entre pacotes consecutivos.

Já o Controller atual espera `hash_valid` voltar a zero no estado `WAIT_VALID_LOW`. No ensaio de 32 entradas, ligar `fifo.out_valid` diretamente a `hash_valid` fez o Controller processar apenas a primeira e permanecer parado com **31 entradas na FIFO**. O teste atingiu seu limite de espera sem terminar a varredura.

Para preservar a FSM atual, a bancada expôs:

```systemverilog
controller_ready = (state == IDLE) && !scan_req && !rst;
fire             = fifo_valid && controller_ready;
fifo_rd_en       = fire;
controller_valid = fire;
```

Assim, a FIFO pode manter `out_valid=1`, enquanto o Controller recebe somente o pulso de transferência que efetivamente aceita. O adaptador não retira entradas durante ocupação. Uma futura conversão integral para `valid/ready` pode remover `WAIT_VALID_LOW`, desde que a alteração seja validada separadamente.

### 4.2 Resultados já em trânsito

O pipeline fornecido não tem `out_ready` nem mecanismo de parada. Olhar apenas `fifo_full` na saída é tarde demais: existem resultados futuros dentro da FIU/Hash.

A versão corrigida reserva uma vaga antes de admitir uma entrada. O contador representa pacotes admitidos que ainda não foram retirados da FIFO pelo Controller. A admissão só ocorre se houver crédito, incluindo uma retirada simultânea. A reserva é liberada na transferência ao Controller.

```text
reservas = ocupação da FIFO + resultados ainda em trânsito
reservas <= profundidade da FIFO
```

Essa é uma política conservadora: reserva espaço físico para todas as saídas futuras e pode reduzir a utilização de um pipeline longo quando a FIFO é pequena. Os ensaios com profundidades 1, 3 e 8 passaram com espera. Outra implementação possível é um pipeline elástico com propagação de `ready` por estágio, ainda não implementado nesta análise.

## 5. Testes com Parser e quadros completos

### PCAP P01-P08

Foram enviados os oito quadros do PCAP disponibilizado pelo grupo, com checagem independente dos metadados extraídos dos bytes Ethernet/IPv4/TCP/UDP.

| Caminho | Espaçamento adicional entre quadros | Concluídos | Features corretas |
|---|---:|---:|---:|
| Sequencial com FIFO antes da Hash, saída direta | 80 clocks | 8/8 | 4 |
| Pipeline direto ao Controller | 0 | 2/8 | Não |
| Pipeline + FIFO 8 após a Hash | 0 | 8/8 | 4 |
| Sequencial + duas FIFOs 8 | 0 | 8/8 | 4 |

Na versão pipeline + FIFO 8, o pico foi de seis entradas. As features conferidas foram: F1, 3 pacotes/152 bytes/500.000 ns; F2, 2/64/200.000 ns; F3, 2/124/900.000 ns; F4, 1/28/0 ns. O comprimento usado é o comprimento IPv4 extraído pelo Parser.

### Rajada de 256 quadros UDP de 64 bytes

O stream de 64 bits recebeu beats consecutivos, sem folga adicional entre quadros. Cada quadro ocupa oito clocks; a origem continua transmitindo independentemente da prontidão da etapa de metadados. Esse é um ensaio de rajada local da interface, não a reprodução de uma velocidade Ethernet específica com todos os intervalos de linha.

| Arquitetura | Concluídos | Não admitidos | Pico antes da Hash | Pico depois da Hash |
|---|---:|---:|---:|---:|
| Pipeline + FIFO após 256 | 256/256 | 0 | - | 205 |
| Sequencial + FIFO antes 8 e depois 8 | 68/256 | 188 | 8 | 8 |
| Sequencial + FIFO antes 256 e depois 8 | 256/256 | 0 | 197 | 8 |
| Pipeline + FIFO após 8 | 59/256 | 197 | - | 8 |

As soluções dimensionadas para a rajada geraram as 256 features corretas. O tempo de processamento foi de 10.257 clocks para a versão pipeline e 10.259 para a sequencial com buffers maiores, pela mesma convenção da campanha de metadados.

**Consequência:** o Parser atual tem `TVALID`, mas não tem `TREADY` nem prontidão na saída de metadados. Um `in_ready` na nova etapa não faz o Parser pausar sozinho. Quando não há vaga, a integração precisa reter o evento em algum ponto anterior, controlar uma origem que possa pausar ou contabilizar o descarte. A bancada mede explicitamente os eventos não admitidos; eles não são tratados como resultados corretos.

## 6. Gargalo medido e possibilidade de pipeline no Controller

Com a Flow Table disponibilizada, que responde a leitura/escrita no clock seguinte ao pedido:

| Resultado | Captura até `lookup_done`, observado pelo receptor | Intervalo mínimo entre capturas em sequência homogênea |
|---|---:|---:|
| MISS | 39 clocks | 40 clocks |
| HIT | 27 clocks | 28 clocks |
| COLLISION | 12 clocks | 13 clocks |

O limite de 40 clocks foi confirmado: 64 chaves distintas a cada 39 clocks resultaram em 32 capturas; a cada 40 clocks, todas as 64 foram processadas. Um ensaio de 512 entradas do mesmo fluxo conferiu 1 MISS, 511 HITs, `packet_count=512`, `byte_count=161536` e duração de 5 segundos e 110.000.000 ns nas duas versões corrigidas.

A memória não torna o Controller impossível de colocar em pipeline. O RTL atual serializa a leitura de várias palavras e a atualização do registro. Para admitir operações sobrepostas, seria necessário mudar a organização dos acessos e tratar dependências entre pacotes do mesmo fluxo, colisões, leituras/escritas concorrentes e a varredura. Isso representa outra mudança arquitetural. A decisão imediata mais simples é manter sua FSM serial e regular a entrada com FIFO e aceitação explícita.

Uma fila finita absorve uma diferença temporária de taxas. Se a chegada sustentada superar a capacidade de serviço, ela acabará impondo espera ou descarte. Para tráfego de novos fluxos, o limite observado é aproximadamente `f_clk / 40` pacotes por segundo, sob a latência de memória ensaiada.

## 7. Finalização e reset: falhas adicionais reproduzidas

### Fim da captura não é fim do processamento

Ao enviar `pcap_done` diretamente ao Controller em uma rajada de 32 entradas com fila, ele finalizou apenas o primeiro fluxo e terminou a varredura com **31 entradas ainda aguardando**. A correção ensaiada memoriza o fim da origem, bloqueia novas admissões e só encaminha o pedido de varredura quando não existem metadados pendentes na FIU/Hash, as FIFOs estão vazias e o Controller está pronto.

### Reset das filas não apaga a tabela

Um reset afirmado entre bordas, durante ocupação, preservou a ocupação até a borda seguinte; nessa borda, limpou uma FIFO com 16 posições ocupadas, além dos contadores de trânsito/crédito. Nenhum resultado antigo reapareceu após a limpeza.

O mesmo teste expôs uma limitação pré-existente da Flow Table: o reset limpa seus sinais de controle, mas não a memória. O Controller escreve W0=`valid=1` antes de terminar o restante da entrada. O reset foi aplicado durante essa escrita parcial; depois dele, W0 continuou válido, o registro estava incompleto e uma nova tentativa da mesma chave foi classificada como **COLLISION**.

Portanto, não se deve anunciar um reset global limpo apenas porque as FIFOs foram zeradas. É preciso definir recuperação da tabela: inicialização/invalidação dos valid bits antes de retomar a captura, marca de geração/época ou outro mecanismo de recuperação consistente. Publicar o valid bit somente após a conclusão da escrita pode proteger contra registros novos parcialmente gravados, mas não substitui a definição do tratamento de registros completos já existentes ou de HITs interrompidos.

## 8. Larguras, profundidades e recursos

| Fila | Campos | Largura por posição |
|---|---|---:|
| Antes da Hash | Chave 104 + comprimento 16 + timestamp 80 | 200 bits |
| Depois da Hash | Índice 16 + chave 104 + comprimento 16 + timestamp 80 | 216 bits |

A FIFO posterior de 256 posições guarda 55.296 bits de dados, sem contar controle. Uma FIFO anterior de oito posições guarda 1.600 bits. A implementação disponibilizada usa leitura combinacional da memória da FIFO; a inferência de BRAM não está comprovada. Migrar para leitura síncrona ou um IP de FIFO pode exigir adaptar o ciclo de entrega ao Controller.

O RTL da Hash em pipeline declara aproximadamente 3.255 bits de registradores de dados/CRC/validade, antes das otimizações; a FIU acrescenta 201. Isso não é uma contagem de FFs pós-síntese. O Controller/Flow Table atual modela 65.536 entradas com 16 palavras de 32 bits, ou 4 MiB de armazenamento; seu mapeamento físico também depende do alvo.

Para uma campanha definida, a fila precisa cobrir o pico da diferença entre chegadas e retiradas. Na reserva conservadora usada aqui, o limite inclui também entradas ainda dentro do pipeline. Para o projeto em simulação, é preciso declarar o perfil de rajadas, a latência da memória e a capacidade de pausar a origem. O clock físico não é necessário para comparar os resultados em ciclos. As profundidades 8, 176 e 256 deste relatório pertencem aos ensaios descritos.

## 9. Encaminhamento para o grupo

1. Integrar FIU e Hash em pipeline com FIFO de 216 bits antes do Controller. A FIFO entre FIU e Hash deixa de ser necessária apenas para compatibilizar a taxa desses dois blocos; outro propósito, como cruzamento de clock, exigiria análise própria.
2. Expor a prontidão do Controller e gerar a transferência somente quando houver `valid` e aceitação. Não ligar um `valid` mantido da FIFO diretamente à FSM atual.
3. Reservar espaço para todas as saídas em trânsito, ou implementar pipeline elástico completo. Fixar a política quando o Parser não puder pausar e registrar descartes.
4. Retardar a varredura até a drenagem e definir recuperação da tabela após reset interrompendo processamento.
5. Manter a variante sequencial com duas FIFOs como referência e apresentar as duas sob o mesmo tráfego simulado, comparando ciclos, ocupação e perdas. Eventual síntese para LUT, FF, BRAM e frequência pode ficar como trabalho futuro, sem bloquear a conclusão atual.

**Conclusão funcional para o escopo em simulação:** usar FIU e Hash em pipeline com FIFO de 216 bits antes do Controller, aceitação explícita, créditos e drenagem antes da varredura. Pipeline e FIFO são recursos complementares: o pipeline resolveu a taxa da Hash, enquanto a FIFO e o protocolo de aceitação resolveram o desacoplamento da memória. A versão sequencial com duas FIFOs permanece como comparação funcional.

## 10. Reexecução e evidências

O pacote inclui as fontes originais selecionadas, os protótipos de avaliação, testbenches, PCAP, vetores, eventos CSV, resultados JSON, logs e hashes SHA-256 das fontes. Não houve alteração nem publicação no repositório remoto.

Com Python 3 e Icarus Verilog 13 instalados:

```bash
python analysis/run_all.py
```

O estado final é gravado em `analysis/campaign_status.json`. A campanha inclui 13 comparações de metadados, oito com Parser, quatro complementares, os quatro testes fornecidos (FIFO e três configurações de pipeline) e a sondagem de reset. Alguns cenários são controles negativos intencionais: o sucesso da campanha significa que os candidatos corretos passaram e que as falhas descritas foram reproduzidas.

Os roteiros para ModelSim e XSim são fornecidos para reexecução pelo grupo e não foram executados neste ambiente. O protótipo de avaliação trabalha uma amostra por reset; não constitui uma substituição homologada do top de produção. O relatório não afirma fechamento temporal ou melhor utilização física.

### Referências do código

- [Pipeline enviado pelo grupo](https://github.com/cidigital-inatel/sd392-t25s2-group2/blob/1f1d1ab50e7b677a914ebf2781d5566e89844ddf/Especifica%C3%A7%C3%A3o/Extracao%20de%20Metadados/FIU_Hash_pipeline.zip).
- [Integração com Parser, Controller, Flow Table e Finalizer](https://github.com/cidigital-inatel/sd392-t25s2-group2/tree/1f1d1ab50e7b677a914ebf2781d5566e89844ddf/Integra%C3%A7%C3%A3o/pcap_teste_2).
- Arquivo anexado pelo usuário: `semana9_fifo_fiu_hash_BRUNO_SAMUEL.zip`, relatório e transcript de 24/11/2026.
