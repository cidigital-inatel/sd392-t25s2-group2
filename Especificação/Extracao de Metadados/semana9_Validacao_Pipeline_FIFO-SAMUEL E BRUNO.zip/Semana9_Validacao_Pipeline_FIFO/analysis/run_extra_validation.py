from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from run_validation import A,experiment

if __name__=='__main__':
    cases=[
        dict(label='pipeline_unique64_gap39_direct',mode=0,n=64,gap=39,data='unique512.mem',good=False),
        dict(label='pipeline_unique64_gap40_direct',mode=0,n=64,gap=40,data='unique512.mem'),
        dict(label='pipeline_181_depth176',mode=2,n=181,gap=1,depth=176),
        dict(label='pipeline_181_depth175',mode=2,n=181,gap=1,depth=175),
    ]
    results=[]
    for case in cases:
        results.append(experiment(**case))
        (A/'extra_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
