"""Check positive RTL experiments independently of the simulator backend."""
from pathlib import Path
import argparse
import binascii
import collections
import csv
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from run_validation import reference

def check(event_path,metadata_path,count,parser=False):
    requested=[]
    for line in Path(metadata_path).read_text().splitlines()[:count]:
        n=int(line,16)
        requested.append(dict(key=f'{n>>112:026x}',length=str((n>>96)&65535),
                              timestamp=f'{(n>>16)&((1<<80)-1):020x}'))
    assert len(requested)==count
    by=collections.defaultdict(list)
    for e in csv.DictReader(Path(event_path).open()):by[e['event']].append(e)
    fields=lambda e:(e['key'],int(e['length']),e['timestamp'])
    expected=[fields(e) for e in requested]
    for stage in (['PARSER'] if parser else [])+['SOURCE','HASH','CAPTURE']:
        assert [fields(e) for e in by[stage]]==expected,(stage,'lost, reordered or altered metadata')
    for e in by['HASH']:
        assert int(e['index'],16)==binascii.crc_hqx(int(e['key'],16).to_bytes(13,'big'),65535)
    golden,classes=reference(requested)
    assert [int(e['result']) for e in by['LOOKUP']]==classes,'Lookup classification mismatch'
    actual={int(e['feature'],16)>>144:int(e['feature'],16) for e in by['FEATURE']}
    assert len(by['FEATURE'])==len(actual)==len(golden),'Missing or repeated feature'
    assert actual==golden,'Feature mismatch'
    print(f'PASS: {count} metadata, {len(actual)} features, independent CRC and reference model')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('events');p.add_argument('metadata');p.add_argument('--count',type=int,required=True)
    p.add_argument('--parser',action='store_true')
    args=p.parse_args()
    check(args.events,args.metadata,args.count,args.parser)
