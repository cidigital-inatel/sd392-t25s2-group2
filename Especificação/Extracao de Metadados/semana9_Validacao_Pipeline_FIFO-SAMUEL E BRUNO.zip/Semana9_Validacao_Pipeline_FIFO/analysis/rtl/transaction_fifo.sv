`timescale 1ns/1ps
`default_nettype none

// Width-parameterized form of the Week 9 FIFO. One clock domain.
module transaction_fifo #(
    parameter integer WIDTH=216,
    parameter integer DEPTH=8,
    parameter integer PTR_W=(DEPTH>1 ? $clog2(DEPTH) : 1),
    parameter integer COUNT_W=$clog2(DEPTH+1)
)(
    input wire clk, reset,
    input wire [WIDTH-1:0] in_data,
    input wire in_valid,
    output wire in_ready,
    output wire [WIDTH-1:0] out_data,
    output wire out_valid,
    input wire out_ready,
    output logic [COUNT_W-1:0] occupancy
);
    logic [WIDTH-1:0] mem[0:DEPTH-1];
    logic [PTR_W-1:0] rd_ptr, wr_ptr;
    wire pop=out_valid && out_ready;
    wire push=in_valid && in_ready;
    assign out_valid=(occupancy!=0) && !reset;
    assign in_ready=((occupancy<DEPTH)||pop) && !reset;
    assign out_data=mem[rd_ptr];
    always_ff @(posedge clk) begin
        if(reset) begin
            rd_ptr<='0; wr_ptr<='0; occupancy<='0;
        end else begin
            if(pop) rd_ptr <= (rd_ptr==DEPTH-1) ? '0 : rd_ptr+1'b1;
            if(push) begin
                mem[wr_ptr] <= in_data;
                wr_ptr <= (wr_ptr==DEPTH-1) ? '0 : wr_ptr+1'b1;
            end
            case({push,pop})
                2'b10: occupancy<=occupancy+1'b1;
                2'b01: occupancy<=occupancy-1'b1;
                default: ;
            endcase
        end
    end
endmodule
`default_nettype wire
