`timescale 1ns/1ps
`default_nettype none

// MODE 0: pipeline direct; 1: pipeline + naive FIFO wiring (negative test);
// 2: pipeline + FIFO + admission credits (candidate);
// 3: Week 9 FIU/FIFO/sequential Hash direct to Controller;
// 4: Week 9 frontend + downstream FIFO + reserved output slot (candidate);
// 5: pipeline + FIFO without credits (negative overflow test).
// Deliberately faulty modes exist only to reproduce integration failures.
module evaluation_system #(
    parameter integer MODE=2,
    parameter integer DEPTH=32,
    parameter integer PRE_DEPTH=8,
    parameter integer EARLY_EOF=0,
    parameter integer SCAN_ENTRIES=65536
)(
    input wire clk, reset,
    input wire [31:0] src_ip_in, dst_ip_in,
    input wire [15:0] src_port_in, dst_port_in,
    input wire [7:0] protocol_in,
    input wire [15:0] packet_length_in,
    input wire [79:0] timestamp_in,
    input wire in_valid, source_done,
    output wire in_ready,
    output wire [247:0] feature_vector,
    output wire fin_done,
    output wire scan_done
);
    localparam bit SEQUENTIAL=(MODE==3||MODE==4);
    localparam bit HAS_FIFO=(MODE!=0&&MODE!=3);
    localparam integer COUNT_W=$clog2(DEPTH+1);
    wire [15:0] hash_index, hash_length;
    wire [103:0] hash_key;
    wire [79:0] hash_timestamp;
    wire hash_valid, src_fire, frontend_ready, frontend_idle, hash_issue;
    wire [31:0] pre_occupancy_status;
    logic end_seen, scan_sent;
    integer inflight, reserved;
    wire controller_ready, post_valid, post_ready, post_input_ready;
    wire [215:0] post_data;
    wire [COUNT_W-1:0] post_occupancy;
    wire post_pop=HAS_FIFO&&post_valid&&post_ready;
    wire credit_available=(reserved<DEPTH)||post_pop;
    wire front_credit=(!HAS_FIFO)||credit_available;
    wire ready_permitted=(!end_seen)&&(!source_done)&&(!reset);
    assign in_ready=ready_permitted && frontend_ready;
    assign src_fire=in_valid&&in_ready;

    generate if(!SEQUENTIAL) begin : g_pipeline
        wire [103:0] fiu_key;
        wire [15:0] fiu_length;
        wire [79:0] fiu_timestamp;
        wire fiu_valid;
        assign frontend_ready=(MODE==2) ? credit_available : 1'b1;
        assign frontend_idle=(inflight==0);
        assign pre_occupancy_status=0;
        assign hash_issue=src_fire;
        flow_identification_unit_pipeline u_fiu(
            .clk,.reset,.src_ip_in,.dst_ip_in,.src_port_in,.dst_port_in,.protocol_in,
            .packet_length_in,.timestamp_in,.in_valid(src_fire),
            .flow_key_out(fiu_key),.packet_length_out(fiu_length),
            .timestamp_out(fiu_timestamp),.out_valid(fiu_valid));
        hash_unit_pipeline u_hash(
            .clk,.reset,.flow_key_in(fiu_key),.packet_length_in(fiu_length),
            .timestamp_in(fiu_timestamp),.in_valid(fiu_valid),
            .hash_index_out(hash_index),.flow_key_out(hash_key),
            .packet_length_out(hash_length),.timestamp_out(hash_timestamp),
            .out_valid(hash_valid));
    end else begin : g_seq
        wire [103:0] fiu_key;
        wire [15:0] fiu_length;
        wire [79:0] fiu_timestamp;
        wire fiu_valid, pre_input_ready, pre_valid, pre_pop_ready, hash_ready;
        wire [199:0] pre_data;
        wire [$clog2(PRE_DEPTH+1)-1:0] pre_occupancy;
        assign pre_occupancy_status=pre_occupancy;
        flow_identification_unit u_fiu(
            .clk,.reset,.src_ip_in,.dst_ip_in,.src_port_in,.dst_port_in,.protocol_in,
            .packet_length_in,.timestamp_in,.in_valid(src_fire),
            .in_ready(frontend_ready),.out_ready(pre_input_ready),
            .flow_key_out(fiu_key),.packet_length_out(fiu_length),
            .timestamp_out(fiu_timestamp),.out_valid(fiu_valid));
        transaction_fifo #(.WIDTH(200),.DEPTH(PRE_DEPTH)) u_pre_fifo(
            .clk,.reset,.in_data({fiu_key,fiu_length,fiu_timestamp}),
            .in_valid(fiu_valid),.in_ready(pre_input_ready),.out_data(pre_data),
            .out_valid(pre_valid),.out_ready(pre_pop_ready),.occupancy(pre_occupancy));
        assign pre_pop_ready=hash_ready&&front_credit;
        assign hash_issue=pre_valid&&pre_pop_ready;
        hash_unit u_hash(
            .clk,.reset,.flow_key_in(pre_data[199:96]),
            .packet_length_in(pre_data[95:80]),.timestamp_in(pre_data[79:0]),
            .in_valid(hash_issue),.in_ready(hash_ready),
            .hash_index_out(hash_index),.flow_key_out(hash_key),
            .packet_length_out(hash_length),.timestamp_out(hash_timestamp),
            .out_valid(hash_valid));
        // Count all admitted metadata, including FIU, pre-FIFO and Hash.
        assign frontend_idle=(inflight==0);
    end endgenerate

    generate if(HAS_FIFO) begin : g_post_fifo
        transaction_fifo #(.WIDTH(216),.DEPTH(DEPTH)) u_fifo(
            .clk,.reset,.in_data({hash_index,hash_key,hash_length,hash_timestamp}),
            .in_valid(hash_valid),.in_ready(post_input_ready),.out_data(post_data),
            .out_valid(post_valid),.out_ready(post_ready),.occupancy(post_occupancy));
    end else begin : g_no_post_fifo
        assign post_input_ready=1'b1;
        assign post_data={hash_index,hash_key,hash_length,hash_timestamp};
        assign post_valid=hash_valid;
        assign post_occupancy='0;
    end endgenerate
    assign post_ready=controller_ready;
    // Existing Controller expects a pulse, not a held valid level.
    wire ctrl_valid=(!HAS_FIFO||MODE==1) ? post_valid : (post_valid&&controller_ready);
    wire controller_done=EARLY_EOF ? source_done :
        (end_seen&&!scan_sent&&frontend_idle&&(post_occupancy==0)&&controller_ready);

    always_ff @(posedge clk) begin
        if(reset) begin
            end_seen<=0; scan_sent<=0; inflight<=0; reserved<=0;
        end else begin
            if(source_done) end_seen<=1;
            if(controller_done) scan_sent<=1;
            case({src_fire,hash_valid})
                2'b10: inflight<=inflight+1;
                2'b01: inflight<=inflight-1;
                default: ;
            endcase
            case({hash_issue,post_pop})
                2'b10: reserved<=reserved+1;
                2'b01: reserved<=reserved-1;
                default: ;
            endcase
        end
    end

    wire rd_en,rd_valid,wr_en,wr_done,fin_valid;
    wire [19:0] rd_addr,wr_addr;
    wire [31:0] rd_data,wr_data;
    wire [383:0] flow_entry;
    controller_ready #(.SCAN_ENTRIES(SCAN_ENTRIES)) u_controller(
        .clk,.rst(reset),.hash_index(post_data[215:200]),.flow_key(post_data[199:96]),
        .packet_length(post_data[95:80]),.timestamp(post_data[79:0]),
        .hash_valid(ctrl_valid),.input_ready(controller_ready),
        .rd_en,.rd_addr,.rd_data,.rd_valid,.wr_en,.wr_addr,.wr_data,.wr_done,
        .flow_entry,.fin_valid,.fin_done,.pcap_done(controller_done));
    flow_table u_flow_table(.clk,.rst(reset),.rd_en,.rd_addr,.rd_data,.rd_valid,
                           .wr_en,.wr_addr,.wr_data,.wr_done);
    flow_finalizer_v5 u_finalizer(.clk,.rst(reset),.flow_entry,.fin_valid,
                                 .feature_vector,.fin_done);
    assign scan_done=u_controller.scan_done;

    // Verification only: reservations must cover every result already in flight.
`ifndef SYNTHESIS
    always @(posedge clk) begin
        if(!reset&&(MODE==2||MODE==4)) begin
            if(reserved<0||reserved>DEPTH)
                $fatal(1,"Output reservation invariant failed");
            if(hash_valid&&!post_input_ready)
                $fatal(1,"Reserved Hash result would overflow the FIFO");
        end
    end
`endif
endmodule
`default_nettype wire
