from pathlib import Path
import html
import math
import re
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Preformatted,KeepTogether

ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'analysis'
OUT=ROOT/'output/pdf'
OUT.mkdir(parents=True,exist_ok=True)
PDF=OUT/'Analise_Tecnica_Pipeline_FIFO_Semana9.pdf'
FONT=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('Body','DejaVuSans.ttf'),('BodyBold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONT/file)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='Body',boldItalic='BodyBold')

INK=colors.HexColor('#183344')
TEAL=colors.HexColor('#087f8c')
MUTED=colors.HexColor('#647582')
PALE=colors.HexColor('#edf5f7')
GREY=colors.HexColor('#f3f5f6')
WIDTH=A4[0]-96
styles={
    'title':ParagraphStyle('title',fontName='BodyBold',fontSize=20,leading=26,textColor=INK,spaceAfter=13),
    'h2':ParagraphStyle('h2',fontName='BodyBold',fontSize=12.5,leading=17,textColor=TEAL,spaceBefore=15,spaceAfter=7,keepWithNext=True),
    'h3':ParagraphStyle('h3',fontName='BodyBold',fontSize=10.4,leading=14,textColor=INK,spaceBefore=10,spaceAfter=6,keepWithNext=True),
    'body':ParagraphStyle('body',fontName='Body',fontSize=9.4,leading=13.7,textColor=INK,spaceAfter=7),
    'table':ParagraphStyle('table',fontName='Body',fontSize=8.1,leading=11.2,textColor=INK),
    'tablehead':ParagraphStyle('tablehead',fontName='BodyBold',fontSize=8.0,leading=11,textColor=colors.white),
    'code':ParagraphStyle('code',fontName='Mono',fontSize=7.5,leading=11,textColor=INK,leftIndent=7,rightIndent=7,spaceBefore=4,spaceAfter=7),
    'item':ParagraphStyle('item',fontName='Body',fontSize=9.4,leading=13.7,textColor=INK,leftIndent=11,firstLineIndent=-11,spaceAfter=6),
}

def inline(s):
    s=html.escape(s)
    s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<link href="\2" color="#087f8c">\1</link>',s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`([^`]+)`',r'<font name="Mono" size="8.3">\1</font>',s)
    return s

def table(rows):
    cols=len(rows[0])
    maxima=[max(len(re.sub(r'[`*]','',r[c])) for r in rows) for c in range(cols)]
    weights=[math.sqrt(max(8,min(m,70))) for m in maxima]
    # Give long architecture descriptions a useful amount of space.
    if cols>=4 and maxima[0]>45:weights[0]*=1.25
    widths=[WIDTH*w/sum(weights) for w in weights]
    minimum=[max(pdfmetrics.stringWidth(word,'BodyBold',8.0) for word in re.sub(r'[`*]','',cell).split())+16 for cell in rows[0]]
    deficit=sum(max(0,m-w) for m,w in zip(minimum,widths))
    surplus=sum(max(0,w-m) for m,w in zip(minimum,widths))
    if deficit and surplus>deficit:
        widths=[max(w,m)-deficit*max(0,w-m)/surplus for w,m in zip(widths,minimum)]
    cells=[]
    for idx,row in enumerate(rows):
        cells.append([Paragraph(inline(c),styles['tablehead' if idx==0 else 'table']) for c in row])
    t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT',splitByRow=0)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),INK),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),
        ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),
        ('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),
        ('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),0.4,TEAL),
        ('LINEBELOW',(0,1),(-1,-1),0.25,colors.HexColor('#d8e4e8')),
    ]))
    return [t,Spacer(1,9)]

lines=(A/'RELATORIO_ANALISE_SEMANA9.md').read_text().splitlines()
story=[]
idx=0
while idx<len(lines):
    line=lines[idx].strip()
    if not line:idx+=1;continue
    if line.startswith('```'):
        idx+=1;code=[]
        while idx<len(lines) and not lines[idx].startswith('```'):
            code.append(lines[idx]);idx+=1
        story.append(Preformatted('\n'.join(code),styles['code']))
        idx+=1;continue
    if line.startswith('|'):
        rows=[]
        while idx<len(lines) and lines[idx].strip().startswith('|'):
            row=[c.strip() for c in lines[idx].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?',c) for c in row):rows.append(row)
            idx+=1
        story.extend(table(rows));continue
    if line.startswith('# '):
        story.append(Paragraph('ANÁLISE TÉCNICA | VALIDAÇÃO RTL',ParagraphStyle('eyebrow',fontName='BodyBold',fontSize=8.5,leading=13,textColor=TEAL,spaceAfter=6)))
        story.append(Paragraph(inline(line[2:]),styles['title']));idx+=1;continue
    if line.startswith('## '):story.append(Paragraph(inline(line[3:]),styles['h2']));idx+=1;continue
    if line.startswith('### '):story.append(Paragraph(inline(line[4:]),styles['h3']));idx+=1;continue
    if re.match(r'^\d+\. ',line) or line.startswith('- '):
        story.append(Paragraph(inline(line),styles['item']));idx+=1;continue
    paragraph=[line];idx+=1
    while idx<len(lines) and lines[idx].strip() and not re.match(r'^(#|\||```|- |\d+\. )',lines[idx]):
        paragraph.append(lines[idx].strip());idx+=1
    style=styles['body']
    probe=idx
    while probe<len(lines) and not lines[probe].strip():probe+=1
    if probe<len(lines) and lines[probe].strip().startswith('|'):
        style=ParagraphStyle('body_before_table',parent=style,keepWithNext=True)
    story.append(Paragraph(inline(' '.join(paragraph)),style))

def page(canvas,doc):
    canvas.saveState()
    w,h=A4
    canvas.setStrokeColor(TEAL);canvas.setLineWidth(1.2);canvas.line(48,h-32,w-48,h-32)
    canvas.setFont('Body',7.7);canvas.setFillColor(MUTED)
    canvas.drawString(48,h-24,'SD392 / PROJETO 4 SAMUEL')
    canvas.drawRightString(w-48,h-24,'SEMANA 9 / PIPELINE E FIFOs')
    canvas.setStrokeColor(colors.HexColor('#d8e4e8'));canvas.setLineWidth(.5);canvas.line(48,38,w-48,38)
    canvas.drawString(48,25,'25/11/2026  |  Escopo: simulação RTL  |  Origem: 1f1d1ab50e7b')
    canvas.drawRightString(w-48,25,str(doc.page))
    canvas.restoreState()

doc=SimpleDocTemplate(str(PDF),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=48,bottomMargin=52,
                      title='Semana 9 - Análise técnica de pipeline e FIFOs',author='Projeto 4 Samuel')
doc.build(story,onFirstPage=page,onLaterPages=page)
print(PDF)
