from pathlib import Path
import collections
import csv
import json
import subprocess
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from run_validation import A, ORIG, SOURCES, compile_sv, simulate, reference

def expected_metadata(path):
    rows=[]
    for line in path.read_text().splitlines():
        n=int(line,16)
        rows.append(dict(key=f'{n>>112:026x}',length=str((n>>96)&65535),
                         timestamp=f'{(n>>16)&((1<<80)-1):020x}',index=f'{n&65535:04x}'))
    return rows

def run_case(label,stream,mode,depth=8,pre_depth=8,good=True):
    specs=json.loads((A/'data/parser_specs.json').read_text())
    expected=expected_metadata(A/'data'/f'{stream}_metadata.mem')
    params=dict(MODE=mode,DEPTH=depth,PRE_DEPTH=pre_depth,N=len(expected),STIM_COUNT=specs[stream])
    sources=SOURCES[:-1]+[A/'tb_parser.sv',ORIG/'packet_parser.sv']
    executable=compile_sv('tb_parser',sources,params,label)
    event_file=A/'events'/f'{label}.csv'
    stdout=simulate(executable,[f'+DATA={A}/data/{stream}.mem',f'+LOG={event_file}'],label)
    summary=next(x for x in stdout.splitlines() if x.startswith('SUMMARY'))
    metrics={k:int(v) for k,v in (x.split('=') for x in summary.split()[1:])}
    by=collections.defaultdict(list)
    for e in csv.DictReader(event_file.open()):by[e['event']].append(e)
    fields=lambda e:(e['key'],e['length'],e['timestamp'])
    # Every Parser output is compared with decoding the actual Ethernet frame bytes in Python.
    assert [fields(e) for e in by['PARSER']]==[fields(e) for e in expected],label
    assert [fields(e) for e in by['SOURCE']]==[fields(e) for e in by['HASH']],label
    for e in by['HASH']:
        import binascii
        assert int(e['index'],16)==binascii.crc_hqx(int(e['key'],16).to_bytes(13,'big'),65535)
    golden,classes=reference(expected)
    observed={int(e['feature'],16)>>144:int(e['feature'],16) for e in by['FEATURE']}
    metrics.update(label=label,feature_match=golden==observed,
                   parser_to_frontend_loss=metrics['parser']-metrics['source'],
                   source_to_controller_loss=metrics['source']-metrics['captured'])
    if good:
        assert metrics['parser']==len(expected)==metrics['source']==metrics['completed'],metrics
        assert metrics['overflow']==0 and metrics['feature_match'],metrics
        assert [int(e['result']) for e in by['LOOKUP']]==classes,metrics
        assert len(by['FEATURE'])==len(golden)==len(observed),metrics
    print(summary,'FEATURE_MATCH='+str(metrics['feature_match']),flush=True)
    return metrics

if __name__=='__main__':
    subprocess.run([sys.executable,str(A/'prepare_parser.py')],check=True)
    cases=[
        dict(label='parser_original_gap80',stream='pcap8_gap80',mode=3),
        dict(label='parser_pipeline_direct_gap0',stream='pcap8_gap0',mode=0,good=False),
        dict(label='parser_pipeline_fifo_gap0',stream='pcap8_gap0',mode=2),
        dict(label='parser_sequential_twofifo_gap0',stream='pcap8_gap0',mode=4),
        dict(label='parser_256_pipeline_fifo256',stream='synthetic256_gap0',mode=2,depth=256),
        dict(label='parser_256_sequential_pre8',stream='synthetic256_gap0',mode=4,depth=8,good=False),
        dict(label='parser_256_sequential_pre256',stream='synthetic256_gap0',mode=4,depth=8,pre_depth=256),
        dict(label='parser_256_pipeline_fifo8',stream='synthetic256_gap0',mode=2,depth=8,good=False),
    ]
    results=[]
    for case in cases:
        results.append(run_case(**case))
        (A/'parser_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
