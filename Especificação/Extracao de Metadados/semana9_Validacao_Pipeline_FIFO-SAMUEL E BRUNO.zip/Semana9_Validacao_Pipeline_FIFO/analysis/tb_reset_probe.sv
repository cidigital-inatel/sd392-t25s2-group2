`timescale 1ns/1ps
module tb_reset_probe;
    logic clk=0,reset=1,in_valid=0,source_done=0;
    always #5 clk=~clk;
    logic [31:0] src_ip_in=0,dst_ip_in=0;
    logic [15:0] src_port_in=0,dst_port_in=0,packet_length_in=0;
    logic [7:0] protocol_in=0;
    logic [79:0] timestamp_in=0;
    wire in_ready,fin_done,scan_done;
    wire [247:0] feature_vector;
    logic [215:0] vectors[0:31];
    string data_file;
    integer id,old_occ,base;
    evaluation_system #(.MODE(2),.DEPTH(32)) dut(.*);
    initial begin
        data_file="analysis/data/unique512.mem";
        if($value$plusargs("DATA=%s",data_file))begin end
        $readmemh(data_file,vectors,0,31);
        repeat(3)@(negedge clk);reset=0;
        for(id=0;id<32;id=id+1)begin
            @(negedge clk);
            {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in}=vectors[id][215:112];
            packet_length_in=vectors[id][111:96];timestamp_in=vectors[id][95:16];in_valid=1;
        end
        @(negedge clk);in_valid=0;
        // Reset during the first MISS after W0=valid was written, before the whole record.
        wait(dut.u_controller.wr_en&&dut.u_controller.write_word_index==1);
        @(negedge clk);
        old_occ=dut.post_occupancy;
        base={vectors[0][15:0],4'b0000};
        if(old_occ==0)$fatal(1,"Expected occupied FIFO before reset");
        #1;reset=1;
        #1;if(dut.post_occupancy!=old_occ)$fatal(1,"FIFO reset acted before rising edge");
        @(posedge clk);#1;
        if(dut.post_occupancy!=0||dut.inflight!=0||dut.reserved!=0||dut.hash_valid)
            $fatal(1,"Reset did not flush pending transactions");
        $display("RESET_QUEUE_PASS occupied_before=%0d occupancy_after=%0d inflight_after=%0d reserved_after=%0d",old_occ,dut.post_occupancy,dut.inflight,dut.reserved);
        $display("RESET_MEMORY_PROBE valid_word=%h key_word=%h packet_count=%h",dut.u_flow_table.mem[base],dut.u_flow_table.mem[base+1],dut.u_flow_table.mem[base+5]);
        @(negedge clk);reset=0;
        repeat(25)@(negedge clk);
        if(dut.hash_valid||dut.post_occupancy!=0)$fatal(1,"Old queued results reappeared");
        {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in}=vectors[0][215:112];
        packet_length_in=vectors[0][111:96];timestamp_in=vectors[0][95:16];in_valid=1;
        @(negedge clk);in_valid=0;
        wait(dut.u_controller.lookup_done);
        #1;$display("RESET_RETRY_PROBE lookup_result=%0d (1=MISS 2=HIT 3=COLLISION)",dut.u_controller.lookup_result);
        $finish;
    end
    initial begin #100000;$fatal(1,"Reset probe timeout");end
endmodule
