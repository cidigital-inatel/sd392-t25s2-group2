`timescale 1ns/1ps
module tb_integrated #(
    parameter integer MODE=2, DEPTH=256, PRE_DEPTH=8, N=181, GAP=1,
    parameter integer HONOR_READY=1, EARLY_EOF=0,
    parameter integer MAX_WAIT=600000
);
    logic clk=0,reset=1,in_valid=0,source_done=0;
    always #5 clk=~clk;
    logic [31:0] src_ip_in=0,dst_ip_in=0;
    logic [15:0] src_port_in=0,dst_port_in=0,packet_length_in=0;
    logic [7:0] protocol_in=0;
    logic [79:0] timestamp_in=0;
    wire in_ready,fin_done,scan_done;
    wire [247:0] feature_vector;
    logic [215:0] vectors[0:511];
    string data_file,log_file;
    integer log_fd,cycles=0,source_count=0,hash_count=0,captured=0,completed=0;
    integer misses=0,hits=0,collisions=0,features=0,overflows=0,source_rejected=0;
    integer max_occupancy=0,max_pre_occupancy=0,max_reserved=0,wait_cycles=0,start_cycle=0;
    integer first_source=0,last_source=0,last_complete=0;
    integer duration,last_hash_cycle=0,min_hash_gap=999999;

    evaluation_system #(.MODE(MODE),.DEPTH(DEPTH),.PRE_DEPTH(PRE_DEPTH),.EARLY_EOF(EARLY_EOF)) dut(.*);

    always @(posedge clk) begin
        cycles=cycles+1;
        if(!reset) begin
            if(dut.post_occupancy>max_occupancy)max_occupancy=dut.post_occupancy;
            if(dut.pre_occupancy_status>max_pre_occupancy)max_pre_occupancy=dut.pre_occupancy_status;
            if(dut.reserved>max_reserved)max_reserved=dut.reserved;
            if(dut.src_fire)begin
                if(source_count==0)first_source=cycles;
                last_source=cycles;
                source_count=source_count+1;
                $fwrite(log_fd,"SOURCE,%0d,%026h,%0d,%020h,0000,0,0\n",cycles,
                        {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in},packet_length_in,timestamp_in);
            end
            if(in_valid&&!in_ready)source_rejected=source_rejected+1;
            if(dut.hash_valid)begin
                if(hash_count>0&&(cycles-last_hash_cycle)<min_hash_gap)
                    min_hash_gap=cycles-last_hash_cycle;
                last_hash_cycle=cycles;
                hash_count=hash_count+1;
                $fwrite(log_fd,"HASH,%0d,%026h,%0d,%020h,%04h,0,0\n",cycles,
                        dut.hash_key,dut.hash_length,dut.hash_timestamp,dut.hash_index);
                if(!dut.post_input_ready)overflows=overflows+1;
            end
            if(dut.u_controller.start)begin
                captured=captured+1;
                start_cycle=cycles;
                $fwrite(log_fd,"CAPTURE,%0d,%026h,%0d,%020h,%04h,0,0\n",cycles,
                        dut.post_data[199:96],dut.post_data[95:80],dut.post_data[79:0],dut.post_data[215:200]);
            end
            if(dut.u_controller.lookup_done)begin
                completed=completed+1;
                last_complete=cycles;
                duration=cycles-start_cycle;
                case(dut.u_controller.lookup_result)
                    1:misses=misses+1;
                    2:hits=hits+1;
                    3:collisions=collisions+1;
                endcase
                $fwrite(log_fd,"LOOKUP,%0d,0,%0d,0,0,%0d,0\n",cycles,duration,dut.u_controller.lookup_result);
            end
            if(fin_done)begin
                features=features+1;
                $fwrite(log_fd,"FEATURE,%0d,0,0,0,0,0,%062h\n",cycles,feature_vector);
            end
        end
    end

    initial begin : scenario
        integer id,timeout;
        data_file="analysis/data/reference181.mem";
        log_file="analysis/events.csv";
        if($value$plusargs("DATA=%s",data_file))begin end
        if($value$plusargs("LOG=%s",log_file))begin end
        $readmemh(data_file,vectors,0,N-1);
        log_fd=$fopen(log_file,"w");
        if(!log_fd)$fatal(1,"Cannot open event log");
        $fwrite(log_fd,"event,cycle,key,length,timestamp,index,result,feature\n");
        repeat(3)@(negedge clk);
        reset=0;
        for(id=0;id<N;id=id+1)begin
            @(negedge clk);
            if(HONOR_READY)begin
                while(!in_ready)begin
                    in_valid=0;
                    wait_cycles=wait_cycles+1;
                    @(negedge clk);
                end
            end
            {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in}=vectors[id][215:112];
            packet_length_in=vectors[id][111:96];
            timestamp_in=vectors[id][95:16];
            in_valid=1;
            if(GAP>1)begin
                @(negedge clk);in_valid=0;
                repeat(GAP-2)@(negedge clk);
            end
        end
        @(negedge clk);in_valid=0;source_done=1;
        @(negedge clk);source_done=0;
        timeout=0;
        while(!scan_done&&timeout<MAX_WAIT)begin
            @(negedge clk);timeout=timeout+1;
        end
        $display("SUMMARY MODE=%0d N=%0d GAP=%0d DEPTH=%0d source=%0d hash=%0d captured=%0d completed=%0d miss=%0d hit=%0d collision=%0d features=%0d overflow=%0d rejected=%0d hwm=%0d pre_hwm=%0d reserved_hwm=%0d wait=%0d hash_min_gap=%0d source_cycles=%0d completion_cycles=%0d scan_done=%0d queue_remaining=%0d",
            MODE,N,GAP,DEPTH,source_count,hash_count,captured,completed,misses,hits,collisions,features,
            overflows,source_rejected,max_occupancy,max_pre_occupancy,max_reserved,wait_cycles,min_hash_gap,
            last_source-first_source+1,last_complete-first_source+1,scan_done,dut.post_occupancy);
        $fclose(log_fd);
        $finish;
    end
endmodule
