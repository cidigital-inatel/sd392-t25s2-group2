from pathlib import Path
import binascii
import struct

ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'analysis'
PCAP=ROOT/'sources/repo/Integração/pcap_teste_2/trafego_referencia_P01_P14.pcap'

def pcap_frames():
    raw=PCAP.read_bytes()
    assert raw[:4]==b'\xd4\xc3\xb2\xa1'
    cursor=24;frames=[]
    while cursor<len(raw):
        sec,usec,size,original=struct.unpack_from('<IIII',raw,cursor)
        cursor+=16
        frames.append((raw[cursor:cursor+size],(sec<<32)|(usec*1000)))
        cursor+=size
    return frames

def make_frame(i):
    dst=bytes.fromhex('001122334455');src=bytes.fromhex('66778899aabb')
    ip_src=bytes([10,0,0,1]);ip_dst=bytes([192,168,0,1])
    payload=bytes((i+j)&255 for j in range(22))
    udp=struct.pack('!HHHH',1000+i,8000,8+len(payload),0)+payload
    ip=bytearray(struct.pack('!BBHHHBBH4s4s',0x45,0,20+len(udp),i,0,64,17,0,ip_src,ip_dst))
    total=sum(struct.unpack('!10H',ip))
    while total>>16:total=(total&65535)+(total>>16)
    struct.pack_into('!H',ip,10,(~total)&65535)
    frame=dst+src+b'\x08\x00'+ip+udp
    assert len(frame)==64
    return bytes(frame),((100+i//100)<<32)|((i%100)*10_000_000)

def metadata(frames):
    rows=[]
    for frame,ts in frames:
        ihl=(frame[14]&15)*4
        key=frame[26:30]+frame[30:34]+frame[14+ihl:18+ihl]+frame[23:24]
        length=struct.unpack_from('!H',frame,16)[0]
        h=binascii.crc_hqx(key,65535)
        rows.append((int.from_bytes(key,'big')<<112)|(length<<96)|(ts<<16)|h)
    return rows

def stream_file(name,frames,gap):
    beats=[]
    for frame,ts in frames:
        for start in range(0,len(frame),8):
            chunk=frame[start:start+8]
            d=int.from_bytes(chunk,'little')
            keep=(1<<len(chunk))-1
            last=int(start+8>=len(frame))
            beats.append((1<<154)|(last<<153)|(1<<152)|(ts<<72)|(keep<<64)|d)
        beats += [0]*gap
    p=A/'data'/name
    p.write_text(''.join(f'{x:039x}\n' for x in beats))
    gold=A/'data'/name.replace('.mem','_metadata.mem')
    gold.write_text(''.join(f'{x:054x}\n' for x in metadata(frames)))
    return len(beats)

frames=pcap_frames()[:8]
specs={
    'pcap8_gap80':stream_file('pcap8_gap80.mem',frames,80),
    'pcap8_gap0':stream_file('pcap8_gap0.mem',frames,0),
    'synthetic256_gap0':stream_file('synthetic256_gap0.mem',[make_frame(i) for i in range(256)],0),
}

# Share the event monitor with the metadata experiments; replace only the stimulus.
s=(A/'tb_integrated.sv').read_text()
s=s.replace('module tb_integrated #(', 'module tb_parser #(')
s=s.replace('parameter integer MAX_WAIT=600000', 'parameter integer MAX_WAIT=600000, STIM_COUNT=2048')
start=s.index('    logic [31:0] src_ip_in=0')
end=s.index('    wire in_ready',start)
s=s[:start]+'''    wire [31:0] src_ip_in,dst_ip_in;
    wire [15:0] src_port_in,dst_port_in,packet_length_in;
    wire [7:0] protocol_in;
    wire [79:0] timestamp_in;
    logic [63:0] TDATA=0;
    logic [7:0] TKEEP=0;
    logic TVALID=0,TLAST=0,TUSER=0;
    logic [79:0] frame_ts=0;
    logic [154:0] stream[0:65535];
    wire parser_valid;
    assign in_valid=parser_valid;
    packet_parser u_parser(.clk,.reset,.TDATA,.TKEEP,.TVALID,.TLAST,.TUSER,
        .timestamp_in(frame_ts),.src_ip(src_ip_in),.dst_ip(dst_ip_in),
        .src_port(src_port_in),.dst_port(dst_port_in),.protocol(protocol_in),
        .packet_length(packet_length_in),.timestamp(timestamp_in),.valid(parser_valid));
''' + s[end:]
s=s.replace('logic clk=0,reset=1,in_valid=0,source_done=0;',
            'logic clk=0,reset=1,source_done=0; wire in_valid;')
s=s.replace('integer duration,last_hash_cycle=0,min_hash_gap=999999;',
            'integer duration,last_hash_cycle=0,min_hash_gap=999999; integer parser_count=0;')
s=s.replace('            if(dut.src_fire)begin', '''            if(parser_valid)begin
                parser_count=parser_count+1;
                $fwrite(log_fd,"PARSER,%0d,%026h,%0d,%020h,0000,0,0\\n",cycles,
                        {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in},packet_length_in,timestamp_in);
            end
            if(dut.src_fire)begin''')
start=s.index('        for(id=0;id<N;id=id+1)begin')
end=s.index('        timeout=0;',start)
s=s[:start]+'''        $readmemh(data_file,stream,0,STIM_COUNT-1);
        for(id=0;id<STIM_COUNT;id=id+1)begin
            @(negedge clk);
            {TVALID,TLAST,TUSER,frame_ts,TKEEP,TDATA}=stream[id];
        end
        @(negedge clk);TVALID=0;TLAST=0;TKEEP=0;TDATA=0;
        repeat(3)@(negedge clk);
        source_done=1;
        @(negedge clk);source_done=0;
''' + s[end:]
s=s.replace('        $readmemh(data_file,vectors,0,N-1);','')
s=s.replace('scan_done=%0d queue_remaining=%0d"','scan_done=%0d queue_remaining=%0d parser=%0d"')
s=s.replace('scan_done,dut.post_occupancy);','scan_done,dut.post_occupancy,parser_count);')
(A/'tb_parser.sv').write_text(s)
(A/'data/parser_specs.json').write_text(__import__('json').dumps(specs,indent=2))
print(specs)
