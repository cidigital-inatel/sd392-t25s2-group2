"""Run the complete, finite RTL validation campaign and verify expected failures."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

A=Path(__file__).resolve().parent
ROOT=A.parent
sys.path.insert(0,str(A))
from run_validation import SOURCES,compile_sv,simulate

def main():
    start=time.monotonic()
    for script in ['prepare_sources.py','run_originals.py','run_validation.py',
                   'run_parser_validation.py','run_extra_validation.py']:
        subprocess.run([sys.executable,str(A/script)],cwd=ROOT,check=True)
    e=compile_sv('tb_reset_probe',SOURCES[:-1]+[A/'tb_reset_probe.sv'],{},'reset_probe')
    output=simulate(e,[],'reset_probe')
    assert 'RESET_QUEUE_PASS' in output
    # An existing Flow Table limitation, intentionally reproduced and reported.
    assert 'lookup_result=3' in output
    print(output,flush=True)
    manifest={}
    for base in [ROOT/'sources',A/'rtl',A/'compat']:
        for p in sorted(base.rglob('*')):
            if p.is_file() and p.suffix in ['.sv','.mem','.pcap','.md','.zip']:
                manifest[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
    (A/'source_sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    result=dict(status='PASS_WITH_EXPECTED_NEGATIVE_CONTROLS',
                repository_commit='1f1d1ab50e7b677a914ebf2781d5566e89844ddf',
                metadata_experiments=len(json.loads((A/'results.json').read_text())),
                parser_experiments=len(json.loads((A/'parser_results.json').read_text())),
                extra_experiments=len(json.loads((A/'extra_results.json').read_text())),
                elapsed_seconds=round(time.monotonic()-start,2))
    (A/'campaign_status.json').write_text(json.dumps(result,indent=2))
    print('CAMPAIGN COMPLETE',json.dumps(result),flush=True)

if __name__=='__main__':main()
