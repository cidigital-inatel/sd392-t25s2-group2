from pathlib import Path
import json
import re
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from run_validation import A,W9,PIPE,compile_sv,simulate

def run():
    executable=compile_sv('tb_semana9_fifo',list((W9/'rtl').glob('*.sv'))+[W9/'tb/tb_semana9_fifo.sv'],{},'fifo_original')
    output=simulate(executable,[],'fifo_original')
    assert 'TODOS OS CENARIOS DA FIFO PASSARAM' in output
    print(output,flush=True)
    summaries=[]
    for kind in [0,1,2]:
        executable=compile_sv('metadata_testbench_pipeline',list((PIPE/'rtl').glob('*.sv'))+[PIPE/'tb/metadata_testbench_pipeline.sv'],{'TEST_KIND':kind},f'pipeline_original_{kind}')
        output=simulate(executable,[f'+VECTORS={PIPE}/tb/hash_vectors.mem',
             f'+RESULTS={A}/pipeline_{kind}_results.csv',f'+STAGES={A}/pipeline_{kind}_stages.csv',
             f'+TRACEFILE={A}/pipeline_{kind}.vcd'],f'pipeline_original_{kind}')
        assert '181 transacoes, II=1' in output
        assert 'PASS: testbench pipeline completo' in output
        line=next(x for x in output.splitlines() if x.startswith('SUMMARY'))
        summaries.append({k:int(v) for k,v in (x.split('=') for x in line.split()[1:])})
        print(output,flush=True)
    (A/'original_results.json').write_text(json.dumps(summaries,indent=2))

if __name__=='__main__':run()
