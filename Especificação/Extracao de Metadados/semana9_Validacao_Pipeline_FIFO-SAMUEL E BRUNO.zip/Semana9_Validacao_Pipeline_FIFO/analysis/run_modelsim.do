# Reexecution recipe for ModelSim/Questa; not executed in this environment.
# First run: python analysis/prepare_sources.py and python analysis/prepare_parser.py
set root [file normalize [file join [file dirname [info script]] ..]]
cd $root
set a [file join $root analysis]
set original [file join $root sources repo Integração pcap_teste_2]
set week9 [file join $root sources semana9 semana9_fifo_fiu_hash_BRUNO_SAMUEL semana9_fifo_fiu_hash_arquivos rtl]
set pipe [file join $root sources pipeline rtl]
file mkdir [file join $a modelsim_work]
file mkdir [file join $a events]
vlib [file join $a modelsim_work]
vmap work [file join $a modelsim_work]
set files [list [file join $a rtl evaluation_system.sv] [file join $a rtl transaction_fifo.sv] \
    [file join $a rtl controller_ready.sv] [file join $a compat flow_table.sv] \
    [file join $original flow_finalizer.sv] [file join $original packet_parser.sv] \
    [file join $week9 flow_identification_unit.sv] [file join $week9 hash_unit.sv] \
    [file join $pipe flow_identification_unit_pipeline.sv] [file join $pipe hash_unit_pipeline.sv] \
    [file join $a tb_integrated.sv] [file join $a tb_parser.sv]]
vlog -sv -work work {*}$files
foreach config {{modelsim_pipeline 2 256 1} {modelsim_sequential 4 8 3}} {
    lassign $config name mode depth gap
    vsim -onfinish stop work.tb_integrated -gMODE=$mode -gDEPTH=$depth -gN=181 -gGAP=$gap \
        +DATA=[file join $a data reference181.mem] +LOG=[file join $a events ${name}.csv]
    run -all
    quit -sim
}
foreach config {{modelsim_parser_pipeline 2} {modelsim_parser_sequential 4}} {
    lassign $config name mode
    vsim -onfinish stop work.tb_parser -gMODE=$mode -gDEPTH=8 -gN=8 -gSTIM_COUNT=65 \
        +DATA=[file join $a data pcap8_gap0.mem] +LOG=[file join $a events ${name}.csv]
    run -all
    quit -sim
}
puts "Check generated CSVs with analysis/check_events.py; see README.md."
