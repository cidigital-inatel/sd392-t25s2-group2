from pathlib import Path
import binascii
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'analysis'
COMPAT = OUT / 'compat'
COMPAT.mkdir(exist_ok=True)
ORIG = ROOT / 'sources/repo/Integração/pcap_teste_2'

# Icarus does not implement this unpacked-array assignment pattern.
# Only the initialization syntax changes; memory size and cycle timing are identical.
s = (ORIG / 'flow_table.sv').read_text()
s = s.replace("logic [DATA_WIDTH-1:0] mem [0:DEPTH-1] = '{default: '0};",
              "logic [DATA_WIDTH-1:0] mem [0:DEPTH-1];\n"
              "    initial begin\n"
              "        for (integer init_i=0; init_i<DEPTH; init_i=init_i+1) mem[init_i]='0;\n"
              "    end")
(COMPAT / 'flow_table.sv').write_text(s)

# Minimal candidate change: expose the existing acceptance condition.
# The Controller FSM, memory requests, and WAIT_VALID_LOW are preserved.
s = (ORIG / 'controller_base.sv').read_text()
s = s.replace('module controller #(', 'module controller_ready #(')
s = s.replace('input  logic         hash_valid,',
              'input  logic         hash_valid,\n    output wire          input_ready,')
s = s.replace('wire start = (state == IDLE) && hash_valid;',
              'wire start = (state == IDLE) && hash_valid;\n'
              '    assign input_ready = (state == IDLE) && !scan_req && !rst;')
(OUT / 'rtl').mkdir(exist_ok=True)
(OUT / 'rtl/controller_ready.sv').write_text(s)

rows = []
for line in (ROOT / 'sources/pipeline/tb/hash_vectors.mem').read_text().splitlines():
    line = line.split('//')[0].strip()
    if not line:
        continue
    n = int(line, 16)
    key, length, timestamp, index = n >> 112, (n >> 96) & 65535, (n >> 16) & ((1 << 80)-1), n & 65535
    assert binascii.crc_hqx(key.to_bytes(13, 'big'), 0xffff) == index
    rows.append((key, length, timestamp, index))
assert len(rows) == 181

def normalized_ts(i):
    return ((100 + i // 100) << 32) | ((i % 100) * 10_000_000)

def write_vectors(name, values):
    (OUT / 'data').mkdir(exist_ok=True)
    with (OUT / 'data' / name).open('w') as f:
        for i, (key, length) in enumerate(values):
            index = binascii.crc_hqx(key.to_bytes(13, 'big'), 0xffff)
            packed = (key << 112) | (length << 96) | (normalized_ts(i) << 16) | index
            f.write(f'{packed:054x}\n')

write_vectors('reference181.mem', [(x[0], x[1]) for x in rows])
write_vectors('repeat512.mem', [(rows[0][0], 60 + i % 1440) for i in range(512)])
# These keys have distinct CRC indices. Full 16-bit indices are preserved.
unique = []
seen = set()
for i in range(512):
    key = (0x0a000001 << 72) | (0xc0a80001 << 40) | ((1000+i) << 24) | (443 << 8) | 6
    h = binascii.crc_hqx(key.to_bytes(13, 'big'), 65535)
    assert h not in seen
    seen.add(h)
    unique.append((key, 60+i % 1440))
write_vectors('unique512.mem', unique)

print('Prepared equivalent memory initialization, ready output, and independent CRC goldens.')
