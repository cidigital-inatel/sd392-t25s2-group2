"""Portable XSim reexecution recipe. Not executed in the authoring environment."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from run_validation import ROOT,A,ORIG,SOURCES
from check_events import check

def main():
    p=argparse.ArgumentParser()
    p.add_argument('case',choices=['pipeline','sequential','parser_pipeline','parser_sequential'])
    args=p.parse_args()
    for tool in ['xvlog','xelab','xsim']:
        if not shutil.which(tool):p.error(f'{tool} unavailable; open a Vivado command shell first')
    parser=args.case.startswith('parser_')
    sequential='sequential' in args.case
    top='tb_parser' if parser else 'tb_integrated'
    params=dict(MODE=4 if sequential else 2,DEPTH=8 if sequential or parser else 256,
                N=8 if parser else 181,GAP=3 if sequential else 1)
    if parser:params['STIM_COUNT']=65
    sources=SOURCES[:-1]+[A/f'{top}.sv']+([ORIG/'packet_parser.sv'] if parser else [])
    build=A/'xsim_build'/args.case
    build.mkdir(parents=True,exist_ok=True)
    def run(cmd):
        subprocess.run(cmd,cwd=build,check=True)
    run(['xvlog','-sv',*map(str,sources)])
    command=['xelab',top,'-s',args.case,'-debug','typical']
    for k,v in params.items():command+=['-generic_top',f'{k}={v}']
    run(command)
    events=A/'events'/f'xsim_{args.case}.csv'
    data=A/'data'/('pcap8_gap0.mem' if parser else 'reference181.mem')
    golden=A/'data'/('pcap8_gap0_metadata.mem' if parser else 'reference181.mem')
    run(['xsim',args.case,'-runall','-testplusarg',f'DATA={data}',
         '-testplusarg',f'LOG={events}'])
    check(events,golden,params['N'],parser)

if __name__=='__main__':main()
