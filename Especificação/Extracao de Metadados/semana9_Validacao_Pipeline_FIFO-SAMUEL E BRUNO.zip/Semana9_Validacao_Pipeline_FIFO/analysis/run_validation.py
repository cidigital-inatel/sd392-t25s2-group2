"""Reproduce experiments with Icarus Verilog 13+, using only Python stdlib."""
from pathlib import Path
import binascii
import collections
import csv
import json
import os
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'analysis'
ORIG=ROOT/'sources/repo/Integração/pcap_teste_2'
W9=ROOT/'sources/semana9/semana9_fifo_fiu_hash_BRUNO_SAMUEL/semana9_fifo_fiu_hash_arquivos'
PIPE=ROOT/'sources/pipeline'
IV=os.environ.get('IVERILOG') or shutil.which('iverilog') or str(ROOT/'tools/iverilog/usr/bin/iverilog')
VVP=os.environ.get('VVP') or shutil.which('vvp') or str(ROOT/'tools/iverilog/usr/bin/vvp')
BACKEND=next((ROOT/'tools/iverilog/usr').glob('lib/*/ivl'),None)
FLAGS=['-B',str(BACKEND)] if BACKEND and not shutil.which('iverilog') else []
for d in ['logs','events','build']:(A/d).mkdir(exist_ok=True)

def compile_sv(top,sources,params,label):
    output=A/'build'/f'{label}.vvp'
    cmd=[IV,*FLAGS,'-g2012','-s',top,'-o',str(output)]
    for k,v in params.items():cmd+=['-P',f'{top}.{k}={v}']
    cmd += list(map(str,sources))
    r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=60)
    (A/'logs'/f'{label}_compile.log').write_text(r.stdout+r.stderr)
    if r.returncode:
        raise RuntimeError(f'{label}: compile failed\n{r.stderr[:4000]}')
    return output

def simulate(output,args,label,timeout=60):
    r=subprocess.run([VVP,str(output),*args],cwd=ROOT,capture_output=True,text=True,timeout=timeout)
    (A/'logs'/f'{label}.log').write_text(r.stdout+r.stderr)
    if r.returncode:raise RuntimeError(f'{label}: simulation failed\n{r.stdout}\n{r.stderr}')
    return r.stdout

def reference(source_events):
    table={}
    classification=[]
    for e in source_events:
        key=int(e['key'],16);length=int(e['length']);ts=int(e['timestamp'],16)
        h=binascii.crc_hqx(key.to_bytes(13,'big'),65535)
        if h not in table:
            table[h]=dict(key=key,packets=1,bytes=length,first=ts,last=ts)
            classification.append(1)
        elif table[h]['key']==key:
            table[h]['packets']+=1;table[h]['bytes']+=length;table[h]['last']=ts
            classification.append(2)
        else:classification.append(3)
    result={}
    for f in table.values():
        first=f['first'];last=f['last']
        elapsed=((last>>32)-(first>>32))*1_000_000_000 + (last&0xffffffff)-(first&0xffffffff)
        assert elapsed>=0
        seconds,nanos=divmod(elapsed,1_000_000_000)
        dur=(seconds<<32)|nanos
        result[f['key']]=(f['key']<<144)|(f['packets']<<112)|(f['bytes']<<80)|dur
    return result,classification

SOURCES=[A/'rtl/evaluation_system.sv',A/'rtl/transaction_fifo.sv',A/'rtl/controller_ready.sv',
         A/'compat/flow_table.sv',ORIG/'flow_finalizer.sv',
         W9/'rtl/flow_identification_unit.sv',W9/'rtl/hash_unit.sv',
         PIPE/'rtl/flow_identification_unit_pipeline.sv',PIPE/'rtl/hash_unit_pipeline.sv',A/'tb_integrated.sv']

def experiment(label,mode,n,gap,depth=256,data='reference181.mem',honor=1,early=0,good=True,max_wait=600000):
    params=dict(MODE=mode,DEPTH=depth,N=n,GAP=gap,HONOR_READY=honor,EARLY_EOF=early,MAX_WAIT=max_wait)
    executable=compile_sv('tb_integrated',SOURCES,params,label)
    event_path=A/'events'/f'{label}.csv'
    stdout=simulate(executable,[f'+DATA={A}/data/{data}',f'+LOG={event_path}'],label)
    summary=next(line for line in stdout.splitlines() if line.startswith('SUMMARY'))
    metrics={k:int(v) for k,v in (part.split('=') for part in summary.split()[1:])}
    events=list(csv.DictReader(event_path.open()))
    by=collections.defaultdict(list)
    for e in events:by[e['event']].append(e)
    # Independent CRC: Python's binascii implementation, not a copy of the HDL loop.
    assert len(by['HASH'])==len(by['SOURCE'])
    for s,h in zip(by['SOURCE'],by['HASH']):
        assert (s['key'],s['length'],s['timestamp'])==(h['key'],h['length'],h['timestamp'])
        assert int(h['index'],16)==binascii.crc_hqx(int(s['key'],16).to_bytes(13,'big'),65535)
    accepted_gold,classes=reference(by['SOURCE'])
    requested=[]
    for line in (A/'data'/data).read_text().splitlines()[:n]:
        packed=int(line,16)
        requested.append(dict(key=f'{packed>>112:026x}',length=str((packed>>96)&65535),
                              timestamp=f'{(packed>>16)&((1<<80)-1):020x}'))
    gold,_=reference(requested)
    actual={int(e['feature'],16)>>144:int(e['feature'],16) for e in by['FEATURE']}
    metrics.update(label=label,feature_match=actual==gold,feature_match_accepted=actual==accepted_gold,
                   features_expected=len(gold),features_observed=len(actual),
                   source_to_controller_loss=len(by['SOURCE'])-len(by['CAPTURE']))
    lat=collections.defaultdict(set)
    for e in by['LOOKUP']:lat[int(e['result'])].add(int(e['length']))
    metrics['controller_latency']={str(k):sorted(v) for k,v in lat.items()}
    if good:
        assert metrics['source']==n and metrics['completed']==n and metrics['overflow']==0,metrics
        assert metrics['feature_match'] and metrics['scan_done']==1,metrics
        assert [int(e['result']) for e in by['LOOKUP']]==classes,metrics
        assert len(actual)==len(by['FEATURE']), 'Duplicate finalized flow'
        assert [(e['key'],e['length'],e['timestamp']) for e in by['CAPTURE']]==[(e['key'],e['length'],e['timestamp']) for e in by['SOURCE']]
    else:
        assert metrics['source']<n or metrics['captured']<metrics['source'] or not metrics['feature_match'] or not metrics['scan_done'] or metrics['overflow']>0,metrics
    print(summary, 'FEATURE_MATCH='+str(metrics['feature_match']),flush=True)
    return metrics

def main():
    subprocess.run([sys.executable,str(A/'prepare_sources.py')],check=True)
    cases=[
        dict(label='pipeline_direct181_II1',mode=0,n=181,gap=1,good=False),
        dict(label='pipeline_fifo_naive32',mode=1,n=32,gap=1,depth=32,good=False,max_wait=10000),
        dict(label='pipeline_fifo_credit181',mode=2,n=181,gap=1,depth=256),
        dict(label='sequential_prefifo181',mode=3,n=181,gap=3,good=False),
        dict(label='sequential_twofifos181',mode=4,n=181,gap=3,depth=8),
        dict(label='pipeline_fifo_credit8_181',mode=2,n=181,gap=1,depth=8),
        dict(label='pipeline_fifo_no_credit8_181',mode=5,n=181,gap=1,depth=8,good=False),
        dict(label='pipeline_fifo_early_eof',mode=2,n=32,gap=1,depth=32,early=1,good=False),
        dict(label='pipeline_sameflow512',mode=2,n=512,gap=1,depth=32,data='repeat512.mem'),
        dict(label='sequential_sameflow512',mode=4,n=512,gap=3,depth=8,data='repeat512.mem'),
        dict(label='pipeline_unique32_credit3',mode=2,n=32,gap=1,depth=3,data='unique512.mem'),
        dict(label='pipeline_unique32_credit1',mode=2,n=32,gap=1,depth=1,data='unique512.mem'),
        dict(label='pipeline_no_backpressure8',mode=2,n=181,gap=1,depth=8,honor=0,good=False),
    ]
    results=[]
    for case in cases:
        results.append(experiment(**case))
        (A/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
