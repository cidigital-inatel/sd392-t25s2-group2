# Semana 9 - validação comparativa de pipeline e FIFOs

Escopo: simulação RTL. Não requer FPGA, placa ou implementação física.

Leia `analysis/RELATORIO_ANALISE_SEMANA9.md` e o PDF anexado. As fontes originais
selecionadas permanecem em `sources/`; os protótipos ficam em `analysis/rtl/`.
O repositório remoto não foi alterado.

## Campanha executada

Instale Python 3 e Icarus Verilog 13, disponibilizando `iverilog` e `vvp` no PATH:

```bash
python analysis/run_all.py
```

São executadas as suítes fornecidas, 25 comparações integradas e uma sondagem de
reset. A campanha deve terminar com `PASS_WITH_EXPECTED_NEGATIVE_CONTROLS` em
`analysis/campaign_status.json`. Há cenários com defeitos intencionais para
reproduzir perda, deadlock, estouro e finalização prematura. Eles não significam
que as variantes recomendadas falharam.

Os logs estão em `analysis/logs/`, os eventos por pacote em `analysis/events/`
e os resumos em `analysis/*results.json`. O modelo de referência é Python,
com CRC por `binascii.crc_hqx` e agregação independente por fluxo.

Os 181 vetores funcionais originais são usados integralmente nas suítes
isoladas. Os 181 vetores da comparação integrada preservam suas chaves e
comprimentos e usam timestamps monotônicos normalizados gerados pela bancada.
Os testes de Parser usam o PCAP original P01-P08 e 256 quadros UDP de 64 bytes.

## ModelSim/Questa

Roteiro fornecido para reexecução; não foi executado no ambiente desta análise.
Prepare os arquivos com Python e execute no Transcript:

```tcl
do analysis/run_modelsim.do
```

Depois confira os CSVs usando, por exemplo:

```bash
python analysis/check_events.py analysis/events/modelsim_pipeline.csv analysis/data/reference181.mem --count 181
python analysis/check_events.py analysis/events/modelsim_sequential.csv analysis/data/reference181.mem --count 181
python analysis/check_events.py analysis/events/modelsim_parser_pipeline.csv analysis/data/pcap8_gap0_metadata.mem --count 8 --parser
python analysis/check_events.py analysis/events/modelsim_parser_sequential.csv analysis/data/pcap8_gap0_metadata.mem --count 8 --parser
```

## Vivado XSim

Roteiro fornecido para reexecução; não foi executado no ambiente desta análise.
Em um terminal com as ferramentas Vivado no PATH:

```bash
python analysis/run_xsim.py pipeline
python analysis/run_xsim.py sequential
python analysis/run_xsim.py parser_pipeline
python analysis/run_xsim.py parser_sequential
```

Os testbenches executados no Icarus usam os mesmos RTLs e estímulos que esses
roteiros. A Flow Table de compatibilidade modifica apenas a sintaxe de sua
inicialização, mantendo a dimensão e a resposta síncrona de um ciclo.

## Variantes na bancada

| MODE | Arquitetura | Uso |
|---:|---|---|
| 0 | Pipeline direto ao Controller | Controle negativo |
| 1 | Pipeline com FIFO e valid mantido ligado ao Controller | Controle negativo de deadlock |
| 2 | Pipeline com FIFO, créditos e adaptação ao Controller | Candidato recomendado |
| 3 | FIU/FIFO/Hash sequencial, sem FIFO posterior | Controle negativo em rajadas rápidas |
| 4 | Sequencial com FIFO anterior, FIFO posterior e créditos | Comparação funcional correta |
| 5 | Pipeline com FIFO, sem reservar vagas em trânsito | Controle negativo de estouro |

O top de avaliação opera uma amostra por reset. Não é uma substituição
homologada do top do grupo. Sua finalidade é tornar as decisões e falhas
reproduzíveis. O relatório também documenta que a Flow Table original retém
memória após reset e pode conservar uma entrada parcialmente escrita.

O commit de origem é `1f1d1ab50e7b677a914ebf2781d5566e89844ddf`.
Os hashes SHA-256 estão em `analysis/source_sha256.json`.
