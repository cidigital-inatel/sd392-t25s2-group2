// Flow Identification Unit - contrato de interface v0.3 (06/10/2026).
// Um registro de saída; a entrada é uma publicação sem in_ready.
module flow_identification_unit (
    input  logic         clk,
    input  logic         reset_n,
    input  logic [31:0]  src_ip_in,
    input  logic [31:0]  dst_ip_in,
    input  logic [15:0]  src_port_in,
    input  logic [15:0]  dst_port_in,
    input  logic [7:0]   protocol_in,
    input  logic [15:0]  packet_length_in,
    input  logic [79:0]  timestamp_in,
    input  logic         in_valid,
    input  logic         out_ready,
    output logic [103:0] flow_key_out,
    output logic [15:0]  packet_length_out,
    output logic [79:0]  timestamp_out,
    output logic         out_valid
);
    // Uma publicação é admissível apenas com a saída livre ou aceita
    // nesta mesma borda. O Parser não recebe backpressure neste contrato.
    always_ff @(posedge clk) begin
        if (!reset_n) begin
            flow_key_out     <= '0;
            packet_length_out <= '0;
            timestamp_out    <= '0;
            out_valid        <= 1'b0;
        end else if (!out_valid || out_ready) begin
            if (in_valid) begin
                flow_key_out      <= {src_ip_in, dst_ip_in,
                                      src_port_in, dst_port_in, protocol_in};
                packet_length_out <= packet_length_in;
                timestamp_out     <= timestamp_in;
                out_valid         <= 1'b1;
            end else begin
                out_valid <= 1'b0;
            end
        end
        // Se a saída estiver bloqueada, o registro permanece estável.
        // in_valid nesse caso viola a premissa temporal do contrato.
    end

`ifndef SYNTHESIS
    // O Parser não tem in_ready: a simulação deve denunciar a publicação
    // que ultrapassa a capacidade do registro único.
    always @(posedge clk) begin
        if (reset_n && in_valid && out_valid && !out_ready)
            $error("FIU: publicacao com registro pendente e Hash indisponivel");
    end
`endif
endmodule
