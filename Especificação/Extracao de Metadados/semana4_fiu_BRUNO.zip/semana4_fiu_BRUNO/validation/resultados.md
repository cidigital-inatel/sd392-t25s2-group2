# Resultado da simulação isolada da FIU

- Data da evidência: 9 de outubro de 2026.
- Ferramenta: ModelSim, executado por Bruno no notebook.
- Módulos: `rtl/flow_identification_unit.sv` e `tb/tb_flow_identification_unit.sv`.
- Compilação no Transcript: ambos os arquivos concluídos com sucesso; `2 compiles, 0 failed with no errors`.
- Resultado: `PASS: FIU, 3 registros entregues em ordem e sem perda`.
- Encerramento: `$finish` em `126 ns`.
- Evidência disponível nesta conversa: captura da janela Transcript enviada por Bruno.

O teste dirigiu casos conhecidos de TCP e UDP, espera da saída, captura simultânea à entrega e reset. Três registros foram entregues; um registro pendente foi cancelado intencionalmente por reset. Não há evidência nesta etapa de teste entre módulos, síntese em FPGA ou medição da folga temporal sem FIFO.
