`timescale 1ns/1ps
module tb_flow_identification_unit;
    logic clk = 0;
    always #5 clk = ~clk;
    logic reset_n = 0, in_valid = 0, out_ready = 0;
    logic [31:0] src_ip_in = 0, dst_ip_in = 0;
    logic [15:0] src_port_in = 0, dst_port_in = 0, packet_length_in = 0;
    logic [7:0] protocol_in = 0;
    logic [79:0] timestamp_in = 0;
    logic [103:0] flow_key_out;
    logic [15:0] packet_length_out;
    logic [79:0] timestamp_out;
    logic out_valid;

    localparam logic [103:0] KEY_A = 104'hC0A8010AC0A80114C35001BB06;
    localparam logic [103:0] KEY_B = 104'hC0A80114C0A8010A01BBC35006;
    localparam logic [79:0] TIME_A = 80'h0123456789ABCDEF0123;
    localparam logic [79:0] TIME_B = 80'hFEDCBA9876543210FEDC;
    int delivered = 0;

    flow_identification_unit dut (.*);

    // Dirigir entradas na borda de descida e conferir após a próxima subida.
    task automatic step;
        @(posedge clk); #1;
    endtask
    task automatic expect_output(
        input logic expected_valid,
        input logic [103:0] expected_key,
        input logic [15:0] expected_length,
        input logic [79:0] expected_time
    );
        if (out_valid !== expected_valid)
            $fatal(1, "out_valid: obtido %b, esperado %b", out_valid, expected_valid);
        if (expected_valid && {flow_key_out,packet_length_out,timestamp_out}
            !== {expected_key,expected_length,expected_time})
            $fatal(1, "dados nao correspondem ao pacote esperado");
    endtask
    task automatic drive_a(input logic [15:0] length, input logic [79:0] stamp);
        src_ip_in = 32'hC0A8010A; dst_ip_in = 32'hC0A80114;
        src_port_in = 16'hC350; dst_port_in = 16'h01BB;
        protocol_in = 8'h06; packet_length_in = length; timestamp_in = stamp;
    endtask
    task automatic drive_b;
        src_ip_in = 32'hC0A80114; dst_ip_in = 32'hC0A8010A;
        src_port_in = 16'h01BB; dst_port_in = 16'hC350;
        protocol_in = 8'h06; packet_length_in = 16'd60; timestamp_in = TIME_B;
    endtask

    initial begin
        step();
        expect_output(0, '0, '0, '0);
        @(negedge clk); reset_n = 1;

        // Pacote A: chave conhecida, sem entrega na borda de captura.
        drive_a(16'd40,TIME_A); in_valid = 1; out_ready = 0;
        step(); expect_output(1,KEY_A,16'd40,TIME_A);
        @(negedge clk); in_valid = 0;
        // Alterações da entrada com in_valid baixo não afetam a saída.
        drive_b();
        repeat (3) begin
            step(); expect_output(1,KEY_A,16'd40,TIME_A);
        end

        // Aceitar A e publicar B na mesma borda.
        @(negedge clk); in_valid = 1; out_ready = 1;
        // Antes da borda, a Hash Unit vê A.
        expect_output(1,KEY_A,16'd40,TIME_A);
        step(); delivered++; expect_output(1,KEY_B,16'd60,TIME_B);

        // B é entregue uma só vez; validade cai sem nova publicação.
        @(negedge clk); in_valid = 0;
        step(); delivered++; expect_output(0,'0,'0,'0);

        // Repetir chave A com comprimento e timestamp novos.
        @(negedge clk); drive_a(16'd72,TIME_B); in_valid = 1;
        step(); expect_output(1,KEY_A,16'd72,TIME_B);
        @(negedge clk); in_valid = 0; out_ready = 0;
        step(); expect_output(1,KEY_A,16'd72,TIME_B);

        // Reset síncrono cancela o registro pendente.
        @(negedge clk); reset_n = 0;
        step(); expect_output(0,'0,'0,'0);
        @(negedge clk); reset_n = 1; out_ready = 1;
        step(); expect_output(0,'0,'0,'0);

        // Protocolo UDP: concatenação e dados associados.
        @(negedge clk);
        src_ip_in=32'h0A000001; dst_ip_in=32'h08080808;
        src_port_in=16'h1234; dst_port_in=16'h0035;
        protocol_in=8'h11; packet_length_in=16'd28;
        timestamp_in=80'h00000000000000000002; in_valid=1;
        step(); expect_output(1,104'h0A000001080808081234003511,
                              16'd28,80'h00000000000000000002);
        @(negedge clk); in_valid=0;
        step(); delivered++; expect_output(0,'0,'0,'0);
        if (delivered != 3) $fatal(1,"contagem de entregas incorreta");
        $display("PASS: FIU, 3 registros entregues em ordem e sem perda");
        $finish;
    end
endmodule
