# FIU - Semana 4

Primeira implementação isolada conforme a proposta de contrato da FIU v0.3, ainda pendente de alinhamento entre equipes. Leia `semana4_fiu_passo_a_passo.md` para o contexto e `validation/resultados.md` para o resultado observado.

No Transcript do ModelSim, na pasta `semana4_fiu`:

```tcl
vlib work
vlog -sv rtl/flow_identification_unit.sv tb/tb_flow_identification_unit.sv
vsim work.tb_flow_identification_unit
run -all
```

Resultado esperado: `PASS: FIU, 3 registros entregues em ordem e sem perda`.
A execução de 9/10/2026, enviada por Bruno, apresentou esse resultado em 126 ns. Integração com Parser e Hash Unit, e comprovação da premissa sem FIFO, seguem pendentes.
