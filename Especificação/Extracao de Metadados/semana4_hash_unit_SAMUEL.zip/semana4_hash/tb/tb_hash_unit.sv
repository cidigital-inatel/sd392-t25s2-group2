`timescale 1ns/1ps
`default_nettype none

// Testbench isolado. Os resultados esperados vem de arquivos calculados em
// Python ANTES da simulacao; nao se reutiliza a funcao CRC do DUT.
module tb_hash_unit;
    localparam int MAX_VECTORS = 512;
    localparam int MAX_TRANSFERS = 1024;

    logic clk;
    logic reset_n;
    logic [103:0] flow_key_in;
    logic [15:0] packet_length_in;
    logic [79:0] timestamp_in;
    logic in_valid;
    wire in_ready;
    wire [15:0] hash_index_out;
    wire [103:0] flow_key_out;
    wire [15:0] packet_length_out;
    wire [79:0] timestamp_out;
    wire out_valid;
    logic out_ready;

    logic [215:0] vectors [0:MAX_VECTORS-1];
    logic [215:0] expected_queue [0:MAX_TRANSFERS-1];
    logic [215:0] stalled_output;
    logic [199:0] stalled_input;
    logic previous_output_stall;
    logic previous_input_stall;

    int vector_count;
    logic [$clog2(MAX_VECTORS)-1:0] active_vector;
    int read_pointer;
    int write_pointer;
    int pending_count;
    int accepted_total;
    int delivered_total;
    int reset_cancelled;
    int output_stability_checks;
    int input_wait_cycles;
    int clock_count;
    bit automatic_ready;
    string vector_file;

    hash_unit dut (
        .clk, .reset_n,
        .flow_key_in, .packet_length_in, .timestamp_in,
        .in_valid, .in_ready,
        .hash_index_out, .flow_key_out, .packet_length_out, .timestamp_out,
        .out_valid, .out_ready
    );

    always #5 clk = ~clk;

    // Modelo do consumidor: alterna periodos disponiveis e indisponiveis.
    always @(negedge clk) begin
        if (automatic_ready)
            out_ready = ((clock_count % 11) >= 3);
    end

    // Amostra os handshakes ANTES das atualizacoes nonblocking do DUT.
    // expected_queue existe apenas no testbench; nao e FIFO de hardware.
    always @(posedge clk) begin
        clock_count = clock_count + 1;
        if (!reset_n) begin
            reset_cancelled = reset_cancelled + pending_count;
            pending_count = 0;
            read_pointer = 0;
            write_pointer = 0;
            previous_output_stall = 1'b0;
            previous_input_stall = 1'b0;
            if (in_ready !== 1'b0)
                $fatal(1, "in_ready ativo durante reset.");
        end else begin
            if (previous_output_stall) begin
                if (out_valid !== 1'b1 ||
                    {flow_key_out, packet_length_out, timestamp_out, hash_index_out}
                    !== stalled_output)
                    $fatal(1, "Saida mudou antes da aceitacao pelo consumidor.");
                output_stability_checks = output_stability_checks + 1;
            end
            if (previous_input_stall) begin
                if (in_valid !== 1'b1 ||
                    {flow_key_in, packet_length_in, timestamp_in} !== stalled_input)
                    $fatal(1, "Estimulador violou estabilidade da entrada em espera.");
            end
            if (out_valid && pending_count == 0)
                $fatal(1, "Resultado sem entrada aceita correspondente.");
            if (pending_count != 0 && in_ready)
                $fatal(1, "Primeira versao deve aceitar somente um registro por vez.");

            if (out_valid && out_ready) begin
                if (pending_count != 1)
                    $fatal(1, "Entrega sem exatamente um registro pendente.");
                if ({flow_key_out, packet_length_out, timestamp_out, hash_index_out}
                    !== expected_queue[read_pointer]) begin
                    $display("Esperado: %054h", expected_queue[read_pointer]);
                    $display("Obtido:   %026h%04h%020h%04h",
                             flow_key_out, packet_length_out, timestamp_out, hash_index_out);
                    $fatal(1, "CRC, chave ou metadados divergentes.");
                end
                read_pointer = read_pointer + 1;
                pending_count = pending_count - 1;
                delivered_total = delivered_total + 1;
            end

            if (in_valid && in_ready) begin
                if (write_pointer >= MAX_TRANSFERS || pending_count != 0)
                    $fatal(1, "Aceitacao indevida ou limite do scoreboard.");
                if ({flow_key_in, packet_length_in, timestamp_in}
                    !== vectors[active_vector][215:16])
                    $fatal(1, "Estimulador apresentou um registro incoerente.");
                expected_queue[write_pointer] = vectors[active_vector];
                write_pointer = write_pointer + 1;
                pending_count = pending_count + 1;
                accepted_total = accepted_total + 1;
            end

            previous_output_stall = out_valid && !out_ready;
            if (previous_output_stall)
                stalled_output = {flow_key_out, packet_length_out, timestamp_out, hash_index_out};
            previous_input_stall = in_valid && !in_ready;
            if (previous_input_stall) begin
                stalled_input = {flow_key_in, packet_length_in, timestamp_in};
                input_wait_cycles = input_wait_cycles + 1;
            end
        end
    end

    task automatic send_vector(input int index);
        int guard;
        bit was_accepted;
        @(negedge clk);
        active_vector = $clog2(MAX_VECTORS)'(index);
        flow_key_in = vectors[index][215:112];
        packet_length_in = vectors[index][111:96];
        timestamp_in = vectors[index][95:16];
        in_valid = 1'b1;
        guard = 0;
        was_accepted = 1'b0;
        while (!was_accepted) begin
            @(posedge clk);
            was_accepted = in_ready;
            #1;
            if (!was_accepted) begin
                guard = guard + 1;
                if (guard > 200)
                    $fatal(1, "Timeout esperando aceitacao do vetor %0d.", index);
            end
        end
    endtask

    task automatic clear_input;
        @(negedge clk);
        in_valid = 1'b0;
        // Alterar dados INVALIDOS prova que o DUT capturou o registro anterior.
        flow_key_in = ~flow_key_in;
        packet_length_in = ~packet_length_in;
        timestamp_in = ~timestamp_in;
    endtask

    task automatic wait_empty;
        int guard;
        guard = 0;
        while (pending_count != 0) begin
            @(posedge clk);
            #1;
            guard = guard + 1;
            if (guard > 200)
                $fatal(1, "Timeout esperando entrega do registro pendente.");
        end
    endtask

    task automatic reset_and_check;
        @(negedge clk);
        reset_n = 1'b0;
        in_valid = 1'b0;
        repeat (2) begin
            @(posedge clk);
            #1;
            if (out_valid !== 1'b0 || in_ready !== 1'b0)
                $fatal(1, "Controle nao reinicializado apos borda de reset.");
        end
        @(negedge clk);
        reset_n = 1'b1;
    endtask

    initial begin : run_tests
        int fd;
        int guard;
        clk = 1'b0;
        reset_n = 1'b0;
        flow_key_in = '0;
        packet_length_in = '0;
        timestamp_in = '0;
        in_valid = 1'b0;
        out_ready = 1'b0;
        stalled_output = '0;
        stalled_input = '0;
        previous_output_stall = 1'b0;
        previous_input_stall = 1'b0;
        vector_count = 181;
        active_vector = '0;
        read_pointer = 0;
        write_pointer = 0;
        pending_count = 0;
        accepted_total = 0;
        delivered_total = 0;
        reset_cancelled = 0;
        output_stability_checks = 0;
        input_wait_cycles = 0;
        clock_count = 0;
        automatic_ready = 1'b0;
        vector_file = "tb/hash_vectors.mem";
        if ($value$plusargs("VECTORS=%s", vector_file)) begin end
        if ($value$plusargs("COUNT=%d", vector_count)) begin end
        if (vector_count < 13 || vector_count > MAX_VECTORS)
            $fatal(1, "Quantidade invalida de vetores.");
        fd = $fopen(vector_file, "r");
        if (fd == 0)
            $fatal(1, "Arquivo de vetores nao encontrado: %s", vector_file);
        $fclose(fd);
        $readmemh(vector_file, vectors, 0, vector_count - 1);

        if ($test$plusargs("TRACE")) begin
            $dumpfile("tb_hash_unit.vcd");
            $dumpvars(0, tb_hash_unit);
        end

        // 1. Reset inicial e latencia exata desta implementacao.
        reset_and_check();
        send_vector(0);
        clear_input();
        for (int cycle = 1; cycle <= 13; cycle++) begin
            @(posedge clk);
            #1;
            if (cycle < 13 && out_valid !== 1'b0)
                $fatal(1, "Resultado declarado antes de processar os 13 bytes.");
            if (cycle == 13 && out_valid !== 1'b1)
                $fatal(1, "Resultado ausente depois das 13 atualizacoes.");
        end
        // 2. Resultado pronto, consumidor ainda indisponivel.
        repeat (4) begin @(posedge clk); #1; end
        @(negedge clk);
        out_ready = 1'b1;
        wait_empty();
        $display("PASS: latencia de 13 atualizacoes e saida preservada na espera.");

        // 3. Reset durante calculo cancela exatamente o registro pendente.
        send_vector(1);
        clear_input();
        repeat (3) begin @(posedge clk); #1; end
        reset_and_check();
        repeat (16) begin @(posedge clk); #1; end
        $display("PASS: reset durante calculo, sem resultado residual.");

        // 4. Reset enquanto um resultado pronto aguarda o consumidor.
        @(negedge clk);
        out_ready = 1'b0;
        send_vector(2);
        clear_input();
        guard = 0;
        while (!out_valid) begin
            @(posedge clk); #1;
            guard = guard + 1;
            if (guard > 30)
                $fatal(1, "Timeout esperando resultado antes do reset.");
        end
        reset_and_check();
        @(negedge clk);
        out_ready = 1'b1;
        repeat (16) begin @(posedge clk); #1; end
        $display("PASS: reset com resultado em espera, sem entrega residual.");

        // 5. Todos os vetores; entrada mantida enquanto o DUT estiver ocupado.
        // automatic_ready exercita bloqueios curtos e repetidos na saida.
        automatic_ready = 1'b1;
        for (int index = 0; index < vector_count; index++)
            send_vector(index);
        clear_input();
        wait_empty();
        automatic_ready = 1'b0;
        @(negedge clk);
        out_ready = 1'b1;
        repeat (20) begin @(posedge clk); #1; end

        if (accepted_total != delivered_total + reset_cancelled || pending_count != 0)
            $fatal(1, "Contagem final inconsistente.");
        if (delivered_total != vector_count + 1 || reset_cancelled != 2)
            $fatal(1, "Quantidade inesperada de entregas ou cancelamentos.");
        if (output_stability_checks == 0 || input_wait_cycles == 0)
            $fatal(1, "Os testes nao exercitaram os bloqueios previstos.");
        $display("PASS: %0d vetores golden, CRC e todos os metadados conferidos.", vector_count);
        $display("SUMMARY accepted=%0d delivered=%0d reset_cancelled=%0d pending=%0d",
                 accepted_total, delivered_total, reset_cancelled, pending_count);
        $display("SUMMARY output_stability_checks=%0d input_wait_cycles=%0d",
                 output_stability_checks, input_wait_cycles);
        $display("PASS: tb_hash_unit concluido sem divergencias.");
        $finish;
    end

    initial begin
        #100000;
        $fatal(1, "Timeout global da simulacao.");
    end
endmodule

`default_nettype wire
