# Registro da verificação isolada da Hash Unit

Execução: 8 de outubro de 2026. Responsável acadêmico pelo módulo: Samuel.

O RTL passou na compilação, na conferência estática e na simulação isolada com os valores esperados gerados antes da execução. A comparação inclui o índice de 16 bits e os metadados de 200 bits, preservando a associação entre entradas e saídas.

| Item | Configuração registrada |
|---|---|
| Módulo | `hash_unit`, em SystemVerilog |
| CRC | CRC-16/CCITT-FALSE: `poly=1021`, `init=FFFF`, sem reflexão, `xorout=0000` |
| Chave | 104 bits, 13 bytes, byte mais significativo primeiro |
| Metadados preservados | Comprimento de 16 bits; timestamp de 80 bits |
| Capacidade do RTL | Um registro por vez, sem FIFO |
| Protocolo | `valid/ready`, transferência na borda de subida com reset inativo |
| Reset | Síncrono, ativo baixo; cancela o registro pendente |
| Referência | Python 3.12.14, biblioteca padrão `binascii.crc_hqx` |
| Ferramenta | Distribuição Python `verilator` 5.48.0; o relatório do binário identifica Verilator 5.49 |
| Identificação do binário | `rev vUNKNOWN-built20260516-4e853d8`, conforme `--version` |
| Compilador C++ | GCC/G++ 13.3.0 |
| Compilação do teste | `--binary --timing --trace --assert -Wall -Wno-BLKSEQ`, topo `tb_hash_unit` |
| Conferência estática do RTL | `--lint-only -Wall --top-module hash_unit`, retorno zero, sem avisos |

`-Wno-BLKSEQ` permite as atribuições bloqueantes usadas pelos processos do testbench; a conferência estática separada do RTL foi executada com `-Wall` sem essa supressão. A compilação final do teste não apresentou avisos do Verilator.

| Verificação | Resultado |
|---|---|
| Conferência do perfil no modelo, ASCII `123456789` → `29B1` | Passou; somente modelo, pois a sequência tem nove bytes |
| Exemplos históricos do grupo | Passaram |
| 13 vetores dirigidos | Passaram |
| 104 vetores com um único bit ativo | Passaram |
| 64 vetores pseudoaleatórios, semente 392 | Passaram |
| Chave repetida com metadados diferentes | Índice repetido corretamente; metadados preservados |
| Par de chaves distintas com índice `B511` | Ambas as chaves preservadas e entregues |
| Latência até disponibilizar o resultado | 13 atualizações de um byte, confirmadas |
| Saída bloqueada por `out_ready = 0` | Dados e validade estáveis |
| Entrada esperando disponibilidade | Produtor mantém o registro; nenhuma aceitação indevida |
| Reset durante cálculo | Registro cancelado; nenhum resultado residual |
| Reset com resultado pronto e bloqueado | Registro cancelado; nenhuma entrega residual |
| Coerência entre CSV, MEM e gerador | 181 linhas correspondentes, conferidas |
| Contagem final e comparação de registros | Sem divergências; nenhum registro pendente |

Resumo da simulação executada:

```text
PASS: latencia de 13 atualizacoes e saida preservada na espera.
PASS: reset durante calculo, sem resultado residual.
PASS: reset com resultado em espera, sem entrega residual.
PASS: 181 vetores golden, CRC e todos os metadados conferidos.
SUMMARY accepted=184 delivered=182 reset_cancelled=2 pending=0
SUMMARY output_stability_checks=272 input_wait_cycles=2785
PASS: tb_hash_unit concluido sem divergencias.
```

Os 184 registros aceitos correspondem aos 181 vetores da coleção mais três operações dirigidas anteriores. Dessas três operações, uma foi entregue e duas foram canceladas pelos resets aplicados de propósito. Assim, `184 = 182 entregues + 2 cancelados + 0 pendentes`.

O índice e os metadados foram comparados nas 182 entregas. A estabilidade da saída foi conferida em 272 bordas após bloqueio, e o teste registrou 2.785 ciclos de espera da entrada. Esses contadores descrevem os estímulos aplicados pelo teste; não são medições de desempenho com tráfego real.

Na pasta do pacote, a execução pode ser reproduzida com:

```bash
python3 python/run_tests.py --simulator verilator
```

A execução realizada utilizou a mesma chamada com `--tool` apontando para o compilador instalado no ambiente. O conteúdo do registro bruto está em `simulation.log`. O runner refaz `compile.log` e `simulation.log` a cada execução.

| Arquivo validado | SHA-256 |
|---|---|
| `rtl/hash_unit.sv` | `17de6f1a92090c61ec88d258d28763516420b64d514b487049ddd3ba4377fe67` |
| `tb/tb_hash_unit.sv` | `c17c4de2cabaacebacec685fc98ec1673e59bb08e4efe87c588ed9ed4245b28c` |
| `python/reference_hash.py` | `b14000f059bfe962102a487ecde035bc8063a1a6d66df8db34f710c997e8f4a9` |
| `python/run_tests.py` | `42ed8ea26c572e63138849f28b1b997b2cf3391d54c796475797a404506e1fde` |
| `tb/hash_vectors.mem` | `20c04b4179b6aa4600dae367828dc1e6ed7368504e9118d17662bebaad6ac9f7` |

O alcance desta verificação é funcional e isolado, com entradas simuladas e consumidor representado pelo testbench. A integração exige concordância dos demais módulos com o perfil, a ordem dos bytes, as larguras e o protocolo documentados. O timestamp é preservado sem interpretação temporal. A validação não comprova frequência máxima, área ou desempenho em FPGA. A alternativa Icarus Verilog presente no runner não foi executada nesta entrega.
