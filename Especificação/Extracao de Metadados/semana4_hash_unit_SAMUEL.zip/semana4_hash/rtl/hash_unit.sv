`timescale 1ns/1ps
`default_nettype none

// Semana 4 - Hash Unit, primeira versao funcional.
// CRC-16/CCITT-FALSE: poly=1021, init=FFFF, refin/refout=0, xorout=0000.
// Entrada: 13 bytes de flow_key, do bit 103 ao bit 0 (MSB primeiro).
// Um registro por vez, sem FIFO. Reset sincrono ativo baixo.
module hash_unit (
    input  logic         clk,
    input  logic         reset_n,
    input  logic [103:0] flow_key_in,
    input  logic [15:0]  packet_length_in,
    input  logic [79:0]  timestamp_in,
    input  logic         in_valid,
    output logic         in_ready,
    output logic [15:0]  hash_index_out,
    output logic [103:0] flow_key_out,
    output logic [15:0]  packet_length_out,
    output logic [79:0]  timestamp_out,
    output logic         out_valid,
    input  logic         out_ready
);

    typedef enum logic [1:0] {IDLE, CALC, RESULT} state_t;
    state_t state;

    logic [103:0] key_reg;
    logic [15:0]  length_reg;
    logic [79:0]  timestamp_reg;
    logic [15:0]  crc_reg;
    logic [15:0]  result_reg;
    logic [3:0]   byte_index;
    logic [7:0]   current_byte;
    logic [15:0]  next_crc;

    // O for abaixo descreve oito atualizacoes combinacionais em um ciclo.
    // Ele NAO consome oito ciclos de clock.
    function automatic logic [15:0] crc16_next_byte (
        input logic [15:0] crc,
        input logic [7:0]  data_byte
    );
        logic [15:0] value;
        value = crc ^ {data_byte, 8'h00};
        for (int bit_index = 0; bit_index < 8; bit_index++) begin
            if (value[15])
                value = (value << 1) ^ 16'h1021;
            else
                value = value << 1;
        end
        return value;
    endfunction

    // Primeiro byte: key_reg[103:96]; ultimo byte: key_reg[7:0].
    assign current_byte = key_reg[103 - (int'(byte_index) * 8) -: 8];
    assign next_crc = crc16_next_byte(crc_reg, current_byte);

    assign in_ready          = reset_n && (state == IDLE);
    assign out_valid         = (state == RESULT);
    assign hash_index_out    = result_reg;
    assign flow_key_out      = key_reg;
    assign packet_length_out = length_reg;
    assign timestamp_out     = timestamp_reg;

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            state         <= IDLE;
            key_reg       <= '0;
            length_reg    <= '0;
            timestamp_reg <= '0;
            crc_reg       <= 16'hFFFF;
            result_reg    <= '0;
            byte_index    <= '0;
        end else begin
            case (state)
                IDLE: begin
                    if (in_valid && in_ready) begin
                        // Captura atomica: todos os campos do mesmo pacote.
                        key_reg       <= flow_key_in;
                        length_reg    <= packet_length_in;
                        timestamp_reg <= timestamp_in;
                        crc_reg       <= 16'hFFFF;
                        byte_index    <= 4'd0;
                        state         <= CALC;
                    end
                end

                CALC: begin
                    crc_reg <= next_crc;
                    if (byte_index == 4'd12) begin
                        // next_crc inclui o 13o byte; crc_reg ainda e o antigo.
                        // Preservam-se TODOS os 16 bits, sem selecao de 5 bits.
                        result_reg <= next_crc;
                        state      <= RESULT;
                    end else begin
                        byte_index <= byte_index + 4'd1;
                    end
                end

                RESULT: begin
                    // Dados, validade e resultado ficam estaveis na espera.
                    if (out_valid && out_ready)
                        state <= IDLE;
                end

                default: begin
                    // Recuperacao do controle; nenhum resultado e declarado.
                    state      <= IDLE;
                    byte_index <= '0;
                    crc_reg    <= 16'hFFFF;
                end
            endcase
        end
    end
endmodule

`default_nettype wire
