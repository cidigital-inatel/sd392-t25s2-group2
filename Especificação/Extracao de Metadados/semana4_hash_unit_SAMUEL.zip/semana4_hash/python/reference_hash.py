#!/usr/bin/env python3
"""Referencia independente do RTL e gerador dos vetores da Semana 4.

Somente biblioteca padrao. crc_hqx e implementado pela biblioteca do Python;
o resultado esperado nao e obtido da funcao SystemVerilog do DUT.
"""

import argparse
import binascii
import csv
import ipaddress
import random
import struct
from dataclasses import dataclass
from pathlib import Path

SEED = 392
INIT = 0xFFFF
KEY_BYTES = 13


def flow_key(src_ip: str, dst_ip: str, src_port: int, dst_port: int,
             protocol: int) -> bytes:
    """5-tuple de 104 bits, campos em ordem de rede (big-endian)."""
    return (ipaddress.IPv4Address(src_ip).packed
            + ipaddress.IPv4Address(dst_ip).packed
            + struct.pack("!HHB", src_port, dst_port, protocol))


def hash_index(key: bytes) -> int:
    if len(key) != KEY_BYTES:
        raise ValueError("A Hash Unit recebe exatamente 13 bytes de flow_key.")
    return binascii.crc_hqx(key, INIT)


def self_check() -> None:
    # '123456789' tem 9 bytes: verifica o perfil do modelo, nao a porta de 104 bits.
    if binascii.crc_hqx(b"123456789", INIT) != 0x29B1:
        raise AssertionError("Modelo nao reproduz o check CRC-16/CCITT-FALSE.")
    # Referencias historicas do grupo, agora usando o CRC completo de 16 bits.
    known = {
        "0A000020C0000220C00001BB06": 0x83A4,
        "0A000020C0000221C00001BB06": 0xC604,
        "0A000020C0000222C00001BB06": 0x08E4,
        "0A000020C0000223C00001BB06": 0x4D44,
        "C0A8010A08080808CB8401BB06": 0xA018,
        "C0A8010AC0A80114C35001BB06": 0xB511,
    }
    for key, expected in known.items():
        if hash_index(bytes.fromhex(key)) != expected:
            raise AssertionError(f"Referencia divergente para {key}.")


@dataclass(frozen=True)
class Vector:
    label: str
    key: bytes
    packet_length: int
    timestamp: int

    def memory_word(self) -> str:
        """216 bits: {key[104], length[16], timestamp[80], index[16]}."""
        if not 0 <= self.packet_length <= 0xFFFF:
            raise ValueError("packet_length nao cabe em 16 bits.")
        if not 0 <= self.timestamp < (1 << 80):
            raise ValueError("timestamp nao cabe em 80 bits.")
        return (self.key.hex().upper() + f"{self.packet_length:04X}"
                + f"{self.timestamp:020X}{hash_index(self.key):04X}")


def make_vectors() -> list[Vector]:
    key_a = flow_key("192.168.1.10", "192.168.1.20", 50000, 443, 6)
    vectors = [
        Vector("tcp_exemplo_FI", key_a, 60, (1 << 79) + 123),
        Vector("mesma_chave_outros_metadados", key_a, 1500, (1 << 80) - 1),
        Vector("fluxo_reverso", flow_key("192.168.1.20", "192.168.1.10", 443, 50000, 6), 60, 500),
        Vector("udp_dns", flow_key("10.0.0.1", "10.0.0.2", 12345, 53, 17), 48, 1000),
    ]
    for dst_octet in range(32, 36):
        vectors.append(Vector(f"pesquisa_dst_{dst_octet}",
                              flow_key("10.0.0.32", f"192.0.2.{dst_octet}", 49152, 443, 6),
                              64 + dst_octet, 2000 + dst_octet))
    vectors.extend([
        Vector("parser_pesquisa", flow_key("192.168.1.10", "8.8.8.8", 52100, 443, 6), 40, 3000),
        Vector("fronteira_zero", bytes(13), 0, 0),
        Vector("fronteira_um", bytes([255]) * 13, 0xFFFF, (1 << 80) - 1),
        Vector("ascii_13_bytes", b"123456789ABCD", 13, 4000),
    ])

    # Duas chaves TCP diferentes com o mesmo CRC completo; nao ha resolucao
    # de colisao na Hash Unit, mas a chave/metadados devem seguir corretos.
    target = hash_index(key_a)
    collision_key = None
    for dst_port in range(65536):
        candidate = flow_key("192.168.1.11", "192.168.1.20", 50000, dst_port, 6)
        if hash_index(candidate) == target:
            collision_key = candidate
            break
    if collision_key is None or collision_key == key_a:
        raise AssertionError("Nao foi produzido o par de colisao esperado.")
    vectors.append(Vector("colisao_indice_chave_distinta", collision_key, 512, 5000))

    # Fronteiras da porta de 104 bits: cada posicao invertida isoladamente.
    for bit in range(104):
        vectors.append(Vector(f"bit_unico_{bit:03d}", (1 << bit).to_bytes(13, "big"),
                              bit + 1, (1 << 64) + bit))

    rng = random.Random(SEED)
    for i in range(64):
        vectors.append(Vector(f"pseudoaleatorio_{i:02d}", rng.getrandbits(104).to_bytes(13, "big"),
                              rng.getrandbits(16), rng.getrandbits(80)))
    return vectors


def generate(out_dir: Path) -> list[Vector]:
    self_check()
    vectors = make_vectors()
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "hash_vectors.mem").open("w", encoding="ascii", newline="\n") as f:
        for vector in vectors:
            word = vector.memory_word()
            if len(word) != 54:
                raise AssertionError("Vetor de memoria nao tem 216 bits.")
            f.write(word + "\n")
    with (out_dir / "hash_vectors.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "caso", "flow_key_hex", "packet_length", "timestamp_hex", "hash_index_esperado_hex"])
        for i, vector in enumerate(vectors):
            writer.writerow([i, vector.label, vector.key.hex().upper(), vector.packet_length,
                             f"{vector.timestamp:020X}", f"{hash_index(vector.key):04X}"])
    return vectors


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=Path(__file__).resolve().parents[1] / "tb")
    args = parser.parse_args()
    vectors = generate(args.out_dir)
    print("Modelo: CRC-16/CCITT-FALSE; check ASCII 123456789 = 29B1.")
    print(f"Vetores: {len(vectors)}; seed: {SEED}; memoria: {args.out_dir / 'hash_vectors.mem'}")
    for vector in vectors[:13]:
        print(f"{vector.label}: {vector.key.hex().upper()} -> {hash_index(vector.key):04X}")


if __name__ == "__main__":
    main()
