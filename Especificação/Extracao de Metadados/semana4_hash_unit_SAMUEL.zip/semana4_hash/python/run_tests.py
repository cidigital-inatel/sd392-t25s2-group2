#!/usr/bin/env python3
"""Gera os valores esperados, compila e executa o teste isolado.

Exemplos:
  python3 python/run_tests.py --simulator verilator
  python3 python/run_tests.py --simulator iverilog
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

from reference_hash import generate


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--simulator", choices=["auto", "iverilog", "verilator"], default="auto")
    parser.add_argument("--tool", help="Caminho do compilador, se ele nao estiver no PATH.")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    vectors = generate(root / "tb")
    simulator = args.simulator
    if simulator == "auto":
        simulator = "iverilog" if shutil.which("iverilog") else "verilator"
    tool = args.tool or shutil.which(simulator)
    if not tool:
        parser.error("Instale Icarus Verilog (iverilog/vvp) ou Verilator e selecione o simulador.")
    rtl = root / "rtl/hash_unit.sv"
    tb = root / "tb/tb_hash_unit.sv"
    build = root / "build" / simulator
    build.mkdir(parents=True, exist_ok=True)
    logs = root / "validation"
    logs.mkdir(exist_ok=True)
    plusargs = [f"+VECTORS={root / 'tb/hash_vectors.mem'}", f"+COUNT={len(vectors)}"]

    if simulator == "iverilog":
        executable = build / "tb_hash_unit.vvp"
        compile_command = [tool, "-g2012", "-Wall", "-s", "tb_hash_unit", "-o", str(executable), str(rtl), str(tb)]
        vvp = shutil.which("vvp")
        if not vvp:
            parser.error("O executavel vvp tambem precisa estar no PATH.")
        simulation_command = [vvp, str(executable), *plusargs]
    else:
        compile_command = [tool, "--binary", "--timing", "--trace", "--assert", "-Wall",
                           "-Wno-BLKSEQ", "--build-jobs", "2", "--top-module", "tb_hash_unit",
                           "--Mdir", str(build), str(rtl), str(tb)]
        simulation_command = [str(build / "Vtb_hash_unit"), *plusargs]

    def execute(command: list[str], log_name: str) -> subprocess.CompletedProcess:
        result = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (logs / log_name).write_text(result.stdout, encoding="utf-8")
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
        return result

    version = subprocess.run([tool, "--version" if simulator == "verilator" else "-V"],
                             text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(version.stdout.splitlines()[0] if version.stdout else simulator)
    print(f"Vetores independentes gerados: {len(vectors)}")
    execute(compile_command, "compile.log")
    result = execute(simulation_command, "simulation.log")
    print(result.stdout)
    if "PASS: tb_hash_unit concluido sem divergencias." not in result.stdout:
        raise SystemExit("Simulacao terminou sem confirmar todos os testes.")


if __name__ == "__main__":
    main()
