`timescale 1ns/1ps
`default_nettype none

module tb_fiu_hash_semana8;
    logic clk = 0;
    always #5 clk = ~clk;
    logic reset = 1;
    logic in_valid = 0;
    logic [31:0] src_ip_in = 0, dst_ip_in = 0;
    logic [15:0] src_port_in = 0, dst_port_in = 0, packet_length_in = 0;
    logic [7:0] protocol_in = 0;
    logic [79:0] timestamp_in = 0;
    wire [15:0] hash_index, packet_length;
    wire [103:0] flow_key;
    wire [79:0] timestamp;
    wire hash_valid;

    fiu_hash_top dut (.*);

    function automatic logic [15:0] reference_crc(input logic [103:0] key);
        logic [15:0] crc;
        crc = 16'hffff;
        for (int b = 12; b >= 0; b--) begin
            crc ^= {key[b*8 +: 8], 8'h00};
            for (int bit_no = 0; bit_no < 8; bit_no++)
                crc = crc[15] ? (crc << 1) ^ 16'h1021 : crc << 1;
        end
        return crc;
    endfunction

    task automatic send_and_check(input logic [79:0] ts, input logic [15:0] len);
        logic [103:0] expected_key;
        int timeout;
        expected_key = {src_ip_in, dst_ip_in, src_port_in, dst_port_in, protocol_in};
        @(negedge clk);
        timestamp_in = ts;
        packet_length_in = len;
        in_valid = 1;
        @(negedge clk);
        in_valid = 0;
        timeout = 0;
        while (!hash_valid && timeout < 25) begin
            @(negedge clk);
            timeout++;
        end
        if (!hash_valid) $fatal(1, "Timeout do hash");
        if (flow_key !== expected_key || packet_length !== len || timestamp !== ts ||
            hash_index !== reference_crc(expected_key))
            $fatal(1, "Dados/CRC incorretos: ts=%h len=%h hash=%h", timestamp, packet_length, hash_index);
        @(negedge clk);
        if (hash_valid) $fatal(1, "hash_valid durou mais que um ciclo");
    endtask

    initial begin
        repeat (2) @(negedge clk);
        if (hash_valid !== 0 || timestamp !== 0) $fatal(1, "Reset inicial falhou");
        reset = 0;
        src_ip_in = 32'h0a000001;
        dst_ip_in = 32'h0a000002;
        src_port_in = 16'd1234;
        dst_port_in = 16'd80;
        protocol_in = 8'd6;
        send_and_check({48'd12345, 32'd987654321}, 16'd100);
        send_and_check({48'd12346, 32'd12}, 16'd120);

        // Reset durante o calculo: limpar somente na proxima borda de subida.
        @(negedge clk);
        timestamp_in = {48'd12347, 32'd7};
        in_valid = 1;
        @(negedge clk);
        in_valid = 0;
        #1 reset = 1;
        #1;
        if (flow_key === 0)
            $fatal(1, "Reset atuou antes da borda de clock");
        @(posedge clk);
        #1;
        if (hash_valid !== 0 || flow_key !== 0 || packet_length !== 0 || timestamp !== 0)
            $fatal(1, "Reset sincrono falhou");
        @(negedge clk);
        reset = 0;
        send_and_check({48'd12348, 32'd999999999}, 16'd140);
        $display("PASSOU: reset alto sincrono, 80 bits do timestamp e CRC16 (3 pacotes).");
        $finish;
    end
endmodule

`default_nettype wire
