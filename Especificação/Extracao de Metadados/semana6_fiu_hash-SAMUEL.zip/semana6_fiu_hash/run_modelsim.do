# Na raiz do pacote: do run_modelsim.do
# Integracao por padrao. Para unidade: do run_modelsim.do fiu ou hash.
onerror {quit -code 1 -f}
set root [file dirname [file normalize [info script]]]
cd $root
set caso integracao
if {[info exists 1]} {set caso [set 1]}
if {$caso eq "fiu"} {
    set topo tb_flow_identification_unit
} elseif {$caso eq "hash"} {
    set topo tb_hash_unit
} elseif {$caso eq "integracao"} {
    set topo tb_fiu_hash_integration
} else {
    error "Caso invalido: use fiu, hash ou integracao"
}
file mkdir build/modelsim
file mkdir validation/modelsim
transcript file validation/modelsim/${caso}_simulation.log
transcript on
if {![file isdirectory build/modelsim/work]} {vlib build/modelsim/work}
vmap semana6_work build/modelsim/work
vlog -sv -work semana6_work rtl/flow_identification_unit.sv rtl/hash_unit.sv \
    rtl/fiu_hash_top.sv tb/metadata_testbench.sv tb/${topo}.sv
vsim -onfinish stop -voptargs=+acc semana6_work.$topo \
    +VECTORS=tb/hash_vectors.mem +COUNT=181 \
    +RESULTS=validation/modelsim/${caso}_obtidos.csv \
    +STAGES=validation/modelsim/${caso}_transferencias.csv
log -r /$topo/tb/*
add wave /$topo/tb/clk /$topo/tb/reset_n /$topo/tb/in_valid
add wave /$topo/tb/fiu_start /$topo/tb/fiu_valid /$topo/tb/hash_start /$topo/tb/out_valid
add wave -radix hexadecimal /$topo/tb/input_key /$topo/tb/fiu_data \
    /$topo/tb/flow_key_out /$topo/tb/hash_index_out /$topo/tb/timestamp_out
add wave -radix unsigned /$topo/tb/packet_length_out
vcd file validation/modelsim/${caso}.vcd
vcd add -r /$topo/tb/*
run -all
vcd flush
wave zoom full
puts "Confira PASS Semana 6 e os contadores; evidencias em validation/modelsim."
