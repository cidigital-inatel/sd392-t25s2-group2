`timescale 1ns/1ps
module tb_valid_high_hash;
    logic clk,reset_n,in_valid;
    wire [15:0] hash_index_out,packet_length_out;
    wire [103:0] flow_key_out;
    wire [79:0] timestamp_out;
    wire out_valid;
    int delivered;
    hash_unit dut(.clk,.reset_n,.in_valid,
        .flow_key_in(104'hC0A8010AC0A80114C35001BB06),
        .packet_length_in(16'd60),.timestamp_in(80'h8000000000000000007B),
        .hash_index_out,.flow_key_out,.packet_length_out,.timestamp_out,.out_valid);
    always #5 clk=~clk;
    always @(posedge clk)begin
        if(reset_n&&out_valid)begin
            delivered=delivered+1;
            if(delivered>1)$fatal(1,"REGRESSION_VALID_HIGH_DUPLICATED: Hash repetiu registro.");
            if({flow_key_out,packet_length_out,timestamp_out,hash_index_out}!==
                {104'hC0A8010AC0A80114C35001BB06,16'd60,80'h8000000000000000007B,16'hB511})
                $fatal(1,"REGRESSION_DATA_MISMATCH: dados do Hash divergentes.");
        end
    end
    initial begin
        clk=0;reset_n=0;in_valid=0;delivered=0;
        repeat(2)begin @(posedge clk);#2;end
        @(negedge clk);reset_n=1;in_valid=1;
        repeat(24)begin @(posedge clk);#2;end
        @(negedge clk);in_valid=0;
        repeat(20)begin @(posedge clk);#2;end
        if(delivered!=1)$fatal(1,"REGRESSION_VALID_HIGH_LOST: Hash nao entregou exatamente uma vez.");
        $display("PASS_REGRESSION: Hash, valid=24 clocks, uma entrega.");$finish;
    end
endmodule
