`timescale 1ns/1ps
module tb_valid_high_fiu;
    logic clk,reset_n,in_valid;
    wire [15:0] packet_length_out;
    wire [103:0] flow_key_out;
    wire [79:0] timestamp_out;
    wire out_valid;
    int delivered;
    flow_identification_unit dut(.clk,.reset_n,.in_valid,
`ifdef LEGACY_FIU
        .out_ready(1'b1),
`endif
        .src_ip_in(32'hC0A8010A),.dst_ip_in(32'hC0A80114),
        .src_port_in(16'd50000),.dst_port_in(16'd443),.protocol_in(8'd6),
        .packet_length_in(16'd60),.timestamp_in(80'h8000000000000000007B),
        .flow_key_out,.packet_length_out,.timestamp_out,.out_valid);
    always #5 clk=~clk;
    always @(posedge clk)begin
        if(reset_n&&out_valid)begin
            delivered=delivered+1;
            if(delivered>1)$fatal(1,"REGRESSION_VALID_HIGH_DUPLICATED: FIU repetiu registro sem valid baixo.");
            if({flow_key_out,packet_length_out,timestamp_out}!==
                {104'hC0A8010AC0A80114C35001BB06,16'd60,80'h8000000000000000007B})
                $fatal(1,"REGRESSION_DATA_MISMATCH: dados da FIU divergentes.");
        end
    end
    initial begin
        clk=0;reset_n=0;in_valid=0;delivered=0;
        repeat(2)begin @(posedge clk);#2;end
        @(negedge clk);reset_n=1;in_valid=1;
        repeat(24)begin @(posedge clk);#2;end
        @(negedge clk);in_valid=0;
        repeat(20)begin @(posedge clk);#2;end
        if(delivered!=1)$fatal(1,"REGRESSION_VALID_HIGH_LOST: FIU nao entregou exatamente uma vez.");
        $display("PASS_REGRESSION: FIU, valid=24 clocks, uma entrega.");$finish;
    end
endmodule
