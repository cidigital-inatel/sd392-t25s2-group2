#!/usr/bin/env python3
"""Reproduz duas incompatibilidades antigas e verifica a correcao na Semana 6.

Nao compile regressions/baseline com o RTL atual no mesmo work.
Os baselines sao historicos; nenhum deles participa da integracao entregue.
"""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tool')
    args=parser.parse_args()
    tool=args.tool or shutil.which('verilator') or shutil.which('verilator-cli')
    if not tool:parser.error('Informe o executavel Verilator com --tool.')
    tool=str(Path(tool).resolve())
    if sys.platform!='win32':
        import resource
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    root=Path(__file__).resolve().parents[1]
    logs=root/'validation/regressions';logs.mkdir(exist_ok=True)
    summary={}
    for label,module in [('hash','hash_unit'),('fiu','flow_identification_unit')]:
        top=f'tb_valid_high_{label}'
        probe=root/'regressions/tb'/f'{top}.sv'
        cases={}
        for variant in ['baseline','semana6']:
            build=root/'build/regressions'/f'{label}_{variant}';build.mkdir(parents=True,exist_ok=True)
            source=root/('regressions/baseline' if variant=='baseline' else 'rtl')/f'{module}.sv'
            command=[tool,'--binary','--timing','--assert','-Wall','-Wno-BLKSEQ',
                     '--build-jobs','2','--top-module',top,'--Mdir',str(build)]
            if label=='fiu' and variant=='baseline':
                # O codigo legado nao declara timescale. Esta permissao e
                # exclusiva do baseline; nao silencia erros do protocolo.
                command+=['-Wno-TIMESCALEMOD','+define+LEGACY_FIU']
            command +=[str(source),str(probe)]
            compiled=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            (logs/f'{label}_{variant}_compile.log').write_text(compiled.stdout)
            if compiled.returncode:
                print(compiled.stdout);raise SystemExit('Falha ao compilar a reproducao.')
            result=subprocess.run([str(build/f'V{top}')],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            (logs/f'{label}_{variant}.log').write_text(result.stdout)
            if variant=='baseline':
                expected='PROTOCOL_VIOLATION:' if label=='hash' else 'REGRESSION_VALID_HIGH_DUPLICATED:'
                assert result.returncode!=0 and expected in result.stdout
                status='EXPECTED_INCOMPATIBILITY_REPRODUCED'
            else:
                assert result.returncode==0 and 'PASS_REGRESSION:' in result.stdout
                status='PASS'
            cases[variant]={'status':status,'returncode':result.returncode,
                            'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
            print(f'{label} {variant}: {status}',flush=True)
        summary[label]=cases
    (logs/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('PASS: duas incompatibilidades reproduzidas; os mesmos estimulos passam nos dois RTLs atuais.')

if __name__=='__main__':main()
