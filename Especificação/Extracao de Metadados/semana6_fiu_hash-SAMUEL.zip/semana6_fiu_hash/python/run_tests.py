#!/usr/bin/env python3
"""Semana 6: testes unitarios e integracao FIU-Hash, com referencia externa.

Na raiz do pacote: python3 python/run_tests.py
Verilator fora do PATH: acrescente --tool /caminho/para/verilator
"""
import argparse
import csv
import hashlib
import json
import platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from reference_hash import generate

TESTS=[('fiu',0,'tb_flow_identification_unit',2,3),
       ('hash',1,'tb_hash_unit',15,16),
       ('integracao',2,'tb_fiu_hash_integration',17,16)]

def check_csv(path,vectors,kind):
    with path.open(encoding='utf-8',newline='') as stream: rows=list(csv.DictReader(stream))
    ids=[0,0,1,2,3,*range(len(vectors))]
    phases=['latencia',*['valid_prolongado']*4,*['colecao']*len(vectors)]
    assert len(rows)==len(ids)==186,'Quantidade incorreta de registros observados.'
    latency=[2,15,17][kind]
    for n,(row,vid,phase) in enumerate(zip(rows,ids,phases),1):
        assert int(row['entrega'])==n and int(row['vetor_id'])==vid and row['fase']==phase
        vector=vectors[vid]
        word=vector.memory_word()
        for key,value in [('flow_key',word[:26]),('timestamp',word[30:50])]:
            a='esperada' if key=='flow_key' else 'esperado'
            b='obtida' if key=='flow_key' else 'obtido'
            assert row[f'{key}_{a}_hex'].upper()==value
            assert row[f'{key}_{b}_hex'].upper()==value
        assert int(row['packet_length_esperado'])==int(row['packet_length_obtido'])==vector.packet_length
        if kind==0: assert row['hash_index_esperado_hex']==row['hash_index_obtido_hex']=='NA'
        else: assert row['hash_index_esperado_hex'].upper()==row['hash_index_obtido_hex'].upper()==word[50:]
        assert int(row['latencia_ciclos'])==int(row['ciclo_saida'])-int(row['ciclo_entrada'])==latency
        assert row['status']=='PASS'
    return rows

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tool',help='Executavel verilator ou verilator-cli.')
    args=parser.parse_args()
    tool=args.tool or shutil.which('verilator') or shutil.which('verilator-cli')
    if not tool: parser.error('Verilator nao encontrado; no ModelSim use run_modelsim.do.')
    tool=str(Path(tool).resolve())
    if sys.platform!='win32':
        import resource
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    root=Path(__file__).resolve().parents[1]
    logs=root/'validation';logs.mkdir(exist_ok=True)
    summary_path=logs/'summary.json';summary_path.unlink(missing_ok=True)
    vectors=generate(root/'tb')
    rtl=[root/'rtl'/name for name in ['flow_identification_unit.sv','hash_unit.sv','fiu_hash_top.sv']]

    def execute(command,log,allow_failure=False):
        result=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        log.write_text(result.stdout,encoding='utf-8')
        if result.returncode and not allow_failure:
            print(result.stdout)
            raise SystemExit(f'Falha em {log.name}, retorno {result.returncode}.')
        return result

    version=execute([tool,'--version'],logs/'tool_version.log')
    execute([tool,'--lint-only','-Wall','--top-module','fiu_hash_top',*map(str,rtl)],logs/'lint.log')
    results={}
    for label,kind,top,latency,gap in TESTS:
        build=root/'build'/label;build.mkdir(parents=True,exist_ok=True)
        command=[tool,'--binary','--timing','--trace','--assert','-Wall','-Wno-BLKSEQ',
                 '--build-jobs','2','--top-module',top,'--Mdir',str(build),*map(str,rtl),
                 str(root/'tb/metadata_testbench.sv'),str(root/'tb'/f'{top}.sv')]
        execute(command,logs/f'{label}_compile.log')
        plusargs=[f'+VECTORS={root / "tb/hash_vectors.mem"}',f'+COUNT={len(vectors)}']
        executable=str(build/f'V{top}')
        nominal=execute([executable,*plusargs,'+TRACE',f'+TRACEFILE={logs / (label+".vcd")}',
                         f'+RESULTS={logs / (label+"_obtidos.csv")}',
                         f'+STAGES={logs / (label+"_transferencias.csv")}'],logs/f'{label}_simulation.log')
        print(nominal.stdout,flush=True)
        if f'PASS: Semana 6 kind={kind} concluida sem divergencias.' not in nominal.stdout:
            raise SystemExit(f'{label}: PASS final ausente.')
        rows=check_csv(logs/f'{label}_obtidos.csv',vectors,kind)
        negative=execute([executable,*plusargs,'+NEGATIVE=busy',
                          f'+RESULTS={build / "negative.csv"}',f'+STAGES={build / "negative_stages.csv"}'],
                         logs/f'{label}_negative_busy.log',allow_failure=True)
        assert negative.returncode!=0 and 'PROTOCOL_VIOLATION:' in negative.stdout
        assert 'NEGATIVE_TEST_FAILED:' not in negative.stdout
        if kind==2: assert 'HASH recebeu nova transferencia ocupado' in negative.stdout
        counters={}
        for line in nominal.stdout.splitlines():
            if line.startswith('SUMMARY '):counters.update({k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)})
        assert counters['accepted']==len(vectors)+(9 if kind==2 else 8)
        assert counters['delivered']==186 and counters['reset_cancelled']==(4 if kind==2 else 3)
        if kind==2:
            with (logs/f'{label}_transferencias.csv').open() as stream: stages=list(csv.DictReader(stream))
            assert len(stages)==counters['fiu_transfers']==counters['hash_captures']==188
            for row in stages:
                word=vectors[int(row['vetor_id'])].memory_word()
                assert row['flow_key_hex'].upper()==word[:26]
                assert int(row['packet_length'])==int(word[26:30],16)
                assert row['timestamp_hex'].upper()==word[30:50]
        results[label]={'status':'PASS','counters':counters,'observed_rows':len(rows),
                        'latency_cycles':latency,'minimum_input_gap_cycles':gap,
                        'negative_busy':{'status':'EXPECTED_PROTOCOL_VIOLATION','returncode':negative.returncode}}
        print(f'PASS: {label}: CSV conferido e chegada ocupada detectada.',flush=True)
    paths=[*rtl,*sorted((root/'tb').glob('*.sv')),root/'python/reference_hash.py',Path(__file__).resolve(),
           root/'tb/hash_vectors.mem',root/'tb/hash_vectors.csv']
    summary={'status':'PASS','generated_at_utc':datetime.now(timezone.utc).isoformat(),
             'simulator':'Verilator','tool_version':version.stdout.strip(),'python_version':platform.python_version(),
             'protocol':'valid: capture once per high interval; rearm after sampled low; registered start',
             'vectors':len(vectors),'tests':results,
             'sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PASS: Semana 6: 3 simulacoes nominais, 558 entregas comparadas, 3 violacoes intencionais detectadas.')

if __name__=='__main__': main()
