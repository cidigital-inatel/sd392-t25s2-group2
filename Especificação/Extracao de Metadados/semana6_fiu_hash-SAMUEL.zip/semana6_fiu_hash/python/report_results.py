#!/usr/bin/env python3
"""Reorganiza o CSV observado no RTL em 181 casos com campos de entrada.

Nao calcula nem inventa os resultados obtidos: eles vem da testbench.
"""
import argparse
import csv
import ipaddress
import struct
from pathlib import Path

def main():
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--observed',type=Path,default=root/'validation/integracao_obtidos.csv')
    parser.add_argument('--out',type=Path,default=root/'validation/casos_integracao.csv')
    args=parser.parse_args()
    with args.observed.open(encoding='utf-8',newline='') as stream:
        observed=[r for r in csv.DictReader(stream) if r['fase']=='colecao']
    with (root/'tb/hash_vectors.csv').open(encoding='utf-8',newline='') as stream:
        fixtures=list(csv.DictReader(stream))
    assert len(observed)==len(fixtures)==181
    fields=['id','caso','src_ip','dst_ip','src_port','dst_port','protocol',
            'packet_length_entrada','timestamp_entrada_hex','flow_key_esperada_hex',
            'flow_key_obtida_hex','hash_index_esperado_hex','hash_index_obtido_hex',
            'packet_length_obtido','timestamp_obtido_hex','latencia_ciclos','status']
    args.out.parent.mkdir(parents=True,exist_ok=True)
    with args.out.open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields)
        writer.writeheader()
        for i,(row,fixture) in enumerate(zip(observed,fixtures)):
            assert int(row['vetor_id'])==i and row['status']=='PASS'
            key=fixture['flow_key_hex'].upper()
            assert row['flow_key_esperada_hex'].upper()==row['flow_key_obtida_hex'].upper()==key
            assert row['hash_index_obtido_hex'].upper()==fixture['hash_index_esperado_hex']
            src,dst,sport,dport,proto=struct.unpack('!IIHHB',bytes.fromhex(key))
            writer.writerow({'id':i,'caso':fixture['caso'],'src_ip':str(ipaddress.IPv4Address(src)),
                'dst_ip':str(ipaddress.IPv4Address(dst)),'src_port':sport,'dst_port':dport,'protocol':proto,
                'packet_length_entrada':row['packet_length_esperado'],'timestamp_entrada_hex':row['timestamp_esperado_hex'].upper(),
                'flow_key_esperada_hex':key,'flow_key_obtida_hex':row['flow_key_obtida_hex'].upper(),
                'hash_index_esperado_hex':fixture['hash_index_esperado_hex'],'hash_index_obtido_hex':row['hash_index_obtido_hex'].upper(),
                'packet_length_obtido':row['packet_length_obtido'],'timestamp_obtido_hex':row['timestamp_obtido_hex'].upper(),
                'latencia_ciclos':row['latencia_ciclos'],'status':row['status']})
    print(f'PASS: 181 casos de integracao organizados em {args.out}')

if __name__=='__main__':main()
