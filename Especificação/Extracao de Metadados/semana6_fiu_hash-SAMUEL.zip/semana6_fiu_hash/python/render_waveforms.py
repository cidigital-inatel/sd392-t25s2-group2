#!/usr/bin/env python3
"""Desenha duas figuras a partir dos VCDs reais; requer matplotlib.

Execute depois de python/run_tests.py, a partir da raiz do pacote.
"""
from pathlib import Path
import bisect
import csv
import re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parents[1]

class VCD:
    def __init__(self,path,top):
        self.prefix=top+'.tb.'
        self.names={};self.changes={}
        scope=[];header=True;time=0
        for line in path.read_text().splitlines():
            line=line.strip()
            if header:
                parts=line.split()
                if line.startswith('$scope'):scope.append(parts[2])
                elif line.startswith('$upscope'):scope.pop()
                elif line.startswith('$var'):
                    code=parts[3];self.names['.'.join([*scope,parts[4]])]=code
                    self.changes.setdefault(code,[])
                elif line.startswith('$enddefinitions'):header=False
            elif line.startswith('#'):time=int(line[1:])/1000
            elif line and not line.startswith('$'):
                if line[0] in 'bB':
                    value,code=line[1:].split()
                    value=int(value,2) if re.fullmatch('[01]+',value) else None
                elif line[0] in '01xzXZ':
                    code=line[1:];value=int(line[0]) if line[0] in '01' else None
                else:continue
                if code in self.changes:self.changes[code].append((time,value))
        self.times={code:[t for t,v in data] for code,data in self.changes.items()}
    def data(self,name):return self.changes[self.names[self.prefix+name]]
    def at(self,name,time):
        code=self.names[self.prefix+name]
        index=bisect.bisect_right(self.times[code],time)-1
        return self.changes[code][index][1]

def plot(vcd,configs,left,right,origin,title,subtitle,target,markers=(),ticks=None):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
    fig,axes=plt.subplots(len(configs),1,figsize=(13.2,8.0),sharex=True,gridspec_kw={'hspace':0.18})
    for axis,(name,label,kind),color in zip(axes,configs,['#325b71','#195c78','#13856e','#386e97','#13856e','#637d96','#b65d19','#b65d19','#637d96']):
        data=vcd.data(name)
        cuts=[left,*[t for t,v in data if left<t<right],right]
        for mark in markers:axis.axvline(mark-origin,color='#cbd6de',linewidth=0.8,zorder=0)
        if kind is None:
            axis.step([t-origin for t in cuts],[vcd.at(name,t) for t in cuts],where='post',color=color,linewidth=1.8)
            axis.set_ylim(-0.25,1.25);axis.set_yticks([0,1]);axis.tick_params(axis='y',labelsize=8)
        else:
            for a,b in zip(cuts,cuts[1:]):
                value=vcd.at(name,a)
                axis.add_patch(Rectangle((a-origin,0.1),b-a,0.8,facecolor='#edf3f7',edgecolor=color,linewidth=0.9))
                text={0:'IDLE',1:'CALC',2:'RESULT'}.get(value,str(value)) if kind=='state' else str(value) if kind=='decimal' else f'{value:04X}'
                if kind=='state' and value==2 and b-a<20:text='R'
                if b-a>=7:axis.text((a+b)/2-origin,0.5,text,ha='center',va='center',fontsize=8,color=color)
            axis.set_ylim(-0.1,1.1);axis.set_yticks([])
        axis.set_ylabel(label,rotation=0,ha='right',va='center',labelpad=18,fontsize=10,color='#25343f')
        axis.set_xlim(left-origin,right-origin)
        axis.spines[['top','right','left']].set_visible(False)
        axis.spines['bottom'].set_color('#d8e0e6');axis.tick_params(axis='x',length=0,labelsize=8)
    if ticks is not None:axes[-1].set_xticks(ticks)
    axes[-1].set_xlabel('Tempo após a captura (ns)' if origin else 'Tempo de simulação (ns)',labelpad=8)
    fig.suptitle(title,x=0.02,ha='left',fontsize=16,fontweight='bold',color='#195c78',y=0.985)
    fig.text(0.02,0.935,subtitle,fontsize=10.5,color='#25343f')
    fig.text(0.02,0.025,'Fonte: transições do VCD desta execução. Clock = 10 ns. Chave A = C0A8010AC0A80114C35001BB06.',fontsize=9,color='#526773')
    fig.subplots_adjust(left=0.18,right=0.99,top=0.90,bottom=0.12)
    fig.savefig(target,dpi=170,facecolor='white');plt.close(fig)
    print(target)

def main():
    target=ROOT/'evidencias';target.mkdir(exist_ok=True)
    vcd=VCD(ROOT/'validation/integracao.vcd','tb_fiu_hash_integration')
    assert vcd.at('fiu_start',45)==1 and vcd.at('fiu_valid',55)==1
    assert vcd.at('hash_start',65)==1 and vcd.at('out_valid',205)==1 and vcd.at('out_valid',215)==0
    assert vcd.at('hash_index_out',205)==0xB511
    plot(vcd,[('clk','clk',None),('in_valid','FIU in_valid',None),('fiu_start','FIU start',None),
              ('fiu_valid','FIU valid / Hash in_valid',None),('hash_start','Hash start',None),
              ('g_chain.dut.u_hash.crc_reg','CRC acumulado','hex'),('out_valid','Hash out_valid',None),
              ('hash_index_out','hash_index_out','hex')],
         30,225,0,'Semana 6 - integração real entre FIU e Hash Unit',
         '45 ns: FIU captura  |  55 ns: FIU publica  |  65 ns: Hash captura  |  205 ns: resultado  |  215 ns: leitura',
         target/'integracao_fiu_hash.png',markers=[45,55,65,75,205,215],
         ticks=[30,45,55,65,75,85,105,125,145,165,185,205,215,225])

    vcd=VCD(ROOT/'validation/hash.vcd','tb_hash_unit')
    with (ROOT/'validation/hash_obtidos.csv').open() as stream:
        row=next(r for r in csv.DictReader(stream) if r['fase']=='valid_prolongado')
    t0=float(row['tempo_saida_ns'])-150
    assert vcd.at('in_valid',t0+230)==1 and vcd.at('in_valid',t0+240)==0
    assert vcd.at('g_hash.dut.valid_seen',t0+230)==1 and vcd.at('g_hash.dut.valid_seen',t0+240)==0
    plot(vcd,[('in_valid','in_valid',None),('g_hash.dut.valid_seen','valid_seen (interno)',None),
              ('hash_start','start (interno)',None),('g_hash.dut.state','state','state'),
              ('out_valid','out_valid',None),('packet_length_out','comprimento capturado','decimal'),
              ('hash_index_out','hash_index_out','hex')],
         t0-10,t0+402,t0,'Semana 6 - valid prolongado representa uma única transferência',
         'Primeiro valid: 24 clocks e uma entrega. Após um clock baixo, outro registro é capturado. R = RESULT.',
         target/'valid_prolongado_hash.png',markers=[t0,t0+140,t0+150,t0+240,t0+250,t0+390,t0+400],
         ticks=[0,50,100,150,200,250,300,350,400])

if __name__=='__main__':main()
