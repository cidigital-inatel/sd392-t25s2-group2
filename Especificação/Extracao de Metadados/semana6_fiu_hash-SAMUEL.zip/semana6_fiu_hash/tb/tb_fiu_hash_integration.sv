`timescale 1ns/1ps
module tb_fiu_hash_integration;
    metadata_testbench #(.TEST_KIND(2)) tb();
endmodule
