`timescale 1ns/1ps
module tb_hash_unit;
    metadata_testbench #(.TEST_KIND(1)) tb();
endmodule
