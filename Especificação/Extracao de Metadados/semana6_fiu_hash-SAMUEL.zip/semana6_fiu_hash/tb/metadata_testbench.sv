`timescale 1ns/1ps
`default_nettype none

// Mesmo plano de estimulos para localizar erros: FIU isolada, Hash isolado,
// e ambos conectados por fiu_hash_top. Golden externo, nao calculado no DUT.
module metadata_testbench #(parameter int TEST_KIND = 2);
    localparam int MAX_VECTORS = 512;
    localparam int MAX_RECORDS = 1024;
    localparam int LATENCY = (TEST_KIND == 0) ? 2 : (TEST_KIND == 1) ? 15 : 17;
    localparam int INPUT_GAP = (TEST_KIND == 0) ? 3 : 16;
    logic clk, reset_n, in_valid;
    logic [31:0] src_ip_in, dst_ip_in;
    logic [15:0] src_port_in, dst_port_in, packet_length_in;
    logic [7:0] protocol_in;
    logic [79:0] timestamp_in;
    wire [103:0] input_key = {src_ip_in,dst_ip_in,src_port_in,dst_port_in,protocol_in};
    wire [103:0] flow_key_out;
    wire [15:0] packet_length_out, hash_index_out;
    wire [79:0] timestamp_out;
    wire out_valid;
    wire fiu_start, hash_start, fiu_valid;
    wire [199:0] fiu_capture_data, hash_capture_data, fiu_data;

    generate
        if (TEST_KIND == 0) begin : g_fiu
            flow_identification_unit dut (
                .clk,.reset_n,.src_ip_in,.dst_ip_in,.src_port_in,.dst_port_in,
                .protocol_in,.packet_length_in,.timestamp_in,.in_valid,
                .flow_key_out,.packet_length_out,.timestamp_out,.out_valid
            );
            assign hash_index_out = '0;
            assign fiu_start = dut.start;
            assign hash_start = 1'b0;
            assign fiu_valid = out_valid;
            assign fiu_capture_data = {dut.src_ip_reg,dut.dst_ip_reg,dut.src_port_reg,
                                      dut.dst_port_reg,dut.protocol_reg,dut.length_reg,dut.timestamp_reg};
            assign hash_capture_data = '0;
            assign fiu_data = {flow_key_out,packet_length_out,timestamp_out};
        end else if (TEST_KIND == 1) begin : g_hash
            hash_unit dut (
                .clk,.reset_n,.flow_key_in(input_key),.packet_length_in,.timestamp_in,
                .in_valid,.hash_index_out,.flow_key_out,.packet_length_out,.timestamp_out,.out_valid
            );
            assign fiu_start = 1'b0;
            assign hash_start = dut.start;
            assign fiu_valid = 1'b0;
            assign fiu_capture_data = '0;
            assign hash_capture_data = {dut.key_reg,dut.length_reg,dut.timestamp_reg};
            assign fiu_data = '0;
        end else begin : g_chain
            fiu_hash_top dut (
                .clk,.reset_n,.src_ip_in,.dst_ip_in,.src_port_in,.dst_port_in,.protocol_in,
                .packet_length_in,.timestamp_in,.in_valid,.hash_index_out,.flow_key_out,
                .packet_length_out,.timestamp_out,.out_valid
            );
            assign fiu_start = dut.u_fiu.start;
            assign hash_start = dut.u_hash.start;
            assign fiu_valid = dut.fiu_valid;
            assign fiu_capture_data = {dut.u_fiu.src_ip_reg,dut.u_fiu.dst_ip_reg,
                                      dut.u_fiu.src_port_reg,dut.u_fiu.dst_port_reg,
                                      dut.u_fiu.protocol_reg,dut.u_fiu.length_reg,dut.u_fiu.timestamp_reg};
            assign hash_capture_data = {dut.u_hash.key_reg,dut.u_hash.length_reg,dut.u_hash.timestamp_reg};
            assign fiu_data = {dut.fiu_flow_key,dut.fiu_packet_length,dut.fiu_timestamp};
        end
    endgenerate

    logic [215:0] vectors [0:MAX_VECTORS-1];
    // Scoreboard de software da simulacao. Nao existe FIFO no RTL.
    logic [215:0] expected [0:MAX_RECORDS-1];
    int capture_cycle [0:MAX_RECORDS-1];
    int vector_id [0:MAX_RECORDS-1];
    string record_phase [0:MAX_RECORDS-1];
    int clock_count, vector_count, active_vector;
    int read_ptr, write_ptr, stage_ptr;
    int accepted_total, delivered_total, cancelled_total;
    int fiu_transfers, hash_captures, max_pending;
    int repeated_high_cycles, start_checks, minimum_gap_checks;
    int previous_capture_cycle, available_checks;
    int result_fd, stage_fd;
    logic source_seen, previous_output_valid;
    logic source_event, hash_event;
    logic [199:0] expected_hash_capture;
    string phase, vector_file, results_file, stages_file, trace_file;
    string negative_mode;

    always #5 clk = ~clk;

    // Conferencia na mesma borda de leitura dos receptores, antes da NBA.
    always @(posedge clk) begin
        clock_count = clock_count + 1;
        source_event = 1'b0;
        hash_event = 1'b0;
        expected_hash_capture = '0;
        if (!reset_n) begin
            cancelled_total = cancelled_total + write_ptr - read_ptr;
            write_ptr = 0;
            read_ptr = 0;
            stage_ptr = 0;
            source_seen = 1'b0;
            previous_output_valid = 1'b0;
            previous_capture_cycle = -1;
        end else begin
            if (previous_output_valid && out_valid)
                $fatal(1,"Saida foi publicada por mais de um ciclo.");
            previous_output_valid = out_valid;

            if (out_valid) begin
                if (read_ptr >= write_ptr)
                    $fatal(1,"Resultado duplicado ou sem entrada correspondente.");
                if ({flow_key_out,packet_length_out,timestamp_out} !== expected[read_ptr][215:16])
                    $fatal(1,"Chave ou metadados nao correspondem ao registro capturado.");
                if (TEST_KIND != 0 && hash_index_out !== expected[read_ptr][15:0])
                    $fatal(1,"CRC divergente: esperado=%04h obtido=%04h",expected[read_ptr][15:0],hash_index_out);
                if (clock_count-capture_cycle[read_ptr] != LATENCY)
                    $fatal(1,"Latencia divergente: esperada=%0d obtida=%0d",LATENCY,clock_count-capture_cycle[read_ptr]);
                delivered_total = delivered_total + 1;
                $fwrite(result_fd,"%0d,%s,%0d,%026h,%026h,%0d,%0d,%020h,%020h,",
                        delivered_total,record_phase[read_ptr],vector_id[read_ptr],
                        expected[read_ptr][215:112],flow_key_out,expected[read_ptr][111:96],packet_length_out,
                        expected[read_ptr][95:16],timestamp_out);
                if (TEST_KIND == 0) $fwrite(result_fd,"NA,NA,");
                else $fwrite(result_fd,"%04h,%04h,",expected[read_ptr][15:0],hash_index_out);
                $fwrite(result_fd,"%0d,%0d,%0d,%0.0f,PASS\n",capture_cycle[read_ptr],clock_count,
                        clock_count-capture_cycle[read_ptr],$realtime/1ns);
                read_ptr = read_ptr + 1;
            end

            if (!in_valid) source_seen = 1'b0;
            else if (!source_seen) begin
                source_seen = 1'b1;
                source_event = 1'b1;
                if (write_ptr >= MAX_RECORDS)
                    $fatal(1,"Scoreboard excedeu o limite.");
                if ({input_key,packet_length_in,timestamp_in} !== vectors[active_vector][215:16])
                    $fatal(1,"Estimulo incoerente com o vetor esperado.");
                if (previous_capture_cycle >= 0 && clock_count-previous_capture_cycle==INPUT_GAP)
                    minimum_gap_checks = minimum_gap_checks + 1;
                previous_capture_cycle = clock_count;
                expected[write_ptr] = vectors[active_vector];
                capture_cycle[write_ptr] = clock_count;
                vector_id[write_ptr] = active_vector;
                record_phase[write_ptr] = phase;
                write_ptr = write_ptr + 1;
                accepted_total = accepted_total + 1;
                if (TEST_KIND == 1) begin
                    hash_event = 1'b1;
                    hash_captures = hash_captures + 1;
                    expected_hash_capture = vectors[active_vector][215:16];
                end
            end else repeated_high_cycles = repeated_high_cycles + 1;

            if (TEST_KIND != 1 && fiu_valid) begin
                if (stage_ptr >= write_ptr || fiu_data !== expected[stage_ptr][215:16])
                    $fatal(1,"Saida FIU duplicada ou concatencacao incorreta.");
                if (clock_count-capture_cycle[stage_ptr] != 2)
                    $fatal(1,"Transferencia FIU nao ocorreu dois clocks apos a captura.");
                fiu_transfers = fiu_transfers + 1;
                $fwrite(stage_fd,"%0d,%0d,%0.0f,%026h,%0d,%020h,%0d\n",fiu_transfers,
                        clock_count,$realtime/1ns,fiu_data[199:96],fiu_data[95:80],fiu_data[79:0],vector_id[stage_ptr]);
                if (TEST_KIND == 2) begin
                    hash_event = 1'b1;
                    hash_captures = hash_captures + 1;
                    expected_hash_capture = fiu_data;
                end
                stage_ptr = stage_ptr + 1;
            end
            if (write_ptr-read_ptr > max_pending) max_pending=write_ptr-read_ptr;
        end

        #1;
        if (!reset_n) begin
            if (out_valid !== 1'b0 || fiu_start !== 1'b0 || hash_start !== 1'b0)
                $fatal(1,"Reset nao limpou validade e starts.");
        end else begin
            if (TEST_KIND != 1) begin
                if (fiu_start !== source_event)
                    $fatal(1,"FIU start nao corresponde a captura unica do periodo alto.");
                if (source_event && fiu_capture_data !== expected[write_ptr-1][215:16])
                    $fatal(1,"FIU nao capturou os sete campos atomicamente.");
            end
            if (TEST_KIND != 0) begin
                if (hash_start !== hash_event)
                    $fatal(1,"Hash start nao corresponde a uma unica captura.");
                if (hash_event && hash_capture_data !== expected_hash_capture)
                    $fatal(1,"Hash nao capturou todos os 200 bits transferidos.");
            end
            start_checks = start_checks + 1;
            if (read_ptr < write_ptr && clock_count-capture_cycle[read_ptr] == LATENCY-1) begin
                if (out_valid !== 1'b1)
                    $fatal(1,"Resultado nao foi disponibilizado no ciclo esperado.");
                available_checks = available_checks + 1;
            end
        end
    end

    task automatic drive_vector(input int id);
        @(negedge clk);
        active_vector=id;
        src_ip_in=vectors[id][215:184]; dst_ip_in=vectors[id][183:152];
        src_port_in=vectors[id][151:136]; dst_port_in=vectors[id][135:120];
        protocol_in=vectors[id][119:112]; packet_length_in=vectors[id][111:96];
        timestamp_in=vectors[id][95:16]; in_valid=1'b1;
        @(posedge clk); #2;
    endtask

    task automatic clear_input;
        @(negedge clk);
        in_valid=1'b0;
        // Ruido durante valid=0: todos os campos externos sao alterados.
        src_ip_in=~src_ip_in; dst_ip_in=~dst_ip_in;
        src_port_in=~src_port_in; dst_port_in=~dst_port_in;
        protocol_in=~protocol_in; packet_length_in=~packet_length_in; timestamp_in=~timestamp_in;
    endtask

    task automatic send_record(input int id,input int hold_cycles,input int gap);
        int first_cycle;
        if (gap<INPUT_GAP || gap<hold_cycles+1)
            $fatal(1,"Estimulo nominal sem intervalo ou sem borda baixa para rearmar.");
        drive_vector(id);
        first_cycle=clock_count;
        repeat(hold_cycles-1) begin @(posedge clk); #2; end
        clear_input();
        // Agenda fixa, independente da ocupacao interna do DUT.
        while(clock_count-first_cycle<gap-1) begin @(posedge clk); #2; end
    endtask

    task automatic reset_dut;
        @(negedge clk); reset_n=1'b0; in_valid=1'b0;
        repeat(2) begin @(posedge clk); #2; end
        @(negedge clk); reset_n=1'b1;
    endtask

    task automatic drain;
        repeat(LATENCY+3) begin @(posedge clk); #2; end
        if (write_ptr != read_ptr) $fatal(1,"Registro pendente nao foi entregue.");
    endtask

    initial begin : run_tests
        int fd;
        int wait_active;
        clk=1'b0;reset_n=1'b0;in_valid=1'b0;
        src_ip_in='0;dst_ip_in='0;src_port_in='0;dst_port_in='0;
        protocol_in='0;packet_length_in='0;timestamp_in='0;
        clock_count=0;vector_count=181;active_vector=0;
        read_ptr=0;write_ptr=0;stage_ptr=0;
        accepted_total=0;delivered_total=0;cancelled_total=0;
        fiu_transfers=0;hash_captures=0;max_pending=0;
        repeated_high_cycles=0;start_checks=0;minimum_gap_checks=0;available_checks=0;
        previous_capture_cycle=-1;source_seen=1'b0;previous_output_valid=1'b0;
        source_event=1'b0;hash_event=1'b0;expected_hash_capture='0;
        phase="latencia";negative_mode="";
        vector_file="tb/hash_vectors.mem";
        results_file="validation/obtidos.csv";
        stages_file="validation/transferencias.csv";
        trace_file="validation/integracao.vcd";
        if($value$plusargs("VECTORS=%s",vector_file))begin end
        if($value$plusargs("COUNT=%d",vector_count))begin end
        if($value$plusargs("RESULTS=%s",results_file))begin end
        if($value$plusargs("STAGES=%s",stages_file))begin end
        if($value$plusargs("TRACEFILE=%s",trace_file))begin end
        if($value$plusargs("NEGATIVE=%s",negative_mode))begin end
        if(vector_count<13 || vector_count>MAX_VECTORS)$fatal(1,"COUNT invalido.");
        fd=$fopen(vector_file,"r");if(fd==0)$fatal(1,"Vetores ausentes: %s",vector_file);$fclose(fd);
        $readmemh(vector_file,vectors,0,vector_count-1);
        result_fd=$fopen(results_file,"w");stage_fd=$fopen(stages_file,"w");
        if(result_fd==0 || stage_fd==0)$fatal(1,"Nao foi possivel abrir CSVs.");
        $fwrite(result_fd,"entrega,fase,vetor_id,flow_key_esperada_hex,flow_key_obtida_hex,packet_length_esperado,packet_length_obtido,timestamp_esperado_hex,timestamp_obtido_hex,hash_index_esperado_hex,hash_index_obtido_hex,ciclo_entrada,ciclo_saida,latencia_ciclos,tempo_saida_ns,status\n");
        $fwrite(stage_fd,"transferencia,ciclo,tempo_ns,flow_key_hex,packet_length,timestamp_hex,vetor_id\n");
        if($test$plusargs("TRACE"))begin $dumpfile(trace_file);$dumpvars(0,metadata_testbench);end
        reset_dut();

        if(negative_mode=="busy")begin
            if(TEST_KIND==2)begin
                // Duas publicacoes FIU separadas por 3 clocks: FIU consegue
                // publicar, mas a segunda chegada encontra o Hash ocupado.
                drive_vector(0);clear_input();
                repeat(2)begin @(posedge clk);#2;end
                drive_vector(1);clear_input();
                repeat(8)begin @(posedge clk);#2;end
            end else begin
                drive_vector(0);clear_input();
                @(posedge clk);#2;
                drive_vector(1);
            end
            $fatal(1,"NEGATIVE_TEST_FAILED: chegada ocupada nao foi detectada.");
        end else if(negative_mode!="")$fatal(1,"NEGATIVE desconhecido.");

        send_record(0,1,INPUT_GAP);drain();
        $display("PASS: kind=%0d captura, start e latencia de %0d clocks.",TEST_KIND,LATENCY);

        phase="reset_captura";
        drive_vector(1);reset_dut();drain();
        phase="reset_ativo";
        drive_vector(2);clear_input();
        wait_active=(TEST_KIND==0)?1:4;
        repeat(wait_active)begin @(posedge clk);#2;end
        reset_dut();drain();

        phase="reset_resultado";
        drive_vector(3);clear_input();
        if(TEST_KIND==2)begin
            // Nova captura FIU em E16, simultanea ao resultado do Hash antigo.
            repeat(LATENCY-2)begin @(posedge clk);#2;end
            drive_vector(4);
        end else begin
            repeat(LATENCY-1)begin @(posedge clk);#2;end
        end
        if(out_valid!==1'b1)$fatal(1,"Reset de resultado nao atingiu publicacao.");
        reset_dut();drain();
        $display("PASS: resets cancelam registros em captura, processamento e publicacao.");

        // Cada periodo alto, inclusive maior que o processamento inteiro,
        // representa EXATAMENTE um pacote. Voltar a baixo permite outro.
        phase="valid_prolongado";
        send_record(0,24,(INPUT_GAP>25)?INPUT_GAP:25);
        send_record(1,2,(INPUT_GAP>3)?INPUT_GAP:3);
        send_record(2,5,(INPUT_GAP>6)?INPUT_GAP:6);
        send_record(3,24,(INPUT_GAP>25)?INPUT_GAP:25);
        drain();
        $display("PASS: valid alto por 2, 5 e 24 clocks gera uma captura; baixo rearma.");

        phase="colecao";
        for(int i=0;i<vector_count;i++)
            send_record(i,1,((i%7)==0)?INPUT_GAP+3:INPUT_GAP);
        drain();
        if(accepted_total!=delivered_total+cancelled_total || read_ptr!=write_ptr)
            $fatal(1,"Conservacao de registros falhou.");
        if(delivered_total!=vector_count+5 || cancelled_total!=((TEST_KIND==2)?4:3))
            $fatal(1,"Quantidade de resultados/reset divergente do plano.");
        if(repeated_high_cycles!=51 || minimum_gap_checks==0)
            $fatal(1,"Estimulos obrigatorios nao foram exercitados.");
        if(TEST_KIND==2 && (max_pending!=2 || fiu_transfers!=hash_captures))
            $fatal(1,"Integracao nao exercitou sobreposicao ou perdeu transferencia FIU-Hash.");
        $fclose(result_fd);$fclose(stage_fd);
        $display("PASS: 181 vetores, todos os dados, ordem e pulsos conferidos.");
        $display("SUMMARY accepted=%0d delivered=%0d reset_cancelled=%0d pending=%0d",
                 accepted_total,delivered_total,cancelled_total,write_ptr-read_ptr);
        $display("SUMMARY fiu_transfers=%0d hash_captures=%0d max_pending=%0d",fiu_transfers,hash_captures,max_pending);
        $display("SUMMARY repeated_high_cycles=%0d start_checks=%0d minimum_gap_checks=%0d availability_checks=%0d",
                 repeated_high_cycles,start_checks,minimum_gap_checks,available_checks);
        $display("PASS: Semana 6 kind=%0d concluida sem divergencias.",TEST_KIND);
        $finish;
    end

    initial begin #150000;$fatal(1,"Timeout global.");end
endmodule

`default_nettype wire
