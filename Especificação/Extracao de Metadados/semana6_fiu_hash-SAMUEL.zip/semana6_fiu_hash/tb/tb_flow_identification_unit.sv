`timescale 1ns/1ps
module tb_flow_identification_unit;
    metadata_testbench #(.TEST_KIND(0)) tb();
endmodule
